---@class UnityGameFramework.Runtime.VarMaterial : GameFramework.Variable_1_UnityEngine_Material_
local m = {}

---@overload fun(value:UnityGameFramework.Runtime.VarMaterial):UnityEngine.Material @static
---@static
---@param value UnityEngine.Material
---@return UnityGameFramework.Runtime.VarMaterial
function m.op_Implicit(value) end

UnityGameFramework.Runtime.VarMaterial = m
return m
