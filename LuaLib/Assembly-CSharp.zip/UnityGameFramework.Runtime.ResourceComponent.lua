---@class UnityGameFramework.Runtime.ResourceComponent : UnityGameFramework.Runtime.GameFrameworkComponent
---@field public ReadOnlyPath string
---@field public ReadWritePath string
---@field public ResourceMode GameFramework.Resource.ResourceMode
---@field public ReadWritePathType UnityGameFramework.Runtime.ReadWritePathType
---@field public CurrentVariant string
---@field public UnloadUnusedAssetsInterval number
---@field public ApplicableGameVersion string
---@field public InternalResourceVersion number
---@field public AssetCount number
---@field public ResourceCount number
---@field public ResourceGroupCount number
---@field public UpdatePrefixUri string
---@field public UpdateRetryCount number
---@field public UpdateWaitingCount number
---@field public UpdatingCount number
---@field public LoadTotalAgentCount number
---@field public LoadFreeAgentCount number
---@field public LoadWorkingAgentCount number
---@field public LoadWaitingTaskCount number
---@field public AssetAutoReleaseInterval number
---@field public AssetCapacity number
---@field public AssetExpireTime number
---@field public AssetPriority number
---@field public ResourceAutoReleaseInterval number
---@field public ResourceCapacity number
---@field public ResourceExpireTime number
---@field public ResourcePriority number
local m = {}

---@param resourceMode GameFramework.Resource.ResourceMode
function m:SetResourceMode(resourceMode) end

---@param currentVariant string
function m:SetCurrentVariant(currentVariant) end

---@param decryptResourceCallback fun(name:string, variant:string, loadType:number, length:number, hashCode:number, storageInReadOnly:boolean, bytes:string):string
function m:SetDecryptResourceCallback(decryptResourceCallback) end

---@param performGCCollect boolean
function m:UnloadUnusedAssets(performGCCollect) end

---@param performGCCollect boolean
function m:ForceUnloadUnusedAssets(performGCCollect) end

function m:InitResources() end

---@param latestInternalResourceVersion number
---@return GameFramework.Resource.CheckVersionListResult
function m:CheckVersionList(latestInternalResourceVersion) end

---@param versionListLength number
---@param versionListHashCode number
---@param versionListZipLength number
---@param versionListZipHashCode number
function m:UpdateVersionList(versionListLength, versionListHashCode, versionListZipLength, versionListZipHashCode) end

function m:CheckResources() end

function m:UpdateResources() end

---@overload fun(assetName:string, loadAssetCallbacks:GameFramework.Resource.LoadAssetCallbacks, userData:any)
---@param assetName string
---@param loadAssetCallbacks GameFramework.Resource.LoadAssetCallbacks
function m:LoadAsset(assetName, loadAssetCallbacks) end

---@param asset any
function m:UnloadAsset(asset) end

---@param resourceGroupName string
---@return boolean
function m:GetResourceGroupReady(resourceGroupName) end

---@param resourceGroupName string
---@return number
function m:GetResourceGroupResourceCount(resourceGroupName) end

---@param resourceGroupName string
---@return number
function m:GetResourceGroupReadyResourceCount(resourceGroupName) end

---@param resourceGroupName string
---@return number
function m:GetResourceGroupTotalLength(resourceGroupName) end

---@param resourceGroupName string
---@return number
function m:GetResourceGroupTotalReadyLength(resourceGroupName) end

---@param resourceGroupName string
---@return number
function m:GetResourceGroupProgress(resourceGroupName) end

UnityGameFramework.Runtime.ResourceComponent = m
return m
