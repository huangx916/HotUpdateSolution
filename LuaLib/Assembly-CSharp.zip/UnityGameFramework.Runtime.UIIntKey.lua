---@class UnityGameFramework.Runtime.UIIntKey : UnityEngine.MonoBehaviour
---@field public Key number
local m = {}

UnityGameFramework.Runtime.UIIntKey = m
return m
