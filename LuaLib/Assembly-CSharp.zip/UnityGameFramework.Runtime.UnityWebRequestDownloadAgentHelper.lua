---@class UnityGameFramework.Runtime.UnityWebRequestDownloadAgentHelper : UnityGameFramework.Runtime.DownloadAgentHelperBase
local m = {}

---@virtual
---@param value fun(sender:any, e:GameFramework.Download.DownloadAgentHelperUpdateEventArgs)
function m:add_DownloadAgentHelperUpdate(value) end

---@virtual
---@param value fun(sender:any, e:GameFramework.Download.DownloadAgentHelperUpdateEventArgs)
function m:remove_DownloadAgentHelperUpdate(value) end

---@virtual
---@param value fun(sender:any, e:GameFramework.Download.DownloadAgentHelperCompleteEventArgs)
function m:add_DownloadAgentHelperComplete(value) end

---@virtual
---@param value fun(sender:any, e:GameFramework.Download.DownloadAgentHelperCompleteEventArgs)
function m:remove_DownloadAgentHelperComplete(value) end

---@virtual
---@param value fun(sender:any, e:GameFramework.Download.DownloadAgentHelperErrorEventArgs)
function m:add_DownloadAgentHelperError(value) end

---@virtual
---@param value fun(sender:any, e:GameFramework.Download.DownloadAgentHelperErrorEventArgs)
function m:remove_DownloadAgentHelperError(value) end

---@overload fun(downloadUri:string, fromPosition:number, userData:any) @virtual
---@overload fun(downloadUri:string, fromPosition:number, toPosition:number, userData:any) @virtual
---@virtual
---@param downloadUri string
---@param userData any
function m:Download(downloadUri, userData) end

---@virtual
function m:Reset() end

---@virtual
function m:Dispose() end

UnityGameFramework.Runtime.UnityWebRequestDownloadAgentHelper = m
return m
