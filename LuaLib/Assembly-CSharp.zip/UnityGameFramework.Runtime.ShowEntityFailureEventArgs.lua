---@class UnityGameFramework.Runtime.ShowEntityFailureEventArgs : GameFramework.Event.GameEventArgs
---@field public Id number
---@field public EntityId number
---@field public EntityLogicType System.Type
---@field public EntityAssetName string
---@field public EntityGroupName string
---@field public ErrorMessage string
---@field public UserData any
local m = {}

UnityGameFramework.Runtime.ShowEntityFailureEventArgs = m
return m
