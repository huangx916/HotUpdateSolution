---@class NGUIText.SymbolStyle : System.Enum
---@field public None NGUIText.SymbolStyle @static
---@field public Normal NGUIText.SymbolStyle @static
---@field public Colored NGUIText.SymbolStyle @static
---@field public value__ number
local m = {}

NGUIText.SymbolStyle = m
return m
