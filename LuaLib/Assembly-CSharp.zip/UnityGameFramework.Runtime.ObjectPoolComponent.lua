---@class UnityGameFramework.Runtime.ObjectPoolComponent : UnityGameFramework.Runtime.GameFrameworkComponent
---@field public Count number
local m = {}

---@overload fun(name:string):boolean
---@return boolean
function m:HasObjectPool() end

---@overload fun(name:string):GameFramework.ObjectPool.IObjectPool_1_T_
---@return GameFramework.ObjectPool.IObjectPool_1_T_
function m:GetObjectPool() end

---@overload fun(sort:boolean):GameFramework.ObjectPool.ObjectPoolBase[]
---@return GameFramework.ObjectPool.ObjectPoolBase[]
function m:GetAllObjectPools() end

---@overload fun(name:string):GameFramework.ObjectPool.IObjectPool_1_T_
---@overload fun(capacity:number):GameFramework.ObjectPool.IObjectPool_1_T_
---@overload fun(expireTime:number):GameFramework.ObjectPool.IObjectPool_1_T_
---@overload fun(name:string, capacity:number):GameFramework.ObjectPool.IObjectPool_1_T_
---@overload fun(name:string, expireTime:number):GameFramework.ObjectPool.IObjectPool_1_T_
---@overload fun(capacity:number, expireTime:number):GameFramework.ObjectPool.IObjectPool_1_T_
---@overload fun(capacity:number, priority:number):GameFramework.ObjectPool.IObjectPool_1_T_
---@overload fun(expireTime:number, priority:number):GameFramework.ObjectPool.IObjectPool_1_T_
---@overload fun(name:string, capacity:number, expireTime:number):GameFramework.ObjectPool.IObjectPool_1_T_
---@overload fun(name:string, capacity:number, priority:number):GameFramework.ObjectPool.IObjectPool_1_T_
---@overload fun(name:string, expireTime:number, priority:number):GameFramework.ObjectPool.IObjectPool_1_T_
---@overload fun(capacity:number, expireTime:number, priority:number):GameFramework.ObjectPool.IObjectPool_1_T_
---@overload fun(name:string, capacity:number, expireTime:number, priority:number):GameFramework.ObjectPool.IObjectPool_1_T_
---@return GameFramework.ObjectPool.IObjectPool_1_T_
function m:CreateSingleSpawnObjectPool() end

---@overload fun(name:string):GameFramework.ObjectPool.IObjectPool_1_T_
---@overload fun(capacity:number):GameFramework.ObjectPool.IObjectPool_1_T_
---@overload fun(expireTime:number):GameFramework.ObjectPool.IObjectPool_1_T_
---@overload fun(name:string, capacity:number):GameFramework.ObjectPool.IObjectPool_1_T_
---@overload fun(name:string, expireTime:number):GameFramework.ObjectPool.IObjectPool_1_T_
---@overload fun(capacity:number, expireTime:number):GameFramework.ObjectPool.IObjectPool_1_T_
---@overload fun(capacity:number, priority:number):GameFramework.ObjectPool.IObjectPool_1_T_
---@overload fun(expireTime:number, priority:number):GameFramework.ObjectPool.IObjectPool_1_T_
---@overload fun(name:string, capacity:number, expireTime:number):GameFramework.ObjectPool.IObjectPool_1_T_
---@overload fun(name:string, capacity:number, priority:number):GameFramework.ObjectPool.IObjectPool_1_T_
---@overload fun(name:string, expireTime:number, priority:number):GameFramework.ObjectPool.IObjectPool_1_T_
---@overload fun(capacity:number, expireTime:number, priority:number):GameFramework.ObjectPool.IObjectPool_1_T_
---@overload fun(name:string, capacity:number, expireTime:number, priority:number):GameFramework.ObjectPool.IObjectPool_1_T_
---@return GameFramework.ObjectPool.IObjectPool_1_T_
function m:CreateMultiSpawnObjectPool() end

---@overload fun(name:string):boolean
---@overload fun(objectPool:GameFramework.ObjectPool.IObjectPool_1_T_):boolean
---@return boolean
function m:DestroyObjectPool() end

function m:Release() end

function m:ReleaseAllUnused() end

UnityGameFramework.Runtime.ObjectPoolComponent = m
return m
