---@class UnityGameFramework.Runtime.LoadDataTableUpdateEventArgs : GameFramework.Event.GameEventArgs
---@field public Id number
---@field public DataTableName string
---@field public DataTableType System.Type
---@field public DataTableAssetName string
---@field public Progress number
---@field public UserData any
local m = {}

UnityGameFramework.Runtime.LoadDataTableUpdateEventArgs = m
return m
