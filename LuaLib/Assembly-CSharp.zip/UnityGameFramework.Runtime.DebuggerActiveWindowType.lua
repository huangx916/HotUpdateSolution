---@class UnityGameFramework.Runtime.DebuggerActiveWindowType : System.Enum
---@field public Auto UnityGameFramework.Runtime.DebuggerActiveWindowType @static
---@field public Close UnityGameFramework.Runtime.DebuggerActiveWindowType @static
---@field public Open UnityGameFramework.Runtime.DebuggerActiveWindowType @static
---@field public value__ number
local m = {}

UnityGameFramework.Runtime.DebuggerActiveWindowType = m
return m
