---@class UnityGameFramework.Runtime.SoundComponent.SoundGroup : System.Object
---@field public Name string
---@field public AvoidBeingReplacedBySamePriority boolean
---@field public Mute boolean
---@field public Volume number
---@field public AgentHelperCount number
local m = {}

UnityGameFramework.Runtime.SoundComponent.SoundGroup = m
return m
