---@class UnityGameFramework.Runtime.LoadDataTableInfo : System.Object
---@field public DataTableName string
---@field public DataTableType System.Type
---@field public DataTableNameInType string
---@field public UserData any
local m = {}

UnityGameFramework.Runtime.LoadDataTableInfo = m
return m
