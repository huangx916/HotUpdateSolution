---@class UILabel.Overflow : System.Enum
---@field public ShrinkContent UILabel.Overflow @static
---@field public ClampContent UILabel.Overflow @static
---@field public ResizeFreely UILabel.Overflow @static
---@field public ResizeHeight UILabel.Overflow @static
---@field public value__ number
local m = {}

UILabel.Overflow = m
return m
