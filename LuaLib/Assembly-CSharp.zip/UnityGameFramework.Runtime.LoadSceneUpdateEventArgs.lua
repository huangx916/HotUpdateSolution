---@class UnityGameFramework.Runtime.LoadSceneUpdateEventArgs : GameFramework.Event.GameEventArgs
---@field public Id number
---@field public SceneAssetName string
---@field public Progress number
---@field public UserData any
local m = {}

UnityGameFramework.Runtime.LoadSceneUpdateEventArgs = m
return m
