---@class UnityGameFramework.Runtime.VarGameObject : GameFramework.Variable_1_UnityEngine_GameObject_
local m = {}

---@overload fun(value:UnityGameFramework.Runtime.VarGameObject):UnityEngine.GameObject @static
---@static
---@param value UnityEngine.GameObject
---@return UnityGameFramework.Runtime.VarGameObject
function m.op_Implicit(value) end

UnityGameFramework.Runtime.VarGameObject = m
return m
