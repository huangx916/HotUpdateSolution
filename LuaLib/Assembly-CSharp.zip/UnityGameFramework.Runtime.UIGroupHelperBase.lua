---@class UnityGameFramework.Runtime.UIGroupHelperBase : UnityEngine.MonoBehaviour
local m = {}

---@abstract
---@param depth number
function m:SetDepth(depth) end

UnityGameFramework.Runtime.UIGroupHelperBase = m
return m
