---@class UnityGameFramework.Runtime.WebRequestStartEventArgs : GameFramework.Event.GameEventArgs
---@field public Id number
---@field public SerialId number
---@field public WebRequestUri string
---@field public UserData any
local m = {}

UnityGameFramework.Runtime.WebRequestStartEventArgs = m
return m
