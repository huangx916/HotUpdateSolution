---@class UnityGameFramework.Runtime.DebuggerComponent.ProfilerInformationWindow : UnityGameFramework.Runtime.DebuggerComponent.ScrollableDebuggerWindowBase
local m = {}

UnityGameFramework.Runtime.DebuggerComponent.ProfilerInformationWindow = m
return m
