---@class UnityGameFramework.Runtime.SoundHelperBase : UnityEngine.MonoBehaviour
local m = {}

---@abstract
---@param soundAsset any
function m:ReleaseSoundAsset(soundAsset) end

UnityGameFramework.Runtime.SoundHelperBase = m
return m
