---@class UnityGameFramework.Runtime.DebuggerComponent.InputAccelerationInformationWindow : UnityGameFramework.Runtime.DebuggerComponent.ScrollableDebuggerWindowBase
local m = {}

UnityGameFramework.Runtime.DebuggerComponent.InputAccelerationInformationWindow = m
return m
