---@class PlayIdleAnimations : UnityEngine.MonoBehaviour
local m = {}

PlayIdleAnimations = m
return m
