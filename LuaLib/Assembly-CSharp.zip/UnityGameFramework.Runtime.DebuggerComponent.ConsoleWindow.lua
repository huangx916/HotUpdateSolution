---@class UnityGameFramework.Runtime.DebuggerComponent.ConsoleWindow : System.Object
---@field public LockScroll boolean
---@field public MaxLine number
---@field public DateTimeFormat string
---@field public InfoFilter boolean
---@field public WarningFilter boolean
---@field public ErrorFilter boolean
---@field public FatalFilter boolean
---@field public InfoCount number
---@field public WarningCount number
---@field public ErrorCount number
---@field public FatalCount number
---@field public InfoColor UnityEngine.Color32
---@field public WarningColor UnityEngine.Color32
---@field public ErrorColor UnityEngine.Color32
---@field public FatalColor UnityEngine.Color32
local m = {}

---@overload fun() @virtual
---@virtual
---@param args any[]|any
function m:Initialize(args) end

---@virtual
function m:Shutdown() end

---@virtual
function m:OnEnter() end

---@virtual
function m:OnLeave() end

---@virtual
---@param elapseSeconds number
---@param realElapseSeconds number
function m:OnUpdate(elapseSeconds, realElapseSeconds) end

---@virtual
function m:OnDraw() end

function m:RefreshCount() end

UnityGameFramework.Runtime.DebuggerComponent.ConsoleWindow = m
return m
