---@class TweenMaterialColor : UITweener
---@field public from UnityEngine.Color
---@field public to UnityEngine.Color
---@field public colorName string
---@field public color UnityEngine.Color
---@field public value UnityEngine.Color
local m = {}

---@static
---@param go UnityEngine.GameObject
---@param duration number
---@param color UnityEngine.Color
---@return TweenMaterialColor
function m.Begin(go, duration, color) end

---@virtual
function m:SetStartToCurrentValue() end

---@virtual
function m:SetEndToCurrentValue() end

TweenMaterialColor = m
return m
