---@class UIStretch : UnityEngine.MonoBehaviour
---@field public uiCamera UnityEngine.Camera
---@field public container UnityEngine.GameObject
---@field public style UIStretch.Style
---@field public runOnlyOnce boolean
---@field public relativeSize UnityEngine.Vector2
---@field public initialSize UnityEngine.Vector2
---@field public borderPadding UnityEngine.Vector2
local m = {}

UIStretch = m
return m
