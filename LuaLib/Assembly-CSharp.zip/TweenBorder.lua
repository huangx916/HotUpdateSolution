---@class TweenBorder : UITweener
---@field public from UnityEngine.Vector4
---@field public to UnityEngine.Vector4
---@field public border UnityEngine.Vector4
---@field public value UnityEngine.Vector4
local m = {}

---@static
---@param go UnityEngine.GameObject
---@param duration number
---@param border UnityEngine.Vector4
---@return TweenBorder
function m.Begin(go, duration, border) end

---@virtual
function m:SetStartToCurrentValue() end

---@virtual
function m:SetEndToCurrentValue() end

TweenBorder = m
return m
