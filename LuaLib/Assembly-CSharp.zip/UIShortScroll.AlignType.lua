---@class UIShortScroll.AlignType : System.Enum
---@field public AT_Forward UIShortScroll.AlignType @static
---@field public AT_Center UIShortScroll.AlignType @static
---@field public AT_Backward UIShortScroll.AlignType @static
---@field public value__ number
local m = {}

UIShortScroll.AlignType = m
return m
