---@class UIEffect : UIBlank
---@field public drawCall UIDrawCall
local m = {}

---@param newDepth number
function m:SetDepth(newDepth) end

UIEffect = m
return m
