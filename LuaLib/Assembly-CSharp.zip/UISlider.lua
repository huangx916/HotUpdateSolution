---@class UISlider : UIProgressBar
---@field public isColliderEnabled boolean
---@field public sliderValue number
---@field public inverted boolean
local m = {}

---@virtual
---@param delta UnityEngine.Vector2
function m:OnPan(delta) end

UISlider = m
return m
