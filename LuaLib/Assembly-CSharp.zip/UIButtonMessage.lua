---@class UIButtonMessage : UnityEngine.MonoBehaviour
---@field public target UnityEngine.GameObject
---@field public functionName string
---@field public trigger UIButtonMessage.Trigger
---@field public includeChildren boolean
local m = {}

UIButtonMessage = m
return m
