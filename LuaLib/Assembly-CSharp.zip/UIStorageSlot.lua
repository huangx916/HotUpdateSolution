---@class UIStorageSlot : UIItemSlot
---@field public storage UIItemStorage
---@field public slot number
local m = {}

UIStorageSlot = m
return m
