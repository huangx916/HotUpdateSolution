---@class UnityGameFramework.Runtime.PlaySoundSuccessEventArgs : GameFramework.Event.GameEventArgs
---@field public Id number
---@field public SerialId number
---@field public SoundAssetName string
---@field public SoundAgent GameFramework.Sound.ISoundAgent
---@field public Duration number
---@field public BindingEntity UnityGameFramework.Runtime.Entity
---@field public UserData any
local m = {}

UnityGameFramework.Runtime.PlaySoundSuccessEventArgs = m
return m
