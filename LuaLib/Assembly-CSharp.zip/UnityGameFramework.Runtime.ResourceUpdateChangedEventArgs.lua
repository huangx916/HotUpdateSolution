---@class UnityGameFramework.Runtime.ResourceUpdateChangedEventArgs : GameFramework.Event.GameEventArgs
---@field public Id number
---@field public Name string
---@field public DownloadPath string
---@field public DownloadUri string
---@field public CurrentLength number
---@field public ZipLength number
local m = {}

UnityGameFramework.Runtime.ResourceUpdateChangedEventArgs = m
return m
