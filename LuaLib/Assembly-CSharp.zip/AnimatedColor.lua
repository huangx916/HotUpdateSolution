---@class AnimatedColor : UnityEngine.MonoBehaviour
---@field public color UnityEngine.Color
local m = {}

AnimatedColor = m
return m
