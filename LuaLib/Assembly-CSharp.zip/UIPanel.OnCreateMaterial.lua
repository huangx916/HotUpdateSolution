---@class UIPanel.OnCreateMaterial : System.MulticastDelegate
local m = {}

---@virtual
---@param widget UIWidget
---@param mat UnityEngine.Material
---@return UnityEngine.Material
function m:Invoke(widget, mat) end

---@virtual
---@param widget UIWidget
---@param mat UnityEngine.Material
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(widget, mat, callback, object) end

---@virtual
---@param result System.IAsyncResult
---@return UnityEngine.Material
function m:EndInvoke(result) end

UIPanel.OnCreateMaterial = m
return m
