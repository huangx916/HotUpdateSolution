---@class UnityGameFramework.Runtime.VarUShort : GameFramework.Variable_1_System_UInt16_
local m = {}

---@overload fun(value:UnityGameFramework.Runtime.VarUShort):number @static
---@static
---@param value number
---@return UnityGameFramework.Runtime.VarUShort
function m.op_Implicit(value) end

UnityGameFramework.Runtime.VarUShort = m
return m
