---@class UnityGameFramework.Runtime.VarString : GameFramework.Variable_1_System_String_
local m = {}

---@overload fun(value:UnityGameFramework.Runtime.VarString):string @static
---@static
---@param value string
---@return UnityGameFramework.Runtime.VarString
function m.op_Implicit(value) end

UnityGameFramework.Runtime.VarString = m
return m
