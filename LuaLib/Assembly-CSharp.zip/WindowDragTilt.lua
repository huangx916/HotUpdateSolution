---@class WindowDragTilt : UnityEngine.MonoBehaviour
---@field public updateOrder number
---@field public degrees number
local m = {}

WindowDragTilt = m
return m
