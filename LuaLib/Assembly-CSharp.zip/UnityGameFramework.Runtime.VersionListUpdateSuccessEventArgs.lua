---@class UnityGameFramework.Runtime.VersionListUpdateSuccessEventArgs : GameFramework.Event.GameEventArgs
---@field public Id number
---@field public DownloadPath string
---@field public DownloadUri string
local m = {}

UnityGameFramework.Runtime.VersionListUpdateSuccessEventArgs = m
return m
