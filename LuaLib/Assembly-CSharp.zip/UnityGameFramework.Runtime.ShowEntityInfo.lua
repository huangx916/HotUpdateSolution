---@class UnityGameFramework.Runtime.ShowEntityInfo : System.Object
---@field public EntityLogicType System.Type
---@field public UserData any
local m = {}

UnityGameFramework.Runtime.ShowEntityInfo = m
return m
