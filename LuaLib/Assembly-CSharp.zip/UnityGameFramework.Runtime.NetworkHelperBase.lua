---@class UnityGameFramework.Runtime.NetworkHelperBase : UnityEngine.MonoBehaviour
local m = {}

---@abstract
---@param networkChannel GameFramework.Network.INetworkChannel
---@return boolean
function m:SendHeartBeat(networkChannel) end

---@abstract
---@param networkChannel GameFramework.Network.INetworkChannel
---@param destination System.IO.Stream
---@param packet GameFramework.Network.Packet
function m:Serialize(networkChannel, destination, packet) end

---@abstract
---@param networkChannel GameFramework.Network.INetworkChannel
---@param source System.IO.Stream
---@return GameFramework.Network.Packet, System.Object
function m:Deserialize(networkChannel, source) end

UnityGameFramework.Runtime.NetworkHelperBase = m
return m
