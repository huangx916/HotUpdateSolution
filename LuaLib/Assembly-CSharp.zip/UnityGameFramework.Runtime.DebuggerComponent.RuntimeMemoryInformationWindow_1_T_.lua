---@class UnityGameFramework.Runtime.DebuggerComponent.RuntimeMemoryInformationWindow_1_T_ : UnityGameFramework.Runtime.DebuggerComponent.ScrollableDebuggerWindowBase
local m = {}

UnityGameFramework.Runtime.DebuggerComponent.RuntimeMemoryInformationWindow_1_T_ = m
return m
