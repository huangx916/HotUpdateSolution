---@class UIKeyNavigation : UnityEngine.MonoBehaviour
---@field public list BetterList_1_UIKeyNavigation_ @static
---@field public mLastFrame number @static
---@field public current UIKeyNavigation @static
---@field public constraint UIKeyNavigation.Constraint
---@field public onUp UnityEngine.GameObject
---@field public onDown UnityEngine.GameObject
---@field public onLeft UnityEngine.GameObject
---@field public onRight UnityEngine.GameObject
---@field public onClick UnityEngine.GameObject
---@field public onTab UnityEngine.GameObject
---@field public startsSelected boolean
---@field public isColliderEnabled boolean
local m = {}

---@return UnityEngine.GameObject
function m:GetLeft() end

---@return UnityEngine.GameObject
function m:GetRight() end

---@return UnityEngine.GameObject
function m:GetUp() end

---@return UnityEngine.GameObject
function m:GetDown() end

---@overload fun(myDir:UnityEngine.Vector3, x:number):UnityEngine.GameObject
---@overload fun(myDir:UnityEngine.Vector3):UnityEngine.GameObject
---@param myDir UnityEngine.Vector3
---@param x number
---@param y number
---@return UnityEngine.GameObject
function m:Get(myDir, x, y) end

---@virtual
---@param key UnityEngine.KeyCode
function m:OnNavigate(key) end

---@virtual
---@param key UnityEngine.KeyCode
function m:OnKey(key) end

UIKeyNavigation = m
return m
