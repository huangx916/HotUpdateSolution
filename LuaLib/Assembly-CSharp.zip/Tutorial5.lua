---@class Tutorial5 : UnityEngine.MonoBehaviour
local m = {}

function m:SetDurationToCurrentProgress() end

Tutorial5 = m
return m
