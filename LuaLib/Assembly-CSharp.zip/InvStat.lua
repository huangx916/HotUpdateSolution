---@class InvStat : System.Object
---@field public id InvStat.Identifier
---@field public modifier InvStat.Modifier
---@field public amount number
local m = {}

---@static
---@param i InvStat.Identifier
---@return string
function m.GetName(i) end

---@static
---@param i InvStat.Identifier
---@return string
function m.GetDescription(i) end

---@static
---@param a InvStat
---@param b InvStat
---@return number
function m.CompareArmor(a, b) end

---@static
---@param a InvStat
---@param b InvStat
---@return number
function m.CompareWeapon(a, b) end

InvStat = m
return m
