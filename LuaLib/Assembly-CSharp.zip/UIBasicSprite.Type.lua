---@class UIBasicSprite.Type : System.Enum
---@field public Simple UIBasicSprite.Type @static
---@field public Sliced UIBasicSprite.Type @static
---@field public Tiled UIBasicSprite.Type @static
---@field public Filled UIBasicSprite.Type @static
---@field public Advanced UIBasicSprite.Type @static
---@field public value__ number
local m = {}

UIBasicSprite.Type = m
return m
