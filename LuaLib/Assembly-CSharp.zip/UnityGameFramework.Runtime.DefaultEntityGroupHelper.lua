---@class UnityGameFramework.Runtime.DefaultEntityGroupHelper : UnityGameFramework.Runtime.EntityGroupHelperBase
local m = {}

UnityGameFramework.Runtime.DefaultEntityGroupHelper = m
return m
