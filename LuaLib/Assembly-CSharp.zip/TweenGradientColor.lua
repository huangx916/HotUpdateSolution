---@class TweenGradientColor : UITweener
---@field public gradient UnityEngine.Gradient
---@field public value UnityEngine.Color
local m = {}

---@static
---@param go UnityEngine.GameObject
---@param duration number
---@param gradient UnityEngine.Gradient
---@return TweenGradientColor
function m.Begin(go, duration, gradient) end

TweenGradientColor = m
return m
