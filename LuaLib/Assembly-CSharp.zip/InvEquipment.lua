---@class InvEquipment : UnityEngine.MonoBehaviour
---@field public equippedItems InvGameItem[]
local m = {}

---@param slot InvBaseItem.Slot
---@param item InvGameItem
---@return InvGameItem
function m:Replace(slot, item) end

---@param item InvGameItem
---@return InvGameItem
function m:Equip(item) end

---@overload fun(slot:InvBaseItem.Slot):InvGameItem
---@param item InvGameItem
---@return InvGameItem
function m:Unequip(item) end

---@overload fun(slot:InvBaseItem.Slot):boolean
---@param item InvGameItem
---@return boolean
function m:HasEquipped(item) end

---@param slot InvBaseItem.Slot
---@return InvGameItem
function m:GetItem(slot) end

InvEquipment = m
return m
