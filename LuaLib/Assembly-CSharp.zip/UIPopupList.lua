---@class UIPopupList : UIWidgetContainer
---@field public current UIPopupList @static
---@field public isOpen boolean @static
---@field public atlas UIAtlas
---@field public bitmapFont UIFont
---@field public trueTypeFont UnityEngine.Font
---@field public fontSize number
---@field public fontStyle UnityEngine.FontStyle
---@field public backgroundSprite string
---@field public highlightSprite string
---@field public background2DSprite UnityEngine.Sprite
---@field public highlight2DSprite UnityEngine.Sprite
---@field public position UIPopupList.Position
---@field public selection UIPopupList.Selection
---@field public alignment NGUIText.Alignment
---@field public items string[]
---@field public itemData any[]
---@field public padding UnityEngine.Vector2
---@field public textColor UnityEngine.Color
---@field public backgroundColor UnityEngine.Color
---@field public highlightColor UnityEngine.Color
---@field public isAnimated boolean
---@field public isLocalized boolean
---@field public textModifier UILabel.Modifier
---@field public separatePanel boolean
---@field public overlap number
---@field public openOn UIPopupList.OpenOn
---@field public onChange EventDelegate[]
---@field public keepValue boolean
---@field public startingPosition UnityEngine.Vector3
---@field public source UnityEngine.GameObject
---@field public ambigiousFont UnityEngine.Object
---@field public onSelectionChange fun(val:string)
---@field public value string
---@field public data any
---@field public isColliderEnabled boolean
local m = {}

---@overload fun(value:string)
---@param value string
---@param notify boolean
function m:Set(value, notify) end

---@virtual
function m:Clear() end

---@overload fun(text:string, data:any) @virtual
---@virtual
---@param text string
function m:AddItem(text) end

---@virtual
---@param text string
function m:RemoveItem(text) end

---@virtual
---@param data any
function m:RemoveItemByData(data) end

---@virtual
function m:Start() end

---@static
function m.Close() end

---@virtual
function m:CloseSelf() end

---@virtual
function m:Show() end

UIPopupList = m
return m
