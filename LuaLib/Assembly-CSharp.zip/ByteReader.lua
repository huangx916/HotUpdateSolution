---@class ByteReader : System.Object
---@field public canRead boolean
local m = {}

---@static
---@param path string
---@return ByteReader
function m.Open(path) end

---@overload fun(skipEmptyLines:boolean):string
---@return string
function m:ReadLine() end

---@return System.Collections.Generic.Dictionary_2_System_String_System_String_
function m:ReadDictionary() end

---@return BetterList_1_System_String_
function m:ReadCSV() end

ByteReader = m
return m
