---@class MinMaxRangeAttribute : UnityEngine.PropertyAttribute
---@field public minLimit number
---@field public maxLimit number
local m = {}

MinMaxRangeAttribute = m
return m
