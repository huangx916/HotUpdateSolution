---@class UnityGameFramework.Runtime.AttachEntityInfo : System.Object
---@field public ParentTransform UnityEngine.Transform
---@field public UserData any
local m = {}

UnityGameFramework.Runtime.AttachEntityInfo = m
return m
