---@class UnityGameFramework.Runtime.ZipHelper : System.Object
local m = {}

---@virtual
---@param bytes string
---@return string
function m:Compress(bytes) end

---@virtual
---@param bytes string
---@return string
function m:Decompress(bytes) end

UnityGameFramework.Runtime.ZipHelper = m
return m
