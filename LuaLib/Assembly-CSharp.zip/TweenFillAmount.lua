---@class TweenFillAmount : UITweener
---@field public from number
---@field public to number
---@field public fillAmount number
---@field public value number
local m = {}

---@static
---@param go UnityEngine.GameObject
---@param duration number
---@param fill number
---@return TweenFillAmount
function m.Begin(go, duration, fill) end

---@virtual
function m:SetStartToCurrentValue() end

---@virtual
function m:SetEndToCurrentValue() end

TweenFillAmount = m
return m
