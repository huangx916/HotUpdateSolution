---@class UnityGameFramework.Runtime.DebuggerComponent.ScreenInformationWindow : UnityGameFramework.Runtime.DebuggerComponent.ScrollableDebuggerWindowBase
local m = {}

UnityGameFramework.Runtime.DebuggerComponent.ScreenInformationWindow = m
return m
