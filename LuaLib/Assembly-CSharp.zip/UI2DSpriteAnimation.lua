---@class UI2DSpriteAnimation : UnityEngine.MonoBehaviour
---@field public frameIndex number
---@field public ignoreTimeScale boolean
---@field public loop boolean
---@field public frames UnityEngine.Sprite[]
---@field public isPlaying boolean
---@field public framesPerSecond number
local m = {}

function m:Play() end

function m:Pause() end

function m:ResetToBeginning() end

UI2DSpriteAnimation = m
return m
