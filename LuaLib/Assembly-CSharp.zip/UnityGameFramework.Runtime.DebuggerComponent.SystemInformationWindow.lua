---@class UnityGameFramework.Runtime.DebuggerComponent.SystemInformationWindow : UnityGameFramework.Runtime.DebuggerComponent.ScrollableDebuggerWindowBase
local m = {}

UnityGameFramework.Runtime.DebuggerComponent.SystemInformationWindow = m
return m
