---@class UIScrollBar.Direction : System.Enum
---@field public Horizontal UIScrollBar.Direction @static
---@field public Vertical UIScrollBar.Direction @static
---@field public Upgraded UIScrollBar.Direction @static
---@field public value__ number
local m = {}

UIScrollBar.Direction = m
return m
