---@class UIKeyBinding.Modifier : System.Enum
---@field public Any UIKeyBinding.Modifier @static
---@field public Shift UIKeyBinding.Modifier @static
---@field public Control UIKeyBinding.Modifier @static
---@field public Alt UIKeyBinding.Modifier @static
---@field public None UIKeyBinding.Modifier @static
---@field public value__ number
local m = {}

UIKeyBinding.Modifier = m
return m
