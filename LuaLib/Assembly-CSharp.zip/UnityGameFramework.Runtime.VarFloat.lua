---@class UnityGameFramework.Runtime.VarFloat : GameFramework.Variable_1_System_Single_
local m = {}

---@overload fun(value:UnityGameFramework.Runtime.VarFloat):number @static
---@static
---@param value number
---@return UnityGameFramework.Runtime.VarFloat
function m.op_Implicit(value) end

UnityGameFramework.Runtime.VarFloat = m
return m
