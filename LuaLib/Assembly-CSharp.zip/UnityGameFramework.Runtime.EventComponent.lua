---@class UnityGameFramework.Runtime.EventComponent : UnityGameFramework.Runtime.GameFrameworkComponent
---@field public Count number
local m = {}

---@param id UnityGameFramework.Runtime.EventId
---@param handler fun(sender:any, e:GameFramework.Event.GameEventArgs)
---@return boolean
function m:Check(id, handler) end

---@param id UnityGameFramework.Runtime.EventId
---@param handler fun(sender:any, e:GameFramework.Event.GameEventArgs)
function m:Subscribe(id, handler) end

---@param id UnityGameFramework.Runtime.EventId
---@param handler fun(sender:any, e:GameFramework.Event.GameEventArgs)
function m:Unsubscribe(id, handler) end

---@param sender any
---@param e GameFramework.Event.GameEventArgs
function m:Fire(sender, e) end

---@param sender any
---@param e GameFramework.Event.GameEventArgs
function m:FireNow(sender, e) end

UnityGameFramework.Runtime.EventComponent = m
return m
