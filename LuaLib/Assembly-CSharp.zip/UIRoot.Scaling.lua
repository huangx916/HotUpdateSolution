---@class UIRoot.Scaling : System.Enum
---@field public Flexible UIRoot.Scaling @static
---@field public Constrained UIRoot.Scaling @static
---@field public ConstrainedOnMobiles UIRoot.Scaling @static
---@field public value__ number
local m = {}

UIRoot.Scaling = m
return m
