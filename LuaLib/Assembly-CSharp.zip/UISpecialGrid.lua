---@class UISpecialGrid : UIGrid
local m = {}

---@virtual
---@return UnityEngine.Transform[]
function m:GetChildList() end

UISpecialGrid = m
return m
