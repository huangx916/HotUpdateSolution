---@class UnityGameFramework.Runtime.OpenUIFormDependencyAssetEventArgs : GameFramework.Event.GameEventArgs
---@field public Id number
---@field public SerialId number
---@field public UIFormAssetName string
---@field public UIGroupName string
---@field public PauseCoveredUIForm boolean
---@field public DependencyAssetName string
---@field public LoadedCount number
---@field public TotalCount number
---@field public UserData any
local m = {}

UnityGameFramework.Runtime.OpenUIFormDependencyAssetEventArgs = m
return m
