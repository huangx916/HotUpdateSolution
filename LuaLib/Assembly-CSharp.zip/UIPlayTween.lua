---@class UIPlayTween : UnityEngine.MonoBehaviour
---@field public current UIPlayTween @static
---@field public tweenTarget UnityEngine.GameObject
---@field public tweenGroup number
---@field public trigger AnimationOrTween.Trigger
---@field public playDirection AnimationOrTween.Direction
---@field public resetOnPlay boolean
---@field public resetIfDisabled boolean
---@field public ifDisabledOnPlay AnimationOrTween.EnableCondition
---@field public disableWhenFinished AnimationOrTween.DisableCondition
---@field public includeChildren boolean
---@field public onFinished EventDelegate[]
local m = {}

---@param forward boolean
function m:Play(forward) end

UIPlayTween = m
return m
