---@class UIAtlas : UnityEngine.MonoBehaviour
---@field public width number
---@field public height number
---@field public spriteMaterial UnityEngine.Material
---@field public premultipliedAlpha boolean
---@field public spriteList UISpriteData[]
---@field public texture UnityEngine.Texture
---@field public alphaTexture UnityEngine.Texture
---@field public pixelSize number
---@field public replacement UIAtlas
local m = {}

---@param tex UnityEngine.Texture
function m:InitSize(tex) end

---@param name string
---@return UISpriteData
function m:GetSprite(name) end

---@param startsWith string
---@return string
function m:GetRandomSprite(startsWith) end

function m:MarkSpriteListAsChanged() end

function m:SortAlphabetically() end

---@overload fun(match:string):BetterList_1_System_String_
---@return BetterList_1_System_String_
function m:GetListOfSprites() end

---@static
---@param a UIAtlas
---@param b UIAtlas
---@return boolean
function m.CheckIfRelated(a, b) end

function m:MarkAsChanged() end

UIAtlas = m
return m
