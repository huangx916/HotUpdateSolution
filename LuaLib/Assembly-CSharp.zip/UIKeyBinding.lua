---@class UIKeyBinding : UnityEngine.MonoBehaviour
---@field public keyCode UnityEngine.KeyCode
---@field public modifier UIKeyBinding.Modifier
---@field public action UIKeyBinding.Action
---@field public captionText string
local m = {}

---@static
---@param key UnityEngine.KeyCode
---@return boolean
function m.IsBound(key) end

---@static
---@param modifier UIKeyBinding.Modifier
---@return boolean
function m.IsModifierActive(modifier) end

---@virtual
---@return string
function m:ToString() end

---@static
---@param keyCode UnityEngine.KeyCode
---@param modifier UIKeyBinding.Modifier
---@return string
function m.GetString(keyCode, modifier) end

---@static
---@param text string
---@return boolean, UnityEngine.KeyCode, UIKeyBinding.Modifier
function m.GetKeyCode(text) end

---@static
---@return UIKeyBinding.Modifier
function m.GetActiveModifier() end

UIKeyBinding = m
return m
