---@class UnityGameFramework.Runtime.DefaultUIGroupHelper : UnityGameFramework.Runtime.UIGroupHelperBase
local m = {}

---@virtual
---@param depth number
function m:SetDepth(depth) end

UnityGameFramework.Runtime.DefaultUIGroupHelper = m
return m
