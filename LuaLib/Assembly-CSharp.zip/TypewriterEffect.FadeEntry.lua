---@class TypewriterEffect.FadeEntry : System.ValueType
---@field public index number
---@field public text string
---@field public alpha number
local m = {}

TypewriterEffect.FadeEntry = m
return m
