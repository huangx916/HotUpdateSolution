---@class UnityGameFramework.Runtime.VarUInt : GameFramework.Variable_1_System_UInt32_
local m = {}

---@overload fun(value:UnityGameFramework.Runtime.VarUInt):number @static
---@static
---@param value number
---@return UnityGameFramework.Runtime.VarUInt
function m.op_Implicit(value) end

UnityGameFramework.Runtime.VarUInt = m
return m
