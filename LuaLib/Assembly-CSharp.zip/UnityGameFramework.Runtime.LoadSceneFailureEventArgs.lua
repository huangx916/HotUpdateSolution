---@class UnityGameFramework.Runtime.LoadSceneFailureEventArgs : GameFramework.Event.GameEventArgs
---@field public Id number
---@field public SceneAssetName string
---@field public ErrorMessage string
---@field public UserData any
local m = {}

UnityGameFramework.Runtime.LoadSceneFailureEventArgs = m
return m
