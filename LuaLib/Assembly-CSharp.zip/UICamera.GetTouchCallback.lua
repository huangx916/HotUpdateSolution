---@class UICamera.GetTouchCallback : System.MulticastDelegate
local m = {}

---@virtual
---@param index number
---@return UICamera.Touch
function m:Invoke(index) end

---@virtual
---@param index number
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(index, callback, object) end

---@virtual
---@param result System.IAsyncResult
---@return UICamera.Touch
function m:EndInvoke(result) end

UICamera.GetTouchCallback = m
return m
