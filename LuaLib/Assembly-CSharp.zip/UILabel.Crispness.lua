---@class UILabel.Crispness : System.Enum
---@field public Never UILabel.Crispness @static
---@field public OnDesktop UILabel.Crispness @static
---@field public Always UILabel.Crispness @static
---@field public value__ number
local m = {}

UILabel.Crispness = m
return m
