---@class UnityGameFramework.Runtime.DataTableHelperBase : UnityEngine.MonoBehaviour
local m = {}

---@overload fun(dataTableName:string, dataTableType:System.Type, dataTableNameInType:string, dataTableAsset:any, userData:any):boolean @abstract
---@virtual
---@param dataTableAsset any
---@param userData any
---@return boolean
function m:LoadDataTable(dataTableAsset, userData) end

---@abstract
---@param text string
---@return string[]
function m:SplitToDataRows(text) end

---@abstract
---@param dataTableAsset any
function m:ReleaseDataTableAsset(dataTableAsset) end

UnityGameFramework.Runtime.DataTableHelperBase = m
return m
