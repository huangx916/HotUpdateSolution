---@class UIForwardEvents : UnityEngine.MonoBehaviour
---@field public target UnityEngine.GameObject
---@field public onHover boolean
---@field public onPress boolean
---@field public onClick boolean
---@field public onDoubleClick boolean
---@field public onSelect boolean
---@field public onDrag boolean
---@field public onDrop boolean
---@field public onSubmit boolean
---@field public onScroll boolean
local m = {}

UIForwardEvents = m
return m
