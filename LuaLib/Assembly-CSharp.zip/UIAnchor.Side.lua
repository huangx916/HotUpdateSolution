---@class UIAnchor.Side : System.Enum
---@field public BottomLeft UIAnchor.Side @static
---@field public Left UIAnchor.Side @static
---@field public TopLeft UIAnchor.Side @static
---@field public Top UIAnchor.Side @static
---@field public TopRight UIAnchor.Side @static
---@field public Right UIAnchor.Side @static
---@field public BottomRight UIAnchor.Side @static
---@field public Bottom UIAnchor.Side @static
---@field public Center UIAnchor.Side @static
---@field public value__ number
local m = {}

UIAnchor.Side = m
return m
