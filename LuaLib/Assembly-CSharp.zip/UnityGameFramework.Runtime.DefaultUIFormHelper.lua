---@class UnityGameFramework.Runtime.DefaultUIFormHelper : UnityGameFramework.Runtime.UIFormHelperBase
local m = {}

---@virtual
---@param uiFormAsset any
---@return any
function m:InstantiateUIForm(uiFormAsset) end

---@virtual
---@param uiFormInstance any
---@param uiGroup GameFramework.UI.IUIGroup
---@param userData any
---@return GameFramework.UI.IUIForm
function m:CreateUIForm(uiFormInstance, uiGroup, userData) end

---@virtual
---@param uiFormAsset any
---@param uiFormInstance any
function m:ReleaseUIForm(uiFormAsset, uiFormInstance) end

UnityGameFramework.Runtime.DefaultUIFormHelper = m
return m
