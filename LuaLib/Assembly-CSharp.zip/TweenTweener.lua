---@class TweenTweener : UITweener
---@field public from number
---@field public to number
---@field public Factor number
---@field public value number
local m = {}

---@static
---@param go UnityEngine.GameObject
---@param duration number
---@param tweener number
---@return TweenTweener
function m.Begin(go, duration, tweener) end

---@virtual
function m:SetStartToCurrentValue() end

---@virtual
function m:SetEndToCurrentValue() end

TweenTweener = m
return m
