---@class TweenLetters.AnimationProperties : System.Object
---@field public animationOrder TweenLetters.AnimationLetterOrder
---@field public overlap number
---@field public randomDurations boolean
---@field public randomness UnityEngine.Vector2
---@field public offsetRange UnityEngine.Vector2
---@field public pos UnityEngine.Vector3
---@field public rot UnityEngine.Vector3
---@field public scale UnityEngine.Vector3
---@field public alpha number
local m = {}

TweenLetters.AnimationProperties = m
return m
