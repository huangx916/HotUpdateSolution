---@class UnityGameFramework.Runtime.LoadDictionaryDependencyAssetEventArgs : GameFramework.Event.GameEventArgs
---@field public Id number
---@field public DictionaryName string
---@field public DictionaryAssetName string
---@field public DependencyAssetName string
---@field public LoadedCount number
---@field public TotalCount number
---@field public UserData any
local m = {}

UnityGameFramework.Runtime.LoadDictionaryDependencyAssetEventArgs = m
return m
