---@class Game.ProcedureLaunch : GameFramework.Procedure.ProcedureBase
local m = {}

Game.ProcedureLaunch = m
return m
