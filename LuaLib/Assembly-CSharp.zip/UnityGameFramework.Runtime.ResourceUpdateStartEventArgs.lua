---@class UnityGameFramework.Runtime.ResourceUpdateStartEventArgs : GameFramework.Event.GameEventArgs
---@field public Id number
---@field public Name string
---@field public DownloadPath string
---@field public DownloadUri string
---@field public CurrentLength number
---@field public ZipLength number
---@field public RetryCount number
local m = {}

UnityGameFramework.Runtime.ResourceUpdateStartEventArgs = m
return m
