---@class UIProgressColor : UnityEngine.MonoBehaviour
---@field public colors UIProgressColor.ProgressColor[]
local m = {}

UIProgressColor = m
return m
