---@class UnityGameFramework.Runtime.WebRequestAgentHelperBase : UnityEngine.MonoBehaviour
local m = {}

---@abstract
---@param value fun(sender:any, e:GameFramework.WebRequest.WebRequestAgentHelperCompleteEventArgs)
function m:add_WebRequestAgentHelperComplete(value) end

---@abstract
---@param value fun(sender:any, e:GameFramework.WebRequest.WebRequestAgentHelperCompleteEventArgs)
function m:remove_WebRequestAgentHelperComplete(value) end

---@abstract
---@param value fun(sender:any, e:GameFramework.WebRequest.WebRequestAgentHelperErrorEventArgs)
function m:add_WebRequestAgentHelperError(value) end

---@abstract
---@param value fun(sender:any, e:GameFramework.WebRequest.WebRequestAgentHelperErrorEventArgs)
function m:remove_WebRequestAgentHelperError(value) end

---@overload fun(webRequestUri:string, postData:string, userData:any) @abstract
---@abstract
---@param webRequestUri string
---@param userData any
function m:Request(webRequestUri, userData) end

---@abstract
function m:Reset() end

UnityGameFramework.Runtime.WebRequestAgentHelperBase = m
return m
