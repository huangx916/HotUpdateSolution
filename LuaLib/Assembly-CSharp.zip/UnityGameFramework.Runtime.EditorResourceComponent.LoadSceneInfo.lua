---@class UnityGameFramework.Runtime.EditorResourceComponent.LoadSceneInfo : System.Object
---@field public AsyncOperation UnityEngine.AsyncOperation
---@field public SceneAssetName string
---@field public StartTime System.DateTime
---@field public LoadSceneCallbacks GameFramework.Resource.LoadSceneCallbacks
---@field public UserData any
local m = {}

UnityGameFramework.Runtime.EditorResourceComponent.LoadSceneInfo = m
return m
