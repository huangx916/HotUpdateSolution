---@class UnityGameFramework.Runtime.UnityWebRequestAgentHelper : UnityGameFramework.Runtime.WebRequestAgentHelperBase
local m = {}

---@virtual
---@param value fun(sender:any, e:GameFramework.WebRequest.WebRequestAgentHelperCompleteEventArgs)
function m:add_WebRequestAgentHelperComplete(value) end

---@virtual
---@param value fun(sender:any, e:GameFramework.WebRequest.WebRequestAgentHelperCompleteEventArgs)
function m:remove_WebRequestAgentHelperComplete(value) end

---@virtual
---@param value fun(sender:any, e:GameFramework.WebRequest.WebRequestAgentHelperErrorEventArgs)
function m:add_WebRequestAgentHelperError(value) end

---@virtual
---@param value fun(sender:any, e:GameFramework.WebRequest.WebRequestAgentHelperErrorEventArgs)
function m:remove_WebRequestAgentHelperError(value) end

---@overload fun(webRequestUri:string, postData:string, userData:any) @virtual
---@virtual
---@param webRequestUri string
---@param userData any
function m:Request(webRequestUri, userData) end

---@virtual
function m:Reset() end

---@virtual
function m:Dispose() end

UnityGameFramework.Runtime.UnityWebRequestAgentHelper = m
return m
