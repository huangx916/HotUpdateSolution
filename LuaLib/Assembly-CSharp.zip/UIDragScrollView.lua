---@class UIDragScrollView : UnityEngine.MonoBehaviour
---@field public scrollView UIScrollView
local m = {}

---@param delta UnityEngine.Vector2
function m:OnPan(delta) end

UIDragScrollView = m
return m
