---@class UIButtonMessage.Trigger : System.Enum
---@field public OnClick UIButtonMessage.Trigger @static
---@field public OnMouseOver UIButtonMessage.Trigger @static
---@field public OnMouseOut UIButtonMessage.Trigger @static
---@field public OnPress UIButtonMessage.Trigger @static
---@field public OnRelease UIButtonMessage.Trigger @static
---@field public OnDoubleClick UIButtonMessage.Trigger @static
---@field public value__ number
local m = {}

UIButtonMessage.Trigger = m
return m
