---@class UnityGameFramework.Runtime.DefaultSoundAgentHelper : UnityGameFramework.Runtime.SoundAgentHelperBase
---@field public IsPlaying boolean
---@field public Time number
---@field public Mute boolean
---@field public Loop boolean
---@field public Priority number
---@field public Volume number
---@field public Pitch number
---@field public PanStereo number
---@field public SpatialBlend number
---@field public MaxDistance number
---@field public AudioMixerGroup UnityEngine.Audio.AudioMixerGroup
local m = {}

---@virtual
---@param value fun(sender:any, e:GameFramework.Sound.ResetSoundAgentEventArgs)
function m:add_ResetSoundAgent(value) end

---@virtual
---@param value fun(sender:any, e:GameFramework.Sound.ResetSoundAgentEventArgs)
function m:remove_ResetSoundAgent(value) end

---@virtual
---@param fadeInSeconds number
function m:Play(fadeInSeconds) end

---@virtual
---@param fadeOutSeconds number
function m:Stop(fadeOutSeconds) end

---@virtual
---@param fadeOutSeconds number
function m:Pause(fadeOutSeconds) end

---@virtual
---@param fadeInSeconds number
function m:Resume(fadeInSeconds) end

---@virtual
function m:Reset() end

---@virtual
---@param soundAsset any
---@return boolean
function m:SetSoundAsset(soundAsset) end

---@virtual
---@param bindingEntity UnityGameFramework.Runtime.Entity
function m:SetBindingEntity(bindingEntity) end

---@virtual
---@param worldPosition UnityEngine.Vector3
function m:SetWorldPosition(worldPosition) end

UnityGameFramework.Runtime.DefaultSoundAgentHelper = m
return m
