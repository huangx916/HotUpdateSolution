---@class UnityGameFramework.Runtime.NetworkCustomErrorEventArgs : GameFramework.Event.GameEventArgs
---@field public Id number
---@field public NetworkChannel GameFramework.Network.INetworkChannel
---@field public CustomErrorData any
local m = {}

UnityGameFramework.Runtime.NetworkCustomErrorEventArgs = m
return m
