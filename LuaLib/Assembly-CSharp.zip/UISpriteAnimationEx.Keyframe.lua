---@class UISpriteAnimationEx.Keyframe : System.Object
---@field public frameIndex number
---@field public spriteName string
local m = {}

UISpriteAnimationEx.Keyframe = m
return m
