---@class UnityGameFramework.Runtime.LoadDataTableFailureEventArgs : GameFramework.Event.GameEventArgs
---@field public Id number
---@field public DataTableName string
---@field public DataTableType System.Type
---@field public DataTableAssetName string
---@field public ErrorMessage string
---@field public UserData any
local m = {}

UnityGameFramework.Runtime.LoadDataTableFailureEventArgs = m
return m
