---@class NGUIText.GlyphInfo : System.Object
---@field public v0 UnityEngine.Vector2
---@field public v1 UnityEngine.Vector2
---@field public u0 UnityEngine.Vector2
---@field public u1 UnityEngine.Vector2
---@field public u2 UnityEngine.Vector2
---@field public u3 UnityEngine.Vector2
---@field public advance number
---@field public channel number
local m = {}

NGUIText.GlyphInfo = m
return m
