---@class UnityGameFramework.Runtime.SceneComponent : UnityGameFramework.Runtime.GameFrameworkComponent
---@field public MainCamera UnityEngine.Camera
local m = {}

---@param sceneAssetName string
---@return boolean
function m:SceneIsLoaded(sceneAssetName) end

---@return string[]
function m:GetLoadedSceneAssetNames() end

---@param sceneAssetName string
---@return boolean
function m:SceneIsLoading(sceneAssetName) end

---@return string[]
function m:GetLoadingSceneAssetNames() end

---@param sceneAssetName string
---@return boolean
function m:SceneIsUnloading(sceneAssetName) end

---@return string[]
function m:GetUnloadingSceneAssetNames() end

---@overload fun(sceneAssetName:string, userData:any)
---@param sceneAssetName string
function m:LoadScene(sceneAssetName) end

---@overload fun(sceneAssetName:string, userData:any)
---@param sceneAssetName string
function m:UnloadScene(sceneAssetName) end

---@static
---@param sceneAssetName string
---@return string
function m.GetSceneName(sceneAssetName) end

UnityGameFramework.Runtime.SceneComponent = m
return m
