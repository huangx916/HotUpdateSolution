---@class UIDrawCall.Clipping : System.Enum
---@field public None UIDrawCall.Clipping @static
---@field public TextureMask UIDrawCall.Clipping @static
---@field public SoftClip UIDrawCall.Clipping @static
---@field public ConstrainButDontClip UIDrawCall.Clipping @static
---@field public value__ number
local m = {}

UIDrawCall.Clipping = m
return m
