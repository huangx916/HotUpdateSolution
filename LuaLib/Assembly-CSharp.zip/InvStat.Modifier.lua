---@class InvStat.Modifier : System.Enum
---@field public Added InvStat.Modifier @static
---@field public Percent InvStat.Modifier @static
---@field public value__ number
local m = {}

InvStat.Modifier = m
return m
