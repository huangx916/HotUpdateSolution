---@class UnityGameFramework.Runtime.DefaultDataTableHelper : UnityGameFramework.Runtime.DataTableHelperBase
local m = {}

---@virtual
---@param dataTableName string
---@param dataTableType System.Type
---@param dataTableNameInType string
---@param dataTableAsset any
---@param userData any
---@return boolean
function m:LoadDataTable(dataTableName, dataTableType, dataTableNameInType, dataTableAsset, userData) end

---@virtual
---@param text string
---@return string[]
function m:SplitToDataRows(text) end

---@virtual
---@param dataTableAsset any
function m:ReleaseDataTableAsset(dataTableAsset) end

UnityGameFramework.Runtime.DefaultDataTableHelper = m
return m
