---@class UIGeometry.OnCustomWrite : System.MulticastDelegate
local m = {}

---@virtual
---@param v UnityEngine.Vector3[]
---@param u UnityEngine.Vector2[]
---@param c UnityEngine.Color[]
---@param n UnityEngine.Vector3[]
---@param t UnityEngine.Vector4[]
---@param u2 UnityEngine.Vector4[]
function m:Invoke(v, u, c, n, t, u2) end

---@virtual
---@param v UnityEngine.Vector3[]
---@param u UnityEngine.Vector2[]
---@param c UnityEngine.Color[]
---@param n UnityEngine.Vector3[]
---@param t UnityEngine.Vector4[]
---@param u2 UnityEngine.Vector4[]
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(v, u, c, n, t, u2, callback, object) end

---@virtual
---@param result System.IAsyncResult
function m:EndInvoke(result) end

UIGeometry.OnCustomWrite = m
return m
