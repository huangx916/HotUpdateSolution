---@class TweenClipOffset : UITweener
---@field public from UnityEngine.Vector2
---@field public to UnityEngine.Vector2
---@field public clipOffset UnityEngine.Vector2
---@field public value UnityEngine.Vector2
local m = {}

---@static
---@param go UnityEngine.GameObject
---@param duration number
---@param clipOffset UnityEngine.Vector2
---@return TweenClipOffset
function m.Begin(go, duration, clipOffset) end

---@virtual
function m:SetStartToCurrentValue() end

---@virtual
function m:SetEndToCurrentValue() end

TweenClipOffset = m
return m
