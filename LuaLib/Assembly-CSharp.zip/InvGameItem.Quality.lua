---@class InvGameItem.Quality : System.Enum
---@field public Broken InvGameItem.Quality @static
---@field public Cursed InvGameItem.Quality @static
---@field public Damaged InvGameItem.Quality @static
---@field public Worn InvGameItem.Quality @static
---@field public Sturdy InvGameItem.Quality @static
---@field public Polished InvGameItem.Quality @static
---@field public Improved InvGameItem.Quality @static
---@field public Crafted InvGameItem.Quality @static
---@field public Superior InvGameItem.Quality @static
---@field public Enchanted InvGameItem.Quality @static
---@field public Epic InvGameItem.Quality @static
---@field public Legendary InvGameItem.Quality @static
---@field public _LastDoNotUse InvGameItem.Quality @static
---@field public value__ number
local m = {}

InvGameItem.Quality = m
return m
