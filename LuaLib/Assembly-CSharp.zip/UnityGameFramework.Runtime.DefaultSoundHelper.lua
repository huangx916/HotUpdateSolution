---@class UnityGameFramework.Runtime.DefaultSoundHelper : UnityGameFramework.Runtime.SoundHelperBase
local m = {}

---@virtual
---@param soundAsset any
function m:ReleaseSoundAsset(soundAsset) end

UnityGameFramework.Runtime.DefaultSoundHelper = m
return m
