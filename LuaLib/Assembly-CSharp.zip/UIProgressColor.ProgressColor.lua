---@class UIProgressColor.ProgressColor : System.ValueType
---@field public progress number
---@field public color UnityEngine.Color
local m = {}

UIProgressColor.ProgressColor = m
return m
