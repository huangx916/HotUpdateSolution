---@class UIRoot.Constraint : System.Enum
---@field public Fit UIRoot.Constraint @static
---@field public Fill UIRoot.Constraint @static
---@field public FitWidth UIRoot.Constraint @static
---@field public FitHeight UIRoot.Constraint @static
---@field public value__ number
local m = {}

UIRoot.Constraint = m
return m
