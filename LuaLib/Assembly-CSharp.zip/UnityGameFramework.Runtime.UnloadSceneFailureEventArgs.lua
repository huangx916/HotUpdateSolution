---@class UnityGameFramework.Runtime.UnloadSceneFailureEventArgs : GameFramework.Event.GameEventArgs
---@field public Id number
---@field public SceneAssetName string
---@field public UserData any
local m = {}

UnityGameFramework.Runtime.UnloadSceneFailureEventArgs = m
return m
