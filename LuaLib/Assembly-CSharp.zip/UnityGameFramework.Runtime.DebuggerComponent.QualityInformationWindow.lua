---@class UnityGameFramework.Runtime.DebuggerComponent.QualityInformationWindow : UnityGameFramework.Runtime.DebuggerComponent.ScrollableDebuggerWindowBase
local m = {}

UnityGameFramework.Runtime.DebuggerComponent.QualityInformationWindow = m
return m
