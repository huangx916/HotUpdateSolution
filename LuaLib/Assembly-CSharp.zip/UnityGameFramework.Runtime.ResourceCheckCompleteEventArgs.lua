---@class UnityGameFramework.Runtime.ResourceCheckCompleteEventArgs : GameFramework.Event.GameEventArgs
---@field public Id number
---@field public RemovedCount number
---@field public UpdateCount number
---@field public UpdateTotalLength number
---@field public UpdateTotalZipLength number
local m = {}

UnityGameFramework.Runtime.ResourceCheckCompleteEventArgs = m
return m
