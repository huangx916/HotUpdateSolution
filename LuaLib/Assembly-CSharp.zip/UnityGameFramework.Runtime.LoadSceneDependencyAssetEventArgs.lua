---@class UnityGameFramework.Runtime.LoadSceneDependencyAssetEventArgs : GameFramework.Event.GameEventArgs
---@field public Id number
---@field public SceneAssetName string
---@field public DependencyAssetName string
---@field public LoadedCount number
---@field public TotalCount number
---@field public UserData any
local m = {}

UnityGameFramework.Runtime.LoadSceneDependencyAssetEventArgs = m
return m
