---@class UnityGameFramework.Runtime.VarInt : GameFramework.Variable_1_System_Int32_
local m = {}

---@overload fun(value:UnityGameFramework.Runtime.VarInt):number @static
---@static
---@param value number
---@return UnityGameFramework.Runtime.VarInt
function m.op_Implicit(value) end

UnityGameFramework.Runtime.VarInt = m
return m
