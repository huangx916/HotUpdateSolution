---@class UnityGameFramework.Runtime.NetworkMissHeartBeatEventArgs : GameFramework.Event.GameEventArgs
---@field public Id number
---@field public NetworkChannel GameFramework.Network.INetworkChannel
---@field public MissCount number
local m = {}

UnityGameFramework.Runtime.NetworkMissHeartBeatEventArgs = m
return m
