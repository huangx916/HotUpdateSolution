---@class UnityGameFramework.Runtime.DebuggerComponent.GeneralSettingsWindow : UnityGameFramework.Runtime.DebuggerComponent.ScrollableDebuggerWindowBase
local m = {}

---@overload fun() @virtual
---@virtual
---@param args any[]|any
function m:Initialize(args) end

---@virtual
---@param elapseSeconds number
---@param realElapseSeconds number
function m:OnUpdate(elapseSeconds, realElapseSeconds) end

UnityGameFramework.Runtime.DebuggerComponent.GeneralSettingsWindow = m
return m
