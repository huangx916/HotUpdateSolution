---@class UnityGameFramework.Runtime.LoadSceneSuccessEventArgs : GameFramework.Event.GameEventArgs
---@field public Id number
---@field public SceneAssetName string
---@field public Duration number
---@field public UserData any
local m = {}

UnityGameFramework.Runtime.LoadSceneSuccessEventArgs = m
return m
