---@class PhysicsListener : UnityEngine.MonoBehaviour
---@field public listenerTag string
---@field public onTriggerEnter fun(arg1:UnityEngine.GameObject, arg2:UnityEngine.Collider)
---@field public onTriggerStay fun(arg1:UnityEngine.GameObject, arg2:UnityEngine.Collider)
---@field public onTriggerExit fun(arg1:UnityEngine.GameObject, arg2:UnityEngine.Collider)
---@field public onCollisionEnter fun(arg1:UnityEngine.GameObject, arg2:UnityEngine.Collision)
---@field public onCollisionStay fun(arg1:UnityEngine.GameObject, arg2:UnityEngine.Collision)
---@field public onCollisionExit fun(arg1:UnityEngine.GameObject, arg2:UnityEngine.Collision)
local m = {}

---@overload fun(go:UnityEngine.GameObject):PhysicsListener @static
---@overload fun(comp:UnityEngine.Component, listenerTag:string):PhysicsListener @static
---@overload fun(comp:UnityEngine.Component):PhysicsListener @static
---@static
---@param go UnityEngine.GameObject
---@param listenerTag string
---@return PhysicsListener
function m.Get(go, listenerTag) end

PhysicsListener = m
return m
