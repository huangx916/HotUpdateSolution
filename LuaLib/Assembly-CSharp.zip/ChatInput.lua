---@class ChatInput : UnityEngine.MonoBehaviour
---@field public textList UITextList
---@field public fillWithDummyData boolean
local m = {}

function m:OnSubmit() end

ChatInput = m
return m
