---@class UnityGameFramework.Runtime.DataNodeComponent : UnityGameFramework.Runtime.GameFrameworkComponent
---@field public Root GameFramework.DataNode.IDataNode
local m = {}

---@overload fun(path:string, node:GameFramework.DataNode.IDataNode):GameFramework.Variable
---@overload fun(path:string):GameFramework.Variable
---@overload fun(path:string, node:GameFramework.DataNode.IDataNode):GameFramework.Variable
---@param path string
---@return GameFramework.Variable
function m:GetData(path) end

---@overload fun(path:string, data:GameFramework.Variable, node:GameFramework.DataNode.IDataNode)
---@param path string
---@param data GameFramework.Variable
function m:SetData(path, data) end

---@overload fun(path:string, node:GameFramework.DataNode.IDataNode):GameFramework.DataNode.IDataNode
---@param path string
---@return GameFramework.DataNode.IDataNode
function m:GetNode(path) end

---@overload fun(path:string, node:GameFramework.DataNode.IDataNode):GameFramework.DataNode.IDataNode
---@param path string
---@return GameFramework.DataNode.IDataNode
function m:GetOrAddNode(path) end

---@overload fun(path:string, node:GameFramework.DataNode.IDataNode)
---@param path string
function m:RemoveNode(path) end

function m:Clear() end

UnityGameFramework.Runtime.DataNodeComponent = m
return m
