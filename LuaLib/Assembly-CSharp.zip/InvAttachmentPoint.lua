---@class InvAttachmentPoint : UnityEngine.MonoBehaviour
---@field public slot InvBaseItem.Slot
local m = {}

---@param prefab UnityEngine.GameObject
---@return UnityEngine.GameObject
function m:Attach(prefab) end

InvAttachmentPoint = m
return m
