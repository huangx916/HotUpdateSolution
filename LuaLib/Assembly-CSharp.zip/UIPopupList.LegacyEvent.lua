---@class UIPopupList.LegacyEvent : System.MulticastDelegate
local m = {}

---@virtual
---@param val string
function m:Invoke(val) end

---@virtual
---@param val string
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(val, callback, object) end

---@virtual
---@param result System.IAsyncResult
function m:EndInvoke(result) end

UIPopupList.LegacyEvent = m
return m
