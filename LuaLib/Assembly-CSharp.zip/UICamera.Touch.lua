---@class UICamera.Touch : System.Object
---@field public fingerId number
---@field public phase UnityEngine.TouchPhase
---@field public position UnityEngine.Vector2
---@field public tapCount number
local m = {}

UICamera.Touch = m
return m
