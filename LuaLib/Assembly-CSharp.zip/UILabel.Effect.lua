---@class UILabel.Effect : System.Enum
---@field public None UILabel.Effect @static
---@field public Shadow UILabel.Effect @static
---@field public Outline UILabel.Effect @static
---@field public Outline8 UILabel.Effect @static
---@field public value__ number
local m = {}

UILabel.Effect = m
return m
