---@class UISliderColors : UnityEngine.MonoBehaviour
---@field public sprite UISprite
---@field public colors UnityEngine.Color[]
local m = {}

UISliderColors = m
return m
