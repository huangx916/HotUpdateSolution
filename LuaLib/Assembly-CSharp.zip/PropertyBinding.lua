---@class PropertyBinding : UnityEngine.MonoBehaviour
---@field public source PropertyReference
---@field public target PropertyReference
---@field public direction PropertyBinding.Direction
---@field public update PropertyBinding.UpdateCondition
---@field public editMode boolean
local m = {}

function m:UpdateTarget() end

PropertyBinding = m
return m
