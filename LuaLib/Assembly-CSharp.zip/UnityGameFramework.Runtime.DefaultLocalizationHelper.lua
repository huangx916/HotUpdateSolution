---@class UnityGameFramework.Runtime.DefaultLocalizationHelper : UnityGameFramework.Runtime.LocalizationHelperBase
---@field public SystemLanguage GameFramework.Localization.Language
local m = {}

---@virtual
---@param dictionaryName string
---@param dictionaryAsset any
---@param userData any
---@return boolean
function m:LoadDictionary(dictionaryName, dictionaryAsset, userData) end

---@virtual
---@param text string
---@param userData any
---@return boolean
function m:ParseDictionary(text, userData) end

---@virtual
---@param dictionaryAsset any
function m:ReleaseDictionaryAsset(dictionaryAsset) end

UnityGameFramework.Runtime.DefaultLocalizationHelper = m
return m
