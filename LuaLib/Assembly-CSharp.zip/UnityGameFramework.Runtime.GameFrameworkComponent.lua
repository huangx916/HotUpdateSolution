---@class UnityGameFramework.Runtime.GameFrameworkComponent : UnityEngine.MonoBehaviour
local m = {}

UnityGameFramework.Runtime.GameFrameworkComponent = m
return m
