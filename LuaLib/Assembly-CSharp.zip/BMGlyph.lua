---@class BMGlyph : System.Object
---@field public index number
---@field public x number
---@field public y number
---@field public width number
---@field public height number
---@field public offsetX number
---@field public offsetY number
---@field public advance number
---@field public channel number
---@field public kerning number[]
local m = {}

---@param previousChar number
---@return number
function m:GetKerning(previousChar) end

---@param previousChar number
---@param amount number
function m:SetKerning(previousChar, amount) end

---@param xMin number
---@param yMin number
---@param xMax number
---@param yMax number
function m:Trim(xMin, yMin, xMax, yMax) end

BMGlyph = m
return m
