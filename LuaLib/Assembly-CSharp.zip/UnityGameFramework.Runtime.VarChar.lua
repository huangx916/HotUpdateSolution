---@class UnityGameFramework.Runtime.VarChar : GameFramework.Variable_1_System_Char_
local m = {}

---@overload fun(value:UnityGameFramework.Runtime.VarChar):number @static
---@static
---@param value number
---@return UnityGameFramework.Runtime.VarChar
function m.op_Implicit(value) end

UnityGameFramework.Runtime.VarChar = m
return m
