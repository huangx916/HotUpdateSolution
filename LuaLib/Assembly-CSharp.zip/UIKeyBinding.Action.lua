---@class UIKeyBinding.Action : System.Enum
---@field public PressAndClick UIKeyBinding.Action @static
---@field public Select UIKeyBinding.Action @static
---@field public All UIKeyBinding.Action @static
---@field public value__ number
local m = {}

UIKeyBinding.Action = m
return m
