---@class UIPopupList.Selection : System.Enum
---@field public OnPress UIPopupList.Selection @static
---@field public OnClick UIPopupList.Selection @static
---@field public value__ number
local m = {}

UIPopupList.Selection = m
return m
