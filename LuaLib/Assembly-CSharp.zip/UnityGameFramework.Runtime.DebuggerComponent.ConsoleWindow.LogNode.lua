---@class UnityGameFramework.Runtime.DebuggerComponent.ConsoleWindow.LogNode : System.Object
---@field public LogTime System.DateTime
---@field public LogType UnityEngine.LogType
---@field public LogMessage string
---@field public StackTrack string
local m = {}

UnityGameFramework.Runtime.DebuggerComponent.ConsoleWindow.LogNode = m
return m
