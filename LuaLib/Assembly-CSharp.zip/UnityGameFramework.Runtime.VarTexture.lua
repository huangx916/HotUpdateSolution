---@class UnityGameFramework.Runtime.VarTexture : GameFramework.Variable_1_UnityEngine_Texture_
local m = {}

---@overload fun(value:UnityGameFramework.Runtime.VarTexture):UnityEngine.Texture @static
---@static
---@param value UnityEngine.Texture
---@return UnityGameFramework.Runtime.VarTexture
function m.op_Implicit(value) end

UnityGameFramework.Runtime.VarTexture = m
return m
