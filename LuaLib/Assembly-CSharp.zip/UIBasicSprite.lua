---@class UIBasicSprite : UIWidget
---@field public centerType UIBasicSprite.AdvancedType
---@field public leftType UIBasicSprite.AdvancedType
---@field public rightType UIBasicSprite.AdvancedType
---@field public bottomType UIBasicSprite.AdvancedType
---@field public topType UIBasicSprite.AdvancedType
---@field public type UIBasicSprite.Type
---@field public flip UIBasicSprite.Flip
---@field public mirror UIBasicSprite.Flip
---@field public fillDirection UIBasicSprite.FillDirection
---@field public fillAmount number
---@field public minWidth number
---@field public minHeight number
---@field public invert boolean
---@field public fillBorder boolean
---@field public hasBorder boolean
---@field public premultipliedAlpha boolean
---@field public pixelSize number
local m = {}

---@param border UnityEngine.Vector4
---@return UnityEngine.Vector4
function m:FlipBorder(border) end

UIBasicSprite = m
return m
