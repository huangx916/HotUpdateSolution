---@class GameFramework.Variable_1_System_DateTime_ : GameFramework.Variable
---@field public Type System.Type
---@field public Value System.DateTime
local m = {}

---@virtual
---@return any
function m:GetValue() end

---@virtual
---@param value any
function m:SetValue(value) end

---@virtual
function m:Reset() end

---@virtual
---@return string
function m:ToString() end

GameFramework.Variable_1_System_DateTime_ = m
return m
