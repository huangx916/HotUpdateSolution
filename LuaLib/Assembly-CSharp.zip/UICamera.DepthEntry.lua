---@class UICamera.DepthEntry : System.ValueType
---@field public depth number
---@field public hit UnityEngine.RaycastHit
---@field public point UnityEngine.Vector3
---@field public go UnityEngine.GameObject
local m = {}

UICamera.DepthEntry = m
return m
