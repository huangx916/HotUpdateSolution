---@class UnityGameFramework.Runtime.VarVector3 : GameFramework.Variable_1_UnityEngine_Vector3_
local m = {}

---@overload fun(value:UnityGameFramework.Runtime.VarVector3):UnityEngine.Vector3 @static
---@static
---@param value UnityEngine.Vector3
---@return UnityGameFramework.Runtime.VarVector3
function m.op_Implicit(value) end

UnityGameFramework.Runtime.VarVector3 = m
return m
