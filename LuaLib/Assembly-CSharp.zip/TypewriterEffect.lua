---@class TypewriterEffect : UnityEngine.MonoBehaviour
---@field public current TypewriterEffect @static
---@field public charsPerSecond number
---@field public fadeInTime number
---@field public delayOnPeriod number
---@field public delayOnNewLine number
---@field public scrollView UIScrollView
---@field public keepFullDimensions boolean
---@field public onFinished EventDelegate[]
---@field public isActive boolean
local m = {}

function m:ResetToBeginning() end

function m:Finish() end

TypewriterEffect = m
return m
