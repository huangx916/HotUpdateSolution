---@class UnityGameFramework.Runtime.WWWFormInfo : System.Object
---@field public WWWForm UnityEngine.WWWForm
---@field public UserData any
local m = {}

UnityGameFramework.Runtime.WWWFormInfo = m
return m
