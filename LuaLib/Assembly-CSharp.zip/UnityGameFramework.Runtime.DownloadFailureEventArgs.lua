---@class UnityGameFramework.Runtime.DownloadFailureEventArgs : GameFramework.Event.GameEventArgs
---@field public Id number
---@field public SerialId number
---@field public DownloadPath string
---@field public DownloadUri string
---@field public ErrorMessage string
---@field public UserData any
local m = {}

UnityGameFramework.Runtime.DownloadFailureEventArgs = m
return m
