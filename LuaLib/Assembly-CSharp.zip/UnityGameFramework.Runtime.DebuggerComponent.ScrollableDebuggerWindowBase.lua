---@class UnityGameFramework.Runtime.DebuggerComponent.ScrollableDebuggerWindowBase : System.Object
local m = {}

---@overload fun() @virtual
---@virtual
---@param args any[]|any
function m:Initialize(args) end

---@virtual
function m:Shutdown() end

---@virtual
function m:OnEnter() end

---@virtual
function m:OnLeave() end

---@virtual
---@param elapseSeconds number
---@param realElapseSeconds number
function m:OnUpdate(elapseSeconds, realElapseSeconds) end

---@virtual
function m:OnDraw() end

UnityGameFramework.Runtime.DebuggerComponent.ScrollableDebuggerWindowBase = m
return m
