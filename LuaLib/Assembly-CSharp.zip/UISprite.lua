---@class UISprite : UIBasicSprite
---@field public mainTexture UnityEngine.Texture
---@field public alphaTexture UnityEngine.Texture
---@field public material UnityEngine.Material
---@field public atlas UIAtlas
---@field public spriteName string
---@field public textureWidth number
---@field public textureHeight number
---@field public isValid boolean
---@field public fillCenter boolean
---@field public applyGradient boolean
---@field public gradientTop UnityEngine.Color
---@field public gradientBottom UnityEngine.Color
---@field public border UnityEngine.Vector4
---@field public flippedBorder UnityEngine.Vector4
---@field public pixelSize number
---@field public minWidth number
---@field public minHeight number
---@field public drawingDimensions UnityEngine.Vector4
---@field public premultipliedAlpha boolean
local m = {}

---@param newDepth number
function m:SetDepth(newDepth) end

---@return UISpriteData
function m:GetAtlasSprite() end

---@virtual
function m:MakePixelPerfect() end

---@virtual
---@param verts UnityEngine.Vector3[]
---@param uvs UnityEngine.Vector2[]
---@param cols UnityEngine.Color[]
function m:OnFill(verts, uvs, cols) end

UISprite = m
return m
