---@class UnityGameFramework.Runtime.UIForm : UnityEngine.MonoBehaviour
---@field public SerialId number
---@field public UIFormAssetName string
---@field public Handle any
---@field public UIGroup GameFramework.UI.IUIGroup
---@field public DepthInUIGroup number
---@field public PauseCoveredUIForm boolean
---@field public Logic UnityGameFramework.Runtime.UIFormLogic
local m = {}

---@virtual
---@param serialId number
---@param uiFormAssetName string
---@param uiGroup GameFramework.UI.IUIGroup
---@param pauseCoveredUIForm boolean
---@param isNewInstance boolean
---@param userData any
function m:OnInit(serialId, uiFormAssetName, uiGroup, pauseCoveredUIForm, isNewInstance, userData) end

---@virtual
function m:OnRecycle() end

---@virtual
---@param userData any
function m:OnOpen(userData) end

---@virtual
---@param userData any
function m:OnClose(userData) end

---@virtual
function m:OnPause() end

---@virtual
function m:OnResume() end

---@virtual
function m:OnCover() end

---@virtual
function m:OnReveal() end

---@virtual
---@param userData any
function m:OnRefocus(userData) end

---@virtual
---@param elapseSeconds number
---@param realElapseSeconds number
function m:OnUpdate(elapseSeconds, realElapseSeconds) end

---@virtual
---@param uiGroupDepth number
---@param depthInUIGroup number
function m:OnDepthChanged(uiGroupDepth, depthInUIGroup) end

UnityGameFramework.Runtime.UIForm = m
return m
