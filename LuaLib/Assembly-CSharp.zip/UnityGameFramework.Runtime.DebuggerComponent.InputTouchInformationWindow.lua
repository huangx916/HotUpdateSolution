---@class UnityGameFramework.Runtime.DebuggerComponent.InputTouchInformationWindow : UnityGameFramework.Runtime.DebuggerComponent.ScrollableDebuggerWindowBase
local m = {}

UnityGameFramework.Runtime.DebuggerComponent.InputTouchInformationWindow = m
return m
