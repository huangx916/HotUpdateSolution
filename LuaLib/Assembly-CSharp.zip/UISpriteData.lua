---@class UISpriteData : System.Object
---@field public name string
---@field public x number
---@field public y number
---@field public width number
---@field public height number
---@field public borderLeft number
---@field public borderRight number
---@field public borderTop number
---@field public borderBottom number
---@field public paddingLeft number
---@field public paddingRight number
---@field public paddingTop number
---@field public paddingBottom number
---@field public hasBorder boolean
---@field public hasPadding boolean
local m = {}

---@param x number
---@param y number
---@param width number
---@param height number
function m:SetRect(x, y, width, height) end

---@param left number
---@param bottom number
---@param right number
---@param top number
function m:SetPadding(left, bottom, right, top) end

---@param left number
---@param bottom number
---@param right number
---@param top number
function m:SetBorder(left, bottom, right, top) end

---@param sd UISpriteData
function m:CopyFrom(sd) end

---@param sd UISpriteData
function m:CopyBorderFrom(sd) end

UISpriteData = m
return m
