---@class UnityGameFramework.Runtime.ShowEntityDependencyAssetEventArgs : GameFramework.Event.GameEventArgs
---@field public Id number
---@field public EntityId number
---@field public EntityLogicType System.Type
---@field public EntityAssetName string
---@field public EntityGroupName string
---@field public DependencyAssetName string
---@field public LoadedCount number
---@field public TotalCount number
---@field public UserData any
local m = {}

UnityGameFramework.Runtime.ShowEntityDependencyAssetEventArgs = m
return m
