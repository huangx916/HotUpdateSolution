---@class UnityGameFramework.Runtime.ResourceInitCompleteEventArgs : GameFramework.Event.GameEventArgs
---@field public Id number
local m = {}

UnityGameFramework.Runtime.ResourceInitCompleteEventArgs = m
return m
