---@class UnityGameFramework.Runtime.ShowEntitySuccessEventArgs : GameFramework.Event.GameEventArgs
---@field public Id number
---@field public EntityLogicType System.Type
---@field public Entity UnityGameFramework.Runtime.Entity
---@field public Duration number
---@field public UserData any
local m = {}

UnityGameFramework.Runtime.ShowEntitySuccessEventArgs = m
return m
