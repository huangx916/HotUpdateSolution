---@class EquipRandomItem : UnityEngine.MonoBehaviour
---@field public equipment InvEquipment
local m = {}

EquipRandomItem = m
return m
