---@class UnityGameFramework.Runtime.HideEntityCompleteEventArgs : GameFramework.Event.GameEventArgs
---@field public Id number
---@field public EntityId number
---@field public EntityAssetName string
---@field public EntityGroup GameFramework.Entity.IEntityGroup
---@field public UserData any
local m = {}

UnityGameFramework.Runtime.HideEntityCompleteEventArgs = m
return m
