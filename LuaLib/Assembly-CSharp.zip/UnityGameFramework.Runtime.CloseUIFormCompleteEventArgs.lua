---@class UnityGameFramework.Runtime.CloseUIFormCompleteEventArgs : GameFramework.Event.GameEventArgs
---@field public Id number
---@field public SerialId number
---@field public UIFormAssetName string
---@field public UIGroup GameFramework.UI.IUIGroup
---@field public UserData any
local m = {}

UnityGameFramework.Runtime.CloseUIFormCompleteEventArgs = m
return m
