---@class UICenterOnClick : UnityEngine.MonoBehaviour
local m = {}

UICenterOnClick = m
return m
