---@class UnityGameFramework.Runtime.NetworkComponent.NetworkChannel : System.Object
---@field public Name string
---@field public IPString string
---@field public Port number
---@field public PacketHeaderLength number
---@field public MaxPacketLength number
---@field public ResetHeartBeatElapseSecondsWhenReceivePacket boolean
---@field public HeartBeatInterval number
local m = {}

---@param networkChannel GameFramework.Network.INetworkChannel
function m:SetNetworkChannel(networkChannel) end

---@param userData any
function m:Connect(userData) end

UnityGameFramework.Runtime.NetworkComponent.NetworkChannel = m
return m
