---@class UIInputOnGUI : UnityEngine.MonoBehaviour
local m = {}

UIInputOnGUI = m
return m
