---@class UnityGameFramework.Runtime.PlaySoundInfo : System.Object
---@field public BindingEntity UnityGameFramework.Runtime.Entity
---@field public WorldPosition UnityEngine.Vector3
---@field public UserData any
local m = {}

UnityGameFramework.Runtime.PlaySoundInfo = m
return m
