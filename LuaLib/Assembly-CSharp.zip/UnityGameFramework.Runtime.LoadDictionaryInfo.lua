---@class UnityGameFramework.Runtime.LoadDictionaryInfo : System.Object
---@field public DictionaryName string
---@field public UserData any
local m = {}

UnityGameFramework.Runtime.LoadDictionaryInfo = m
return m
