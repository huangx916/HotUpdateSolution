---@class ActiveAnimation : UnityEngine.MonoBehaviour
---@field public current ActiveAnimation @static
---@field public onFinished EventDelegate[]
---@field public eventReceiver UnityEngine.GameObject
---@field public callWhenFinished string
---@field public isPlaying boolean
local m = {}

function m:Finish() end

function m:Reset() end

---@overload fun(anim:UnityEngine.Animation, clipName:string, playDirection:AnimationOrTween.Direction):ActiveAnimation @static
---@overload fun(anim:UnityEngine.Animation, playDirection:AnimationOrTween.Direction):ActiveAnimation @static
---@overload fun(anim:UnityEngine.Animator, clipName:string, playDirection:AnimationOrTween.Direction, enableBeforePlay:AnimationOrTween.EnableCondition, disableCondition:AnimationOrTween.DisableCondition):ActiveAnimation @static
---@static
---@param anim UnityEngine.Animation
---@param clipName string
---@param playDirection AnimationOrTween.Direction
---@param enableBeforePlay AnimationOrTween.EnableCondition
---@param disableCondition AnimationOrTween.DisableCondition
---@return ActiveAnimation
function m.Play(anim, clipName, playDirection, enableBeforePlay, disableCondition) end

ActiveAnimation = m
return m
