---@class UIAtlas.Sprite : System.Object
---@field public name string
---@field public outer UnityEngine.Rect
---@field public inner UnityEngine.Rect
---@field public rotated boolean
---@field public paddingLeft number
---@field public paddingRight number
---@field public paddingTop number
---@field public paddingBottom number
---@field public hasPadding boolean
local m = {}

UIAtlas.Sprite = m
return m
