---@class UIInput.InputType : System.Enum
---@field public Standard UIInput.InputType @static
---@field public AutoCorrect UIInput.InputType @static
---@field public Password UIInput.InputType @static
---@field public value__ number
local m = {}

UIInput.InputType = m
return m
