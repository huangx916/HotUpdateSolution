---@class UnityGameFramework.Runtime.PlaySoundFailureEventArgs : GameFramework.Event.GameEventArgs
---@field public Id number
---@field public SerialId number
---@field public SoundAssetName string
---@field public SoundGroupName string
---@field public PlaySoundParams GameFramework.Sound.PlaySoundParams
---@field public BindingEntity UnityGameFramework.Runtime.Entity
---@field public ErrorCode GameFramework.Sound.PlaySoundErrorCode
---@field public ErrorMessage string
---@field public UserData any
local m = {}

UnityGameFramework.Runtime.PlaySoundFailureEventArgs = m
return m
