---@class UIBasicSprite.AdvancedType : System.Enum
---@field public Invisible UIBasicSprite.AdvancedType @static
---@field public Sliced UIBasicSprite.AdvancedType @static
---@field public Tiled UIBasicSprite.AdvancedType @static
---@field public value__ number
local m = {}

UIBasicSprite.AdvancedType = m
return m
