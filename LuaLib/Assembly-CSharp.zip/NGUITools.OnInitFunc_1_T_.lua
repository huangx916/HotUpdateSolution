---@class NGUITools.OnInitFunc_1_T_ : System.MulticastDelegate
local m = {}

---@virtual
---@param w UIWidget
function m:Invoke(w) end

---@virtual
---@param w UIWidget
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(w, callback, object) end

---@virtual
---@param result System.IAsyncResult
function m:EndInvoke(result) end

NGUITools.OnInitFunc_1_T_ = m
return m
