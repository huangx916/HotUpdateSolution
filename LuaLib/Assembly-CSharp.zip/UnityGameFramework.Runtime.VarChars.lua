---@class UnityGameFramework.Runtime.VarChars : GameFramework.Variable_1_System_Char___
local m = {}

---@overload fun(value:UnityGameFramework.Runtime.VarChars):number[] @static
---@static
---@param value number[]
---@return UnityGameFramework.Runtime.VarChars
function m.op_Implicit(value) end

UnityGameFramework.Runtime.VarChars = m
return m
