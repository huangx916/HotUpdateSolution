---@class UnityGameFramework.Runtime.DebuggerComponent.EnvironmentInformationWindow : UnityGameFramework.Runtime.DebuggerComponent.ScrollableDebuggerWindowBase
local m = {}

---@overload fun() @virtual
---@virtual
---@param args any[]|any
function m:Initialize(args) end

UnityGameFramework.Runtime.DebuggerComponent.EnvironmentInformationWindow = m
return m
