---@class UnityGameFramework.Runtime.VarTransform : GameFramework.Variable_1_UnityEngine_Transform_
local m = {}

---@overload fun(value:UnityGameFramework.Runtime.VarTransform):UnityEngine.Transform @static
---@static
---@param value UnityEngine.Transform
---@return UnityGameFramework.Runtime.VarTransform
function m.op_Implicit(value) end

UnityGameFramework.Runtime.VarTransform = m
return m
