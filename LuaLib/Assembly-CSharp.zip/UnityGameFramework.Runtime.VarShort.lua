---@class UnityGameFramework.Runtime.VarShort : GameFramework.Variable_1_System_Int16_
local m = {}

---@overload fun(value:UnityGameFramework.Runtime.VarShort):number @static
---@static
---@param value number
---@return UnityGameFramework.Runtime.VarShort
function m.op_Implicit(value) end

UnityGameFramework.Runtime.VarShort = m
return m
