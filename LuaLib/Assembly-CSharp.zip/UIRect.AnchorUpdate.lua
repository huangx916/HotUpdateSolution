---@class UIRect.AnchorUpdate : System.Enum
---@field public OnEnable UIRect.AnchorUpdate @static
---@field public OnUpdate UIRect.AnchorUpdate @static
---@field public OnStart UIRect.AnchorUpdate @static
---@field public value__ number
local m = {}

UIRect.AnchorUpdate = m
return m
