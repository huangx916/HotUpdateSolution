---@class UnityGameFramework.Runtime.ShutdownType : System.Enum
---@field public None UnityGameFramework.Runtime.ShutdownType @static
---@field public Restart UnityGameFramework.Runtime.ShutdownType @static
---@field public Quit UnityGameFramework.Runtime.ShutdownType @static
---@field public value__ number
local m = {}

UnityGameFramework.Runtime.ShutdownType = m
return m
