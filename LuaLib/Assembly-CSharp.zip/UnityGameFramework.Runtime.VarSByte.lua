---@class UnityGameFramework.Runtime.VarSByte : GameFramework.Variable_1_System_SByte_
local m = {}

---@overload fun(value:UnityGameFramework.Runtime.VarSByte):number @static
---@static
---@param value number
---@return UnityGameFramework.Runtime.VarSByte
function m.op_Implicit(value) end

UnityGameFramework.Runtime.VarSByte = m
return m
