---@class UnityGameFramework.Runtime.SoundGroupHelperBase : UnityEngine.MonoBehaviour
---@field public AudioMixerGroup UnityEngine.Audio.AudioMixerGroup
local m = {}

UnityGameFramework.Runtime.SoundGroupHelperBase = m
return m
