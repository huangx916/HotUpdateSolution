---@class UnityGameFramework.Runtime.Entity : UnityEngine.MonoBehaviour
---@field public Id number
---@field public EntityAssetName string
---@field public Handle any
---@field public EntityGroup GameFramework.Entity.IEntityGroup
---@field public Logic UnityGameFramework.Runtime.EntityLogic
local m = {}

---@virtual
---@param entityId number
---@param entityAssetName string
---@param entityGroup GameFramework.Entity.IEntityGroup
---@param isNewInstance boolean
---@param userData any
function m:OnInit(entityId, entityAssetName, entityGroup, isNewInstance, userData) end

---@virtual
function m:OnRecycle() end

---@virtual
---@param userData any
function m:OnShow(userData) end

---@virtual
---@param userData any
function m:OnHide(userData) end

---@virtual
---@param childEntity GameFramework.Entity.IEntity
---@param userData any
function m:OnAttached(childEntity, userData) end

---@virtual
---@param childEntity GameFramework.Entity.IEntity
---@param userData any
function m:OnDetached(childEntity, userData) end

---@virtual
---@param parentEntity GameFramework.Entity.IEntity
---@param userData any
function m:OnAttachTo(parentEntity, userData) end

---@virtual
---@param parentEntity GameFramework.Entity.IEntity
---@param userData any
function m:OnDetachFrom(parentEntity, userData) end

---@virtual
---@param elapseSeconds number
---@param realElapseSeconds number
function m:OnUpdate(elapseSeconds, realElapseSeconds) end

UnityGameFramework.Runtime.Entity = m
return m
