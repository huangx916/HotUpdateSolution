---@class UnityGameFramework.Runtime.ResourceUpdateFailureEventArgs : GameFramework.Event.GameEventArgs
---@field public Id number
---@field public Name string
---@field public DownloadUri string
---@field public RetryCount number
---@field public TotalRetryCount number
---@field public ErrorMessage string
local m = {}

UnityGameFramework.Runtime.ResourceUpdateFailureEventArgs = m
return m
