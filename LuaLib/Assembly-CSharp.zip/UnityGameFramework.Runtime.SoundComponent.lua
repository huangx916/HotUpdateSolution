---@class UnityGameFramework.Runtime.SoundComponent : UnityGameFramework.Runtime.GameFrameworkComponent
---@field public SoundGroupCount number
---@field public AudioMixer UnityEngine.Audio.AudioMixer
local m = {}

---@param soundGroupName string
---@return boolean
function m:HasSoundGroup(soundGroupName) end

---@param soundGroupName string
---@return GameFramework.Sound.ISoundGroup
function m:GetSoundGroup(soundGroupName) end

---@return GameFramework.Sound.ISoundGroup[]
function m:GetAllSoundGroups() end

---@overload fun(soundGroupName:string, soundGroupAvoidBeingReplacedBySamePriority:boolean, soundGroupMute:boolean, soundGroupVolume:number, soundAgentHelperCount:number):boolean
---@param soundGroupName string
---@param soundAgentHelperCount number
---@return boolean
function m:AddSoundGroup(soundGroupName, soundAgentHelperCount) end

---@return number[]
function m:GetAllLoadingSoundSerialIds() end

---@param serialId number
---@return boolean
function m:IsLoadingSound(serialId) end

---@overload fun(soundAssetName:string, soundGroupName:string, playSoundParams:GameFramework.Sound.PlaySoundParams):number
---@overload fun(soundAssetName:string, soundGroupName:string, bindingEntity:UnityGameFramework.Runtime.Entity):number
---@overload fun(soundAssetName:string, soundGroupName:string, userData:any):number
---@overload fun(soundAssetName:string, soundGroupName:string, playSoundParams:GameFramework.Sound.PlaySoundParams, bindingEntity:UnityGameFramework.Runtime.Entity):number
---@overload fun(soundAssetName:string, soundGroupName:string, playSoundParams:GameFramework.Sound.PlaySoundParams, userData:any):number
---@overload fun(soundAssetName:string, soundGroupName:string, bindingEntity:UnityGameFramework.Runtime.Entity, userData:any):number
---@overload fun(soundAssetName:string, soundGroupName:string, playSoundParams:GameFramework.Sound.PlaySoundParams, bindingEntity:UnityGameFramework.Runtime.Entity, userData:any):number
---@overload fun(soundAssetName:string, soundGroupName:string, worldPosition:UnityEngine.Vector3):number
---@overload fun(soundAssetName:string, soundGroupName:string, playSoundParams:GameFramework.Sound.PlaySoundParams, worldPosition:UnityEngine.Vector3):number
---@overload fun(soundAssetName:string, soundGroupName:string, worldPosition:UnityEngine.Vector3, userData:any):number
---@overload fun(soundAssetName:string, soundGroupName:string, playSoundParams:GameFramework.Sound.PlaySoundParams, worldPosition:UnityEngine.Vector3, userData:any):number
---@param soundAssetName string
---@param soundGroupName string
---@return number
function m:PlaySound(soundAssetName, soundGroupName) end

---@overload fun(serialId:number, fadeOutSeconds:number)
---@param serialId number
function m:StopSound(serialId) end

---@overload fun(fadeOutSeconds:number)
function m:StopAllLoadedSounds() end

function m:StopAllLoadingSounds() end

---@overload fun(serialId:number, fadeOutSeconds:number)
---@param serialId number
function m:PauseSound(serialId) end

---@overload fun(serialId:number, fadeInSeconds:number)
---@param serialId number
function m:ResumeSound(serialId) end

UnityGameFramework.Runtime.SoundComponent = m
return m
