---@class UnityGameFramework.Runtime.DownloadAgentHelperBase : UnityEngine.MonoBehaviour
local m = {}

---@abstract
---@param value fun(sender:any, e:GameFramework.Download.DownloadAgentHelperUpdateEventArgs)
function m:add_DownloadAgentHelperUpdate(value) end

---@abstract
---@param value fun(sender:any, e:GameFramework.Download.DownloadAgentHelperUpdateEventArgs)
function m:remove_DownloadAgentHelperUpdate(value) end

---@abstract
---@param value fun(sender:any, e:GameFramework.Download.DownloadAgentHelperCompleteEventArgs)
function m:add_DownloadAgentHelperComplete(value) end

---@abstract
---@param value fun(sender:any, e:GameFramework.Download.DownloadAgentHelperCompleteEventArgs)
function m:remove_DownloadAgentHelperComplete(value) end

---@abstract
---@param value fun(sender:any, e:GameFramework.Download.DownloadAgentHelperErrorEventArgs)
function m:add_DownloadAgentHelperError(value) end

---@abstract
---@param value fun(sender:any, e:GameFramework.Download.DownloadAgentHelperErrorEventArgs)
function m:remove_DownloadAgentHelperError(value) end

---@overload fun(downloadUri:string, fromPosition:number, userData:any) @abstract
---@overload fun(downloadUri:string, fromPosition:number, toPosition:number, userData:any) @abstract
---@abstract
---@param downloadUri string
---@param userData any
function m:Download(downloadUri, userData) end

---@abstract
function m:Reset() end

UnityGameFramework.Runtime.DownloadAgentHelperBase = m
return m
