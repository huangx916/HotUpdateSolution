---@class LookAtTarget : UnityEngine.MonoBehaviour
---@field public level number
---@field public target UnityEngine.Transform
---@field public speed number
local m = {}

LookAtTarget = m
return m
