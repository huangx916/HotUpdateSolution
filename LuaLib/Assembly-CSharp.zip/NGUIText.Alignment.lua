---@class NGUIText.Alignment : System.Enum
---@field public Automatic NGUIText.Alignment @static
---@field public Left NGUIText.Alignment @static
---@field public Center NGUIText.Alignment @static
---@field public Right NGUIText.Alignment @static
---@field public Justified NGUIText.Alignment @static
---@field public value__ number
local m = {}

NGUIText.Alignment = m
return m
