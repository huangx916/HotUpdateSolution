---@class UnityGameFramework.Runtime.VarULong : GameFramework.Variable_1_System_UInt64_
local m = {}

---@overload fun(value:UnityGameFramework.Runtime.VarULong):number @static
---@static
---@param value number
---@return UnityGameFramework.Runtime.VarULong
function m.op_Implicit(value) end

UnityGameFramework.Runtime.VarULong = m
return m
