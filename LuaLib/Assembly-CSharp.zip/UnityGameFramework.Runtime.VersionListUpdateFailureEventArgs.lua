---@class UnityGameFramework.Runtime.VersionListUpdateFailureEventArgs : GameFramework.Event.GameEventArgs
---@field public Id number
---@field public DownloadUri string
---@field public ErrorMessage string
local m = {}

UnityGameFramework.Runtime.VersionListUpdateFailureEventArgs = m
return m
