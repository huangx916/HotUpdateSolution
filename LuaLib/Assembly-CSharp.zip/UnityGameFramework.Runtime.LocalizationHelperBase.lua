---@class UnityGameFramework.Runtime.LocalizationHelperBase : UnityEngine.MonoBehaviour
---@field public SystemLanguage GameFramework.Localization.Language
local m = {}

---@overload fun(dictionaryName:string, dictionaryAsset:any, userData:any):boolean @abstract
---@virtual
---@param dictionaryAsset any
---@param userData any
---@return boolean
function m:LoadDictionary(dictionaryAsset, userData) end

---@abstract
---@param text string
---@param userData any
---@return boolean
function m:ParseDictionary(text, userData) end

---@abstract
---@param dictionaryAsset any
function m:ReleaseDictionaryAsset(dictionaryAsset) end

UnityGameFramework.Runtime.LocalizationHelperBase = m
return m
