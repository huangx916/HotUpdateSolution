---@class UnityGameFramework.Runtime.NetworkClosedEventArgs : GameFramework.Event.GameEventArgs
---@field public Id number
---@field public NetworkChannel GameFramework.Network.INetworkChannel
local m = {}

UnityGameFramework.Runtime.NetworkClosedEventArgs = m
return m
