---@class UICamera.GetTouchDelegate : System.MulticastDelegate
local m = {}

---@virtual
---@param id number
---@param createIfMissing boolean
---@return UICamera.MouseOrTouch
function m:Invoke(id, createIfMissing) end

---@virtual
---@param id number
---@param createIfMissing boolean
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(id, createIfMissing, callback, object) end

---@virtual
---@param result System.IAsyncResult
---@return UICamera.MouseOrTouch
function m:EndInvoke(result) end

UICamera.GetTouchDelegate = m
return m
