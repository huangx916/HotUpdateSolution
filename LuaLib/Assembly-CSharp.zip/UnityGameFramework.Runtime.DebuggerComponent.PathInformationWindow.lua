---@class UnityGameFramework.Runtime.DebuggerComponent.PathInformationWindow : UnityGameFramework.Runtime.DebuggerComponent.ScrollableDebuggerWindowBase
local m = {}

UnityGameFramework.Runtime.DebuggerComponent.PathInformationWindow = m
return m
