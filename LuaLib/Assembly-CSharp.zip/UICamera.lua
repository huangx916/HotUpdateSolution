---@class UICamera : UnityEngine.MonoBehaviour
---@field public list BetterList_1_UICamera_ @static
---@field public GetKeyDown fun(key:UnityEngine.KeyCode):boolean @static
---@field public GetKeyUp fun(key:UnityEngine.KeyCode):boolean @static
---@field public GetKey fun(key:UnityEngine.KeyCode):boolean @static
---@field public GetAxis fun(name:string):number @static
---@field public GetAnyKeyDown fun():boolean @static
---@field public GetMouse fun(button:number):UICamera.MouseOrTouch @static
---@field public GetTouch fun(id:number, createIfMissing:boolean):UICamera.MouseOrTouch @static
---@field public RemoveTouch fun(id:number) @static
---@field public onScreenResize fun() @static
---@field public onCustomInput fun() @static
---@field public showTooltips boolean @static
---@field public ignoreAllEvents boolean @static
---@field public ignoreControllerInput boolean @static
---@field public lastWorldPosition UnityEngine.Vector3 @static
---@field public lastWorldRay UnityEngine.Ray @static
---@field public lastHit UnityEngine.RaycastHit @static
---@field public current UICamera @static
---@field public currentCamera UnityEngine.Camera @static
---@field public onSchemeChange fun() @static
---@field public currentTouchID number @static
---@field public currentTouch UICamera.MouseOrTouch @static
---@field public fallThrough UnityEngine.GameObject @static
---@field public onClick fun(go:UnityEngine.GameObject) @static
---@field public onDoubleClick fun(go:UnityEngine.GameObject) @static
---@field public onHover fun(go:UnityEngine.GameObject, state:boolean) @static
---@field public onPress fun(go:UnityEngine.GameObject, state:boolean) @static
---@field public onSelect fun(go:UnityEngine.GameObject, state:boolean) @static
---@field public onScroll fun(go:UnityEngine.GameObject, delta:number) @static
---@field public onDrag fun(go:UnityEngine.GameObject, delta:UnityEngine.Vector2) @static
---@field public onDragStart fun(go:UnityEngine.GameObject) @static
---@field public onDragOver fun(go:UnityEngine.GameObject, obj:UnityEngine.GameObject) @static
---@field public onDragOut fun(go:UnityEngine.GameObject, obj:UnityEngine.GameObject) @static
---@field public onDragEnd fun(go:UnityEngine.GameObject) @static
---@field public onDrop fun(go:UnityEngine.GameObject, obj:UnityEngine.GameObject) @static
---@field public onKey fun(go:UnityEngine.GameObject, key:UnityEngine.KeyCode) @static
---@field public onNavigate fun(go:UnityEngine.GameObject, key:UnityEngine.KeyCode) @static
---@field public onPan fun(go:UnityEngine.GameObject, delta:UnityEngine.Vector2) @static
---@field public onTooltip fun(go:UnityEngine.GameObject, state:boolean) @static
---@field public onMouseMove fun(delta:UnityEngine.Vector2) @static
---@field public controller UICamera.MouseOrTouch @static
---@field public activeTouches UICamera.MouseOrTouch[] @static
---@field public isDragging boolean @static
---@field public GetInputTouchCount fun():number @static
---@field public GetInputTouch fun(index:number):UICamera.Touch @static
---@field public disableController boolean @static
---@field public lastTouchPosition UnityEngine.Vector2 @static
---@field public lastEventPosition UnityEngine.Vector2 @static
---@field public first UICamera @static
---@field public currentScheme UICamera.ControlScheme @static
---@field public currentKey UnityEngine.KeyCode @static
---@field public currentRay UnityEngine.Ray @static
---@field public inputHasFocus boolean @static
---@field public genericEventHandler UnityEngine.GameObject @static
---@field public mouse0 UICamera.MouseOrTouch @static
---@field public mouse1 UICamera.MouseOrTouch @static
---@field public mouse2 UICamera.MouseOrTouch @static
---@field public tooltipObject UnityEngine.GameObject @static
---@field public isOverUI boolean @static
---@field public uiHasFocus boolean @static
---@field public interactingWithUI boolean @static
---@field public hoveredObject UnityEngine.GameObject @static
---@field public controllerNavigationObject UnityEngine.GameObject @static
---@field public selectedObject UnityEngine.GameObject @static
---@field public touchCount number @static
---@field public dragCount number @static
---@field public mainCamera UnityEngine.Camera @static
---@field public eventHandler UICamera @static
---@field public eventType UICamera.EventType
---@field public eventsGoToColliders boolean
---@field public eventReceiverMask UnityEngine.LayerMask
---@field public processEventsIn UICamera.ProcessEventsIn
---@field public debug boolean
---@field public useMouse boolean
---@field public useTouch boolean
---@field public allowMultiTouch boolean
---@field public useKeyboard boolean
---@field public useController boolean
---@field public stickyTooltip boolean
---@field public tooltipDelay number
---@field public longPressTooltip boolean
---@field public mouseDragThreshold number
---@field public mouseClickThreshold number
---@field public touchDragThreshold number
---@field public touchClickThreshold number
---@field public rangeDistance number
---@field public horizontalAxisName string
---@field public verticalAxisName string
---@field public horizontalPanAxisName string
---@field public verticalPanAxisName string
---@field public scrollAxisName string
---@field public commandClick boolean
---@field public submitKey0 UnityEngine.KeyCode
---@field public submitKey1 UnityEngine.KeyCode
---@field public cancelKey0 UnityEngine.KeyCode
---@field public cancelKey1 UnityEngine.KeyCode
---@field public autoHideCursor boolean
---@field public stickyPress boolean
---@field public cachedCamera UnityEngine.Camera
local m = {}

---@static
---@param go UnityEngine.GameObject
---@return boolean
function m.IsPartOfUI(go) end

---@static
---@param go UnityEngine.GameObject
---@return boolean
function m.IsPressed(go) end

---@static
---@return number
function m.CountInputSources() end

---@overload fun(inPos:UnityEngine.Vector3):boolean @static
---@static
---@param touch UICamera.MouseOrTouch
function m.Raycast(touch) end

---@static
---@param go UnityEngine.GameObject
---@return boolean
function m.IsHighlighted(go) end

---@static
---@param layer number
---@return UICamera
function m.FindCameraForLayer(layer) end

---@static
---@param go UnityEngine.GameObject
---@param funcName string
---@param obj any
function m.Notify(go, funcName, obj) end

function m:ProcessMouse() end

function m:ProcessTouches() end

function m:ProcessOthers() end

---@param pressed boolean
---@param released boolean
function m:ProcessTouch(pressed, released) end

---@static
function m.CancelNextTooltip() end

---@static
---@param go UnityEngine.GameObject
---@return boolean
function m.ShowTooltip(go) end

---@static
---@return boolean
function m.HideTooltip() end

UICamera = m
return m
