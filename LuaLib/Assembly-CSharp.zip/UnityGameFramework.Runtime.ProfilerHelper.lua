---@class UnityGameFramework.Runtime.ProfilerHelper : System.Object
local m = {}

---@virtual
---@param name string
function m:BeginSample(name) end

---@virtual
function m:EndSample() end

UnityGameFramework.Runtime.ProfilerHelper = m
return m
