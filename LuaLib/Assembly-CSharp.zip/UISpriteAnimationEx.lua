---@class UISpriteAnimationEx : UnityEngine.MonoBehaviour
---@field public frameIndex number
---@field public framesPerSecond number
---@field public snap boolean
---@field public loop boolean
---@field public isPlaying boolean
---@field public keyframes UISpriteAnimationEx.Keyframe[]
---@field public sprite UISprite
local m = {}

function m:Play() end

function m:Pause() end

function m:ResetToBeginning() end

---@overload fun(frameIndex:number)
function m:Sample() end

---@param frameIndex number
---@return string
function m:GetSpriteName(frameIndex) end

UISpriteAnimationEx = m
return m
