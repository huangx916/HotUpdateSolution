---@class UITextureEx : UITexture
---@field public replacement UITexture
---@field public mainTexture UnityEngine.Texture
---@field public alphaTexture UnityEngine.Texture
---@field public material UnityEngine.Material
---@field public shader UnityEngine.Shader
---@field public premultipliedAlpha boolean
---@field public uvRect UnityEngine.Rect
local m = {}

---@virtual
function m:MakePixelPerfect() end

UITextureEx = m
return m
