---@class UIDrawCall : UnityEngine.MonoBehaviour
---@field public list BetterList_1_UIDrawCall_ @static
---@field public activeList BetterList_1_UIDrawCall_ @static
---@field public inactiveList BetterList_1_UIDrawCall_ @static
---@field public widgetCount number
---@field public depthStart number
---@field public depthEnd number
---@field public manager UIPanel
---@field public panel UIPanel
---@field public clipTexture UnityEngine.Texture2D
---@field public alwaysOnScreen boolean
---@field public verts UnityEngine.Vector3[]
---@field public norms UnityEngine.Vector3[]
---@field public tans UnityEngine.Vector4[]
---@field public uvs UnityEngine.Vector2[]
---@field public uv2 UnityEngine.Vector4[]
---@field public cols UnityEngine.Color[]
---@field public isDirty boolean
---@field public onRender fun(mat:UnityEngine.Material)
---@field public onCreateDrawCall fun(dc:UIDrawCall, filter:UnityEngine.MeshFilter, ren:UnityEngine.MeshRenderer)
---@field public onRenderQueueChanged fun(renderQueue:number)
---@field public renderQueue number
---@field public sortingOrder number
---@field public sortingLayerName string
---@field public finalRenderQueue number
---@field public isActive boolean
---@field public cachedTransform UnityEngine.Transform
---@field public baseMaterial UnityEngine.Material
---@field public dynamicMaterial UnityEngine.Material
---@field public mainTexture UnityEngine.Texture
---@field public alphaTexture UnityEngine.Texture
---@field public shader UnityEngine.Shader
---@field public shadowMode UIDrawCall.ShadowMode
---@field public triangles number
---@field public isClipped boolean
local m = {}

---@param widgetCount number
function m:UpdateGeometry(widgetCount) end

function m:UpdateBlankGeometry() end

---@static
---@param panel UIPanel
---@param mat UnityEngine.Material
---@param tex UnityEngine.Texture
---@param alphaTex UnityEngine.Texture
---@param shader UnityEngine.Shader
---@return UIDrawCall
function m.Create(panel, mat, tex, alphaTex, shader) end

---@static
function m.ClearAll() end

---@static
function m.ReleaseAll() end

---@static
function m.ReleaseInactive() end

---@static
---@param panel UIPanel
---@return number
function m.Count(panel) end

---@static
---@param dc UIDrawCall
function m.Destroy(dc) end

---@static
---@param scene UnityEngine.SceneManagement.Scene
function m.MoveToScene(scene) end

UIDrawCall = m
return m
