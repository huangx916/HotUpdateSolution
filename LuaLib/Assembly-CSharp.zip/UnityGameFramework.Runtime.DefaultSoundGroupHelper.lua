---@class UnityGameFramework.Runtime.DefaultSoundGroupHelper : UnityGameFramework.Runtime.SoundGroupHelperBase
local m = {}

UnityGameFramework.Runtime.DefaultSoundGroupHelper = m
return m
