---@class UICamera.ClickNotification : System.Enum
---@field public None UICamera.ClickNotification @static
---@field public Always UICamera.ClickNotification @static
---@field public BasedOnDelta UICamera.ClickNotification @static
---@field public value__ number
local m = {}

UICamera.ClickNotification = m
return m
