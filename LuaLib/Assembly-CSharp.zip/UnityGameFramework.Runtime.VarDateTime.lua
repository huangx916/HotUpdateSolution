---@class UnityGameFramework.Runtime.VarDateTime : GameFramework.Variable_1_System_DateTime_
local m = {}

---@overload fun(value:UnityGameFramework.Runtime.VarDateTime):System.DateTime @static
---@static
---@param value System.DateTime
---@return UnityGameFramework.Runtime.VarDateTime
function m.op_Implicit(value) end

UnityGameFramework.Runtime.VarDateTime = m
return m
