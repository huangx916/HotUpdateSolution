---@class UnityGameFramework.Runtime.LoadDataTableDependencyAssetEventArgs : GameFramework.Event.GameEventArgs
---@field public Id number
---@field public DataTableName string
---@field public DataTableType System.Type
---@field public DataTableAssetName string
---@field public DependencyAssetName string
---@field public LoadedCount number
---@field public TotalCount number
---@field public UserData any
local m = {}

UnityGameFramework.Runtime.LoadDataTableDependencyAssetEventArgs = m
return m
