---@class UIEventListener : UnityEngine.MonoBehaviour
---@field public listenerTag string
---@field public parameter any
---@field public onEnabled fun(arg1:UnityEngine.GameObject, arg2:boolean)
---@field public onSubmit fun(obj:UnityEngine.GameObject)
---@field public onClick fun(obj:UnityEngine.GameObject)
---@field public onDoubleClick fun(obj:UnityEngine.GameObject)
---@field public onHover fun(arg1:UnityEngine.GameObject, arg2:boolean)
---@field public onPress fun(arg1:UnityEngine.GameObject, arg2:boolean)
---@field public onSelect fun(arg1:UnityEngine.GameObject, arg2:boolean)
---@field public onScroll fun(arg1:UnityEngine.GameObject, arg2:number)
---@field public onDragStart fun(obj:UnityEngine.GameObject)
---@field public onDrag fun(arg1:UnityEngine.GameObject, arg2:UnityEngine.Vector2)
---@field public onDragOver fun(obj:UnityEngine.GameObject)
---@field public onDragOut fun(obj:UnityEngine.GameObject)
---@field public onDragEnd fun(obj:UnityEngine.GameObject)
---@field public onDrop fun(arg1:UnityEngine.GameObject, arg2:UnityEngine.GameObject)
---@field public onKey fun(arg1:UnityEngine.GameObject, arg2:UnityEngine.KeyCode)
---@field public onTooltip fun(arg1:UnityEngine.GameObject, arg2:boolean)
local m = {}

function m:Clear() end

---@overload fun(go:UnityEngine.GameObject, listenerTag:string):UIEventListener @static
---@static
---@param go UnityEngine.GameObject
---@return UIEventListener
function m.Get(go) end

UIEventListener = m
return m
