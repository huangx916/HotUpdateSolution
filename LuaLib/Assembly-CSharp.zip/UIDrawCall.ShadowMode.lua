---@class UIDrawCall.ShadowMode : System.Enum
---@field public None UIDrawCall.ShadowMode @static
---@field public Receive UIDrawCall.ShadowMode @static
---@field public CastAndReceive UIDrawCall.ShadowMode @static
---@field public value__ number
local m = {}

UIDrawCall.ShadowMode = m
return m
