---@class UnityGameFramework.Runtime.VarQuaternion : GameFramework.Variable_1_UnityEngine_Quaternion_
local m = {}

---@overload fun(value:UnityGameFramework.Runtime.VarQuaternion):UnityEngine.Quaternion @static
---@static
---@param value UnityEngine.Quaternion
---@return UnityGameFramework.Runtime.VarQuaternion
function m.op_Implicit(value) end

UnityGameFramework.Runtime.VarQuaternion = m
return m
