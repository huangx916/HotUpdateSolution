---@class UnityGameFramework.Runtime.WebRequestSuccessEventArgs : GameFramework.Event.GameEventArgs
---@field public Id number
---@field public SerialId number
---@field public WebRequestUri string
---@field public UserData any
local m = {}

---@return string
function m:GetWebResponseBytes() end

UnityGameFramework.Runtime.WebRequestSuccessEventArgs = m
return m
