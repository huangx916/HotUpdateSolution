---@class UnityGameFramework.Runtime.DefaultNetworkHelper : UnityGameFramework.Runtime.NetworkHelperBase
local m = {}

---@virtual
---@param networkChannel GameFramework.Network.INetworkChannel
---@return boolean
function m:SendHeartBeat(networkChannel) end

---@virtual
---@param networkChannel GameFramework.Network.INetworkChannel
---@param destination System.IO.Stream
---@param packet GameFramework.Network.Packet
function m:Serialize(networkChannel, destination, packet) end

---@virtual
---@param networkChannel GameFramework.Network.INetworkChannel
---@param source System.IO.Stream
---@return GameFramework.Network.Packet, System.Object
function m:Deserialize(networkChannel, source) end

UnityGameFramework.Runtime.DefaultNetworkHelper = m
return m
