---@class UnityGameFramework.Runtime.VarRect : GameFramework.Variable_1_UnityEngine_Rect_
local m = {}

---@overload fun(value:UnityGameFramework.Runtime.VarRect):UnityEngine.Rect @static
---@static
---@param value UnityEngine.Rect
---@return UnityGameFramework.Runtime.VarRect
function m.op_Implicit(value) end

UnityGameFramework.Runtime.VarRect = m
return m
