---@class TweenRotation : UITweener
---@field public from UnityEngine.Vector3
---@field public to UnityEngine.Vector3
---@field public quaternionLerp boolean
---@field public cachedTransform UnityEngine.Transform
---@field public rotation UnityEngine.Quaternion
---@field public value UnityEngine.Quaternion
local m = {}

---@static
---@param go UnityEngine.GameObject
---@param duration number
---@param rot UnityEngine.Quaternion
---@return TweenRotation
function m.Begin(go, duration, rot) end

---@virtual
function m:SetStartToCurrentValue() end

---@virtual
function m:SetEndToCurrentValue() end

TweenRotation = m
return m
