---@class UICamera.GetKeyStateFunc : System.MulticastDelegate
local m = {}

---@virtual
---@param key UnityEngine.KeyCode
---@return boolean
function m:Invoke(key) end

---@virtual
---@param key UnityEngine.KeyCode
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(key, callback, object) end

---@virtual
---@param result System.IAsyncResult
---@return boolean
function m:EndInvoke(result) end

UICamera.GetKeyStateFunc = m
return m
