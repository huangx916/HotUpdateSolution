---@class UICamera.VectorDelegate : System.MulticastDelegate
local m = {}

---@virtual
---@param go UnityEngine.GameObject
---@param delta UnityEngine.Vector2
function m:Invoke(go, delta) end

---@virtual
---@param go UnityEngine.GameObject
---@param delta UnityEngine.Vector2
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(go, delta, callback, object) end

---@virtual
---@param result System.IAsyncResult
function m:EndInvoke(result) end

UICamera.VectorDelegate = m
return m
