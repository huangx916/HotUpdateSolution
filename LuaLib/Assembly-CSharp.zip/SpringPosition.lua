---@class SpringPosition : UnityEngine.MonoBehaviour
---@field public current SpringPosition @static
---@field public target UnityEngine.Vector3
---@field public strength number
---@field public worldSpace boolean
---@field public ignoreTimeScale boolean
---@field public updateScrollView boolean
---@field public onFinished fun()
---@field public callWhenFinished string
local m = {}

---@static
---@param go UnityEngine.GameObject
---@param pos UnityEngine.Vector3
---@param strength number
---@return SpringPosition
function m.Begin(go, pos, strength) end

SpringPosition = m
return m
