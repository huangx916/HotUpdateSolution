---@class UICamera.RemoveTouchDelegate : System.MulticastDelegate
local m = {}

---@virtual
---@param id number
function m:Invoke(id) end

---@virtual
---@param id number
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(id, callback, object) end

---@virtual
---@param result System.IAsyncResult
function m:EndInvoke(result) end

UICamera.RemoveTouchDelegate = m
return m
