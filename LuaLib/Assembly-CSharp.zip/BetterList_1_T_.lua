---@class BetterList_1_T_ : System.Object
---@field public buffer any[]
---@field public size number
---@field public Item any
local m = {}

---@return System.Collections.Generic.IEnumerator_1_T_
function m:GetEnumerator() end

function m:Clear() end

function m:Release() end

---@param item any
function m:Add(item) end

---@param index number
---@param item any
function m:Insert(index, item) end

---@param item any
---@return boolean
function m:Contains(item) end

---@param item any
---@return number
function m:IndexOf(item) end

---@param item any
---@return boolean
function m:Remove(item) end

---@param index number
function m:RemoveAt(index) end

---@return any
function m:Pop() end

---@return any[]
function m:ToArray() end

---@param comparer fun(left:any, right:any):number
function m:Sort(comparer) end

BetterList_1_T_ = m
return m
