---@class UIPopupList.Position : System.Enum
---@field public Auto UIPopupList.Position @static
---@field public Above UIPopupList.Position @static
---@field public Below UIPopupList.Position @static
---@field public value__ number
local m = {}

UIPopupList.Position = m
return m
