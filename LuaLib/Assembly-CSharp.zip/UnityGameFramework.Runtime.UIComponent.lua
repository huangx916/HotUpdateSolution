---@class UnityGameFramework.Runtime.UIComponent : UnityGameFramework.Runtime.GameFrameworkComponent
---@field public UIGroupCount number
---@field public InstanceAutoReleaseInterval number
---@field public InstanceCapacity number
---@field public InstanceExpireTime number
---@field public InstancePriority number
local m = {}

---@param uiGroupName string
---@return boolean
function m:HasUIGroup(uiGroupName) end

---@param uiGroupName string
---@return GameFramework.UI.IUIGroup
function m:GetUIGroup(uiGroupName) end

---@return GameFramework.UI.IUIGroup[]
function m:GetAllUIGroups() end

---@overload fun(uiGroupName:string, depth:number):boolean
---@param uiGroupName string
---@return boolean
function m:AddUIGroup(uiGroupName) end

---@overload fun(uiFormAssetName:string):boolean
---@param serialId number
---@return boolean
function m:HasUIForm(serialId) end

---@overload fun(uiFormAssetName:string):UnityGameFramework.Runtime.UIForm
---@param serialId number
---@return UnityGameFramework.Runtime.UIForm
function m:GetUIForm(serialId) end

---@param uiFormAssetName string
---@return UnityGameFramework.Runtime.UIForm[]
function m:GetUIForms(uiFormAssetName) end

---@return UnityGameFramework.Runtime.UIForm[]
function m:GetAllLoadedUIForms() end

---@return number[]
function m:GetAllLoadingUIFormSerialIds() end

---@overload fun(uiFormAssetName:string):boolean
---@param serialId number
---@return boolean
function m:IsLoadingUIForm(serialId) end

---@param uiForm UnityGameFramework.Runtime.UIForm
---@return boolean
function m:IsValidUIForm(uiForm) end

---@overload fun(uiFormAssetName:string, uiGroupName:string, pauseCoveredUIForm:boolean):number
---@overload fun(uiFormAssetName:string, uiGroupName:string, userData:any):number
---@overload fun(uiFormAssetName:string, uiGroupName:string, pauseCoveredUIForm:boolean, userData:any):number
---@param uiFormAssetName string
---@param uiGroupName string
---@return number
function m:OpenUIForm(uiFormAssetName, uiGroupName) end

---@overload fun(serialId:number, userData:any)
---@overload fun(uiForm:UnityGameFramework.Runtime.UIForm)
---@overload fun(uiForm:UnityGameFramework.Runtime.UIForm, userData:any)
---@param serialId number
function m:CloseUIForm(serialId) end

---@overload fun(userData:any)
function m:CloseAllLoadedUIForms() end

function m:CloseAllLoadingUIForms() end

---@overload fun(uiForm:UnityGameFramework.Runtime.UIForm, userData:any)
---@param uiForm UnityGameFramework.Runtime.UIForm
function m:RefocusUIForm(uiForm) end

---@param uiForm UnityGameFramework.Runtime.UIForm
---@param locked boolean
function m:SetUIFormLocked(uiForm, locked) end

---@param uiForm UnityGameFramework.Runtime.UIForm
---@param priority number
function m:SetUIFormPriority(uiForm, priority) end

UnityGameFramework.Runtime.UIComponent = m
return m
