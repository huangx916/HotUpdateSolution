---@class TweenLetters : UITweener
---@field public hoverOver TweenLetters.AnimationProperties
---@field public hoverOut TweenLetters.AnimationProperties
local m = {}

---@virtual
---@param forward boolean
function m:Play(forward) end

TweenLetters = m
return m
