---@class UnityGameFramework.Runtime.VarObject : GameFramework.Variable_1_System_Object_
local m = {}

UnityGameFramework.Runtime.VarObject = m
return m
