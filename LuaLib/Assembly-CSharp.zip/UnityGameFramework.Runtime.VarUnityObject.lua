---@class UnityGameFramework.Runtime.VarUnityObject : GameFramework.Variable_1_UnityEngine_Object_
local m = {}

---@overload fun(value:UnityGameFramework.Runtime.VarUnityObject):UnityEngine.Object @static
---@static
---@param value UnityEngine.Object
---@return UnityGameFramework.Runtime.VarUnityObject
function m.op_Implicit(value) end

UnityGameFramework.Runtime.VarUnityObject = m
return m
