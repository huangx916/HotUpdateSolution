---@class UILabel.ModifierFunc : System.MulticastDelegate
local m = {}

---@virtual
---@param s string
---@return string
function m:Invoke(s) end

---@virtual
---@param s string
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(s, callback, object) end

---@virtual
---@param result System.IAsyncResult
---@return string
function m:EndInvoke(result) end

UILabel.ModifierFunc = m
return m
