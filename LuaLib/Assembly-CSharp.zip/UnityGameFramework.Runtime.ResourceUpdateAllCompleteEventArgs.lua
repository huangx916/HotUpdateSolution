---@class UnityGameFramework.Runtime.ResourceUpdateAllCompleteEventArgs : GameFramework.Event.GameEventArgs
---@field public Id number
local m = {}

UnityGameFramework.Runtime.ResourceUpdateAllCompleteEventArgs = m
return m
