---@class UnityGameFramework.Runtime.WebRequestComponent : UnityGameFramework.Runtime.GameFrameworkComponent
---@field public TotalAgentCount number
---@field public FreeAgentCount number
---@field public WorkingAgentCount number
---@field public WaitingTaskCount number
---@field public Timeout number
local m = {}

---@overload fun(webRequestUri:string, postData:string):number
---@overload fun(webRequestUri:string, wwwForm:UnityEngine.WWWForm):number
---@overload fun(webRequestUri:string, userData:any):number
---@overload fun(webRequestUri:string, postData:string, userData:any):number
---@overload fun(webRequestUri:string, wwwForm:UnityEngine.WWWForm, userData:any):number
---@param webRequestUri string
---@return number
function m:AddWebRequest(webRequestUri) end

---@param serialId number
---@return boolean
function m:RemoveWebRequest(serialId) end

function m:RemoveAllWebRequests() end

UnityGameFramework.Runtime.WebRequestComponent = m
return m
