---@class UnityGameFramework.Runtime.DebuggerComponent.QualitySettingsWindow : UnityGameFramework.Runtime.DebuggerComponent.ScrollableDebuggerWindowBase
local m = {}

UnityGameFramework.Runtime.DebuggerComponent.QualitySettingsWindow = m
return m
