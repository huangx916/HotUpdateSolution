---@class UITextList.Style : System.Enum
---@field public Text UITextList.Style @static
---@field public Chat UITextList.Style @static
---@field public value__ number
local m = {}

UITextList.Style = m
return m
