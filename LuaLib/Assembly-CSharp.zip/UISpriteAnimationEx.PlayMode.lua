---@class UISpriteAnimationEx.PlayMode : System.Enum
---@field public OnEnable UISpriteAnimationEx.PlayMode @static
---@field public OnAwake UISpriteAnimationEx.PlayMode @static
---@field public OnStart UISpriteAnimationEx.PlayMode @static
---@field public value__ number
local m = {}

UISpriteAnimationEx.PlayMode = m
return m
