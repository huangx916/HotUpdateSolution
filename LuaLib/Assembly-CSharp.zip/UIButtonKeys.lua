---@class UIButtonKeys : UIKeyNavigation
---@field public selectOnClick UIButtonKeys
---@field public selectOnUp UIButtonKeys
---@field public selectOnDown UIButtonKeys
---@field public selectOnLeft UIButtonKeys
---@field public selectOnRight UIButtonKeys
local m = {}

function m:Upgrade() end

UIButtonKeys = m
return m
