---@class UnityGameFramework.Runtime.EntityLogic : UnityEngine.MonoBehaviour
---@field public Entity UnityGameFramework.Runtime.Entity
---@field public Name string
---@field public IsAvailable boolean
---@field public CachedTransform UnityEngine.Transform
local m = {}

UnityGameFramework.Runtime.EntityLogic = m
return m
