---@class UILabel.Modifier : System.Enum
---@field public None UILabel.Modifier @static
---@field public ToUppercase UILabel.Modifier @static
---@field public ToLowercase UILabel.Modifier @static
---@field public Custom UILabel.Modifier @static
---@field public value__ number
local m = {}

UILabel.Modifier = m
return m
