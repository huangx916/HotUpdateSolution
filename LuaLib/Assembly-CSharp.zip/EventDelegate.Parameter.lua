---@class EventDelegate.Parameter : System.Object
---@field public obj UnityEngine.Object
---@field public field string
---@field public expectedType System.Type
---@field public cached boolean
---@field public propInfo System.Reflection.PropertyInfo
---@field public fieldInfo System.Reflection.FieldInfo
---@field public value any
---@field public type System.Type
local m = {}

EventDelegate.Parameter = m
return m
