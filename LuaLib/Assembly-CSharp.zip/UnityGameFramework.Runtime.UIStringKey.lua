---@class UnityGameFramework.Runtime.UIStringKey : UnityEngine.MonoBehaviour
---@field public Key string
local m = {}

UnityGameFramework.Runtime.UIStringKey = m
return m
