---@class UnityGameFramework.Runtime.DebuggerComponent.WebPlayerInformationWindow : UnityGameFramework.Runtime.DebuggerComponent.ScrollableDebuggerWindowBase
local m = {}

UnityGameFramework.Runtime.DebuggerComponent.WebPlayerInformationWindow = m
return m
