---@class UnityGameFramework.Runtime.SoundAgentHelperBase : UnityEngine.MonoBehaviour
---@field public IsPlaying boolean
---@field public Time number
---@field public Mute boolean
---@field public Loop boolean
---@field public Priority number
---@field public Volume number
---@field public Pitch number
---@field public PanStereo number
---@field public SpatialBlend number
---@field public MaxDistance number
---@field public AudioMixerGroup UnityEngine.Audio.AudioMixerGroup
local m = {}

---@abstract
---@param value fun(sender:any, e:GameFramework.Sound.ResetSoundAgentEventArgs)
function m:add_ResetSoundAgent(value) end

---@abstract
---@param value fun(sender:any, e:GameFramework.Sound.ResetSoundAgentEventArgs)
function m:remove_ResetSoundAgent(value) end

---@abstract
---@param fadeInSeconds number
function m:Play(fadeInSeconds) end

---@abstract
---@param fadeOutSeconds number
function m:Stop(fadeOutSeconds) end

---@abstract
---@param fadeOutSeconds number
function m:Pause(fadeOutSeconds) end

---@abstract
---@param fadeInSeconds number
function m:Resume(fadeInSeconds) end

---@abstract
function m:Reset() end

---@abstract
---@param soundAsset any
---@return boolean
function m:SetSoundAsset(soundAsset) end

---@abstract
---@param bindingEntity UnityGameFramework.Runtime.Entity
function m:SetBindingEntity(bindingEntity) end

---@abstract
---@param worldPosition UnityEngine.Vector3
function m:SetWorldPosition(worldPosition) end

UnityGameFramework.Runtime.SoundAgentHelperBase = m
return m
