---@class UnityGameFramework.Runtime.VarDouble : GameFramework.Variable_1_System_Double_
local m = {}

---@overload fun(value:UnityGameFramework.Runtime.VarDouble):number @static
---@static
---@param value number
---@return UnityGameFramework.Runtime.VarDouble
function m.op_Implicit(value) end

UnityGameFramework.Runtime.VarDouble = m
return m
