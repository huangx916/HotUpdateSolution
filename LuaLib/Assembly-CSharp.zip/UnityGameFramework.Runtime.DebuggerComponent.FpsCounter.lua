---@class UnityGameFramework.Runtime.DebuggerComponent.FpsCounter : System.Object
---@field public UpdateInterval number
---@field public CurrentFps number
local m = {}

---@param elapseSeconds number
---@param realElapseSeconds number
function m:Update(elapseSeconds, realElapseSeconds) end

UnityGameFramework.Runtime.DebuggerComponent.FpsCounter = m
return m
