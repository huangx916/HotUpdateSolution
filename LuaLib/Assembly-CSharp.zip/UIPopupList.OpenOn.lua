---@class UIPopupList.OpenOn : System.Enum
---@field public ClickOrTap UIPopupList.OpenOn @static
---@field public RightClick UIPopupList.OpenOn @static
---@field public DoubleClick UIPopupList.OpenOn @static
---@field public Manual UIPopupList.OpenOn @static
---@field public value__ number
local m = {}

UIPopupList.OpenOn = m
return m
