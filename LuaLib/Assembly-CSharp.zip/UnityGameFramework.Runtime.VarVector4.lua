---@class UnityGameFramework.Runtime.VarVector4 : GameFramework.Variable_1_UnityEngine_Vector4_
local m = {}

---@overload fun(value:UnityGameFramework.Runtime.VarVector4):UnityEngine.Vector4 @static
---@static
---@param value UnityEngine.Vector4
---@return UnityGameFramework.Runtime.VarVector4
function m.op_Implicit(value) end

UnityGameFramework.Runtime.VarVector4 = m
return m
