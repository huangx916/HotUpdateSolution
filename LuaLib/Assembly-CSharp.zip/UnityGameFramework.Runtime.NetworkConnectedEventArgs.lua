---@class UnityGameFramework.Runtime.NetworkConnectedEventArgs : GameFramework.Event.GameEventArgs
---@field public Id number
---@field public NetworkChannel GameFramework.Network.INetworkChannel
---@field public UserData any
local m = {}

UnityGameFramework.Runtime.NetworkConnectedEventArgs = m
return m
