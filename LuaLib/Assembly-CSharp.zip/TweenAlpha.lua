---@class TweenAlpha : UITweener
---@field public from number
---@field public to number
---@field public alpha number
---@field public value number
local m = {}

---@overload fun(go:UnityEngine.GameObject, duration:number, alpha:number):TweenAlpha @static
---@static
---@param go UnityEngine.GameObject
---@param duration number
---@param alpha number
---@param delay number
---@return TweenAlpha
function m.Begin(go, duration, alpha, delay) end

---@virtual
function m:SetStartToCurrentValue() end

---@virtual
function m:SetEndToCurrentValue() end

TweenAlpha = m
return m
