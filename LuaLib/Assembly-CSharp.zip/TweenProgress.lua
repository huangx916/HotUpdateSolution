---@class TweenProgress : UITweener
---@field public from number
---@field public to number
---@field public progress number
---@field public value number
local m = {}

---@static
---@param go UnityEngine.GameObject
---@param duration number
---@param progress number
---@return TweenProgress
function m.Begin(go, duration, progress) end

---@virtual
function m:SetStartToCurrentValue() end

---@virtual
function m:SetEndToCurrentValue() end

TweenProgress = m
return m
