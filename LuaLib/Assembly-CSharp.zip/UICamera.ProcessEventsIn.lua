---@class UICamera.ProcessEventsIn : System.Enum
---@field public Update UICamera.ProcessEventsIn @static
---@field public LateUpdate UICamera.ProcessEventsIn @static
---@field public value__ number
local m = {}

UICamera.ProcessEventsIn = m
return m
