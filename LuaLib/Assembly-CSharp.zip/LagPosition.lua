---@class LagPosition : UnityEngine.MonoBehaviour
---@field public speed UnityEngine.Vector3
---@field public ignoreTimeScale boolean
local m = {}

function m:OnRepositionEnd() end

function m:ResetPosition() end

LagPosition = m
return m
