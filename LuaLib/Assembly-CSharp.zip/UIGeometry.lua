---@class UIGeometry : System.Object
---@field public verts UnityEngine.Vector3[]
---@field public uvs UnityEngine.Vector2[]
---@field public cols UnityEngine.Color[]
---@field public onCustomWrite fun(v:UnityEngine.Vector3[], u:UnityEngine.Vector2[], c:UnityEngine.Color[], n:UnityEngine.Vector3[], t:UnityEngine.Vector4[], u2:UnityEngine.Vector4[])
---@field public hasVertices boolean
---@field public hasTransformed boolean
local m = {}

function m:Clear() end

---@overload fun(widgetToPanel:UnityEngine.Matrix4x4)
---@param widgetToPanel UnityEngine.Matrix4x4
---@param generateNormals boolean
function m:ApplyTransform(widgetToPanel, generateNormals) end

---@param v UnityEngine.Vector3[]
---@param u UnityEngine.Vector2[]
---@param c UnityEngine.Color[]
---@param n UnityEngine.Vector3[]
---@param t UnityEngine.Vector4[]
---@param u2 UnityEngine.Vector4[]
function m:WriteToBuffers(v, u, c, n, t, u2) end

UIGeometry = m
return m
