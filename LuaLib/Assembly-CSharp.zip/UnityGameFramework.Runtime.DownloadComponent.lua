---@class UnityGameFramework.Runtime.DownloadComponent : UnityGameFramework.Runtime.GameFrameworkComponent
---@field public TotalAgentCount number
---@field public FreeAgentCount number
---@field public WorkingAgentCount number
---@field public WaitingTaskCount number
---@field public Timeout number
---@field public FlushSize number
---@field public CurrentSpeed number
local m = {}

---@overload fun(downloadPath:string, downloadUri:string, userData:any):number
---@param downloadPath string
---@param downloadUri string
---@return number
function m:AddDownload(downloadPath, downloadUri) end

---@param serialId number
function m:RemoveDownload(serialId) end

function m:RemoveAllDownload() end

UnityGameFramework.Runtime.DownloadComponent = m
return m
