---@class UnityGameFramework.Runtime.SceneAsset : System.Object
local m = {}

UnityGameFramework.Runtime.SceneAsset = m
return m
