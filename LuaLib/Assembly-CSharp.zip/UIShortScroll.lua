---@class UIShortScroll : UnityEngine.MonoBehaviour
---@field public itemPrefab UIRect
---@field public space number
---@field public itemRadius number
---@field public prevRefresh number
---@field public momentumOffset number
---@field public progressBar UISlider
---@field public itemIndexLabel UILabel
---@field public hideBarWhenStop boolean
---@field public onUpdateItem fun(arg1:UnityEngine.Transform, arg2:number)
---@field public alignEnable boolean
---@field public alignType UIShortScroll.AlignType
---@field public springStrength number
---@field public nextPageThreshold number
---@field public restrictEnable boolean
---@field public basedOnSoftness boolean
---@field public onFinished fun()
---@field public onAlign fun(obj:number)
---@field public Offset number
---@field public CurrentIndex number
---@field public CurrentTrans UnityEngine.Transform
---@field public alignedIndex number
local m = {}

---@param callback fun(obj:UnityEngine.Transform)
function m:InitItems(callback) end

---@overload fun(count:number)
---@param count number
---@param targetIndex number
function m:StartScroll(count, targetIndex) end

---@overload fun(dispose:(fun(obj:UnityEngine.Transform)))
---@overload fun()
---@param dispose fun(obj:UnityEngine.Transform)
---@param delayUnload number
function m:StopScroll(dispose, delayUnload) end

---@param index number
---@return UnityEngine.Transform
function m:GetItem(index) end

---@overload fun(removeIndex:number):number
---@param removeIndex number
---@param callback fun(obj:UnityEngine.Transform)
---@return number
function m:RemoveAt(removeIndex, callback) end

---@overload fun(insertIndex:number):number
---@param insertIndex number
---@param callback fun(obj:UnityEngine.Transform)
---@return number
function m:InsertAt(insertIndex, callback) end

---@param count number
function m:UpdateCount(count) end

---@param itemIdex number
function m:UpdateItem(itemIdex) end

---@overload fun(updateList:number[])
---@overload fun()
---@param updateList number[]
---@param exceptList number[]
function m:UpdateItems(updateList, exceptList) end

---@param offset number
---@return number
function m:Move(offset) end

function m:Realign() end

---@overload fun()
---@param immediately boolean
function m:StopAlign(immediately) end

---@overload fun(index:number)
---@param index number
---@param immediately boolean
function m:AlignOn(index, immediately) end

UIShortScroll = m
return m
