---@class UnityGameFramework.Runtime.ShowEntityUpdateEventArgs : GameFramework.Event.GameEventArgs
---@field public Id number
---@field public EntityId number
---@field public EntityLogicType System.Type
---@field public EntityAssetName string
---@field public EntityGroupName string
---@field public Progress number
---@field public UserData any
local m = {}

UnityGameFramework.Runtime.ShowEntityUpdateEventArgs = m
return m
