---@class TweenFOV : UITweener
---@field public from number
---@field public to number
---@field public cachedCamera UnityEngine.Camera
---@field public fov number
---@field public value number
local m = {}

---@static
---@param go UnityEngine.GameObject
---@param duration number
---@param to number
---@return TweenFOV
function m.Begin(go, duration, to) end

---@virtual
function m:SetStartToCurrentValue() end

---@virtual
function m:SetEndToCurrentValue() end

TweenFOV = m
return m
