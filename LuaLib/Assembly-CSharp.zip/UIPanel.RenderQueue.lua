---@class UIPanel.RenderQueue : System.Enum
---@field public Automatic UIPanel.RenderQueue @static
---@field public StartAt UIPanel.RenderQueue @static
---@field public Explicit UIPanel.RenderQueue @static
---@field public value__ number
local m = {}

UIPanel.RenderQueue = m
return m
