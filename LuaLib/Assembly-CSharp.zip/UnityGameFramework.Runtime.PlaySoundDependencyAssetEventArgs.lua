---@class UnityGameFramework.Runtime.PlaySoundDependencyAssetEventArgs : GameFramework.Event.GameEventArgs
---@field public Id number
---@field public SerialId number
---@field public SoundAssetName string
---@field public SoundGroupName string
---@field public PlaySoundParams GameFramework.Sound.PlaySoundParams
---@field public DependencyAssetName string
---@field public LoadedCount number
---@field public TotalCount number
---@field public BindingEntity UnityGameFramework.Runtime.Entity
---@field public UserData any
local m = {}

UnityGameFramework.Runtime.PlaySoundDependencyAssetEventArgs = m
return m
