---@class UnityGameFramework.Runtime.ResourceHelperBase : UnityEngine.MonoBehaviour
local m = {}

---@abstract
---@param fileUri string
---@param loadBytesCallback fun(fileUri:string, bytes:string, errorMessage:string)
function m:LoadBytes(fileUri, loadBytesCallback) end

---@abstract
---@param sceneAssetName string
---@param unloadSceneCallbacks GameFramework.Resource.UnloadSceneCallbacks
---@param userData any
function m:UnloadScene(sceneAssetName, unloadSceneCallbacks, userData) end

---@abstract
---@param objectToRelease any
function m:Release(objectToRelease) end

UnityGameFramework.Runtime.ResourceHelperBase = m
return m
