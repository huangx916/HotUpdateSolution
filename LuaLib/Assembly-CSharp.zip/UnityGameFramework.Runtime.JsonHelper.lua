---@class UnityGameFramework.Runtime.JsonHelper : System.Object
local m = {}

---@virtual
---@param obj any
---@return string
function m:ToJson(obj) end

---@virtual
---@param json string
---@return any
function m:ToObject(json) end

UnityGameFramework.Runtime.JsonHelper = m
return m
