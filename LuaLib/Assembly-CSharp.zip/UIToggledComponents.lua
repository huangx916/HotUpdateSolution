---@class UIToggledComponents : UnityEngine.MonoBehaviour
---@field public activate UnityEngine.MonoBehaviour[]
---@field public deactivate UnityEngine.MonoBehaviour[]
local m = {}

function m:Toggle() end

UIToggledComponents = m
return m
