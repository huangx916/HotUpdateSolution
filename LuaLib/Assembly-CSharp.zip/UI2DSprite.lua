---@class UI2DSprite : UIBasicSprite
---@field public nextSprite UnityEngine.Sprite
---@field public sprite2D UnityEngine.Sprite
---@field public alphaSprite2D UnityEngine.Sprite
---@field public material UnityEngine.Material
---@field public shader UnityEngine.Shader
---@field public mainTexture UnityEngine.Texture
---@field public alphaTexture UnityEngine.Texture
---@field public fixedAspect boolean
---@field public premultipliedAlpha boolean
---@field public pixelSize number
---@field public drawingDimensions UnityEngine.Vector4
---@field public border UnityEngine.Vector4
---@field public flippedBorder UnityEngine.Vector4
local m = {}

---@param newDepth number
function m:SetDepth(newDepth) end

---@virtual
function m:MakePixelPerfect() end

---@virtual
---@param verts UnityEngine.Vector3[]
---@param uvs UnityEngine.Vector2[]
---@param cols UnityEngine.Color[]
function m:OnFill(verts, uvs, cols) end

UI2DSprite = m
return m
