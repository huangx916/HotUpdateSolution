---@class UnityGameFramework.Runtime.DebuggerComponent.InputLocationInformationWindow : UnityGameFramework.Runtime.DebuggerComponent.ScrollableDebuggerWindowBase
local m = {}

UnityGameFramework.Runtime.DebuggerComponent.InputLocationInformationWindow = m
return m
