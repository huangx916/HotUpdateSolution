---@class TweenLetters.LetterProperties : System.Object
---@field public start number
---@field public duration number
---@field public offset UnityEngine.Vector2
local m = {}

TweenLetters.LetterProperties = m
return m
