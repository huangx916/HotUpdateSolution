---@class RealTime : UnityEngine.MonoBehaviour
---@field public time number @static
---@field public deltaTime number @static
local m = {}

RealTime = m
return m
