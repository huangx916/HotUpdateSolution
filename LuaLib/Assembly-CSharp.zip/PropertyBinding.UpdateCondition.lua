---@class PropertyBinding.UpdateCondition : System.Enum
---@field public OnStart PropertyBinding.UpdateCondition @static
---@field public OnUpdate PropertyBinding.UpdateCondition @static
---@field public OnLateUpdate PropertyBinding.UpdateCondition @static
---@field public OnFixedUpdate PropertyBinding.UpdateCondition @static
---@field public OnEndOfFirstFrame PropertyBinding.UpdateCondition @static
---@field public value__ number
local m = {}

PropertyBinding.UpdateCondition = m
return m
