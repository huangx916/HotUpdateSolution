---@class UnityGameFramework.Runtime.VarBytes : GameFramework.Variable_1_System_Byte___
local m = {}

---@overload fun(value:UnityGameFramework.Runtime.VarBytes):string @static
---@static
---@param value string
---@return UnityGameFramework.Runtime.VarBytes
function m.op_Implicit(value) end

UnityGameFramework.Runtime.VarBytes = m
return m
