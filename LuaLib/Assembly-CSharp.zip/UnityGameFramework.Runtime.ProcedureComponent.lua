---@class UnityGameFramework.Runtime.ProcedureComponent : UnityGameFramework.Runtime.GameFrameworkComponent
---@field public CurrentProcedure GameFramework.Procedure.ProcedureBase
local m = {}

---@return boolean
function m:HasProcedure() end

---@return GameFramework.Procedure.ProcedureBase
function m:GetProcedure() end

UnityGameFramework.Runtime.ProcedureComponent = m
return m
