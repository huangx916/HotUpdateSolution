---@class UnityGameFramework.Runtime.DebuggerComponent : UnityGameFramework.Runtime.GameFrameworkComponent
---@field public ActiveWindow boolean
---@field public ShowFullWindow boolean
---@field public IconRect UnityEngine.Rect
---@field public WindowRect UnityEngine.Rect
---@field public WindowScale number
local m = {}

---@overload fun(path:string, debuggerWindow:GameFramework.Debugger.IDebuggerWindow)
---@param path string
---@param debuggerWindow GameFramework.Debugger.IDebuggerWindow
---@param args any[]|any
function m:RegisterDebuggerWindow(path, debuggerWindow, args) end

---@param path string
---@return GameFramework.Debugger.IDebuggerWindow
function m:GetDebuggerWindow(path) end

UnityGameFramework.Runtime.DebuggerComponent = m
return m
