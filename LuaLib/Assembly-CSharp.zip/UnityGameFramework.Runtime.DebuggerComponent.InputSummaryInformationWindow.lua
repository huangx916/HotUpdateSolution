---@class UnityGameFramework.Runtime.DebuggerComponent.InputSummaryInformationWindow : UnityGameFramework.Runtime.DebuggerComponent.ScrollableDebuggerWindowBase
local m = {}

UnityGameFramework.Runtime.DebuggerComponent.InputSummaryInformationWindow = m
return m
