---@class UnityGameFramework.Runtime.DebuggerComponent.OperationSettingsWindow : UnityGameFramework.Runtime.DebuggerComponent.ScrollableDebuggerWindowBase
local m = {}

UnityGameFramework.Runtime.DebuggerComponent.OperationSettingsWindow = m
return m
