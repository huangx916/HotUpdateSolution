---@class UISoundVolume : UnityEngine.MonoBehaviour
local m = {}

UISoundVolume = m
return m
