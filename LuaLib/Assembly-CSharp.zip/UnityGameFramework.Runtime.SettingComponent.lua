---@class UnityGameFramework.Runtime.SettingComponent : UnityGameFramework.Runtime.GameFrameworkComponent
local m = {}

function m:Save() end

---@param key string
---@return boolean
function m:HasKey(key) end

---@param key string
function m:RemoveKey(key) end

function m:RemoveAllKeys() end

---@overload fun(key:string, defaultValue:boolean):boolean
---@param key string
---@return boolean
function m:GetBool(key) end

---@param key string
---@param value boolean
function m:SetBool(key, value) end

---@overload fun(key:string, defaultValue:number):number
---@param key string
---@return number
function m:GetInt(key) end

---@param key string
---@param value number
function m:SetInt(key, value) end

---@overload fun(key:string, defaultValue:number):number
---@param key string
---@return number
function m:GetFloat(key) end

---@param key string
---@param value number
function m:SetFloat(key, value) end

---@overload fun(key:string, defaultValue:string):string
---@param key string
---@return string
function m:GetString(key) end

---@param key string
---@param value string
function m:SetString(key, value) end

---@overload fun(key:string, defaultObj:any):any
---@param key string
---@return any
function m:GetObject(key) end

---@param key string
---@param obj any
function m:SetObject(key, obj) end

UnityGameFramework.Runtime.SettingComponent = m
return m
