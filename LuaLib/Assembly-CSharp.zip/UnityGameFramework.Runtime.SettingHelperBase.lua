---@class UnityGameFramework.Runtime.SettingHelperBase : UnityEngine.MonoBehaviour
local m = {}

---@abstract
function m:Save() end

---@abstract
---@param key string
---@return boolean
function m:HasKey(key) end

---@abstract
---@param key string
function m:RemoveKey(key) end

---@abstract
function m:RemoveAllKeys() end

---@overload fun(key:string, defaultValue:boolean):boolean @abstract
---@abstract
---@param key string
---@return boolean
function m:GetBool(key) end

---@abstract
---@param key string
---@param value boolean
function m:SetBool(key, value) end

---@overload fun(key:string, defaultValue:number):number @abstract
---@abstract
---@param key string
---@return number
function m:GetInt(key) end

---@abstract
---@param key string
---@param value number
function m:SetInt(key, value) end

---@overload fun(key:string, defaultValue:number):number @abstract
---@abstract
---@param key string
---@return number
function m:GetFloat(key) end

---@abstract
---@param key string
---@param value number
function m:SetFloat(key, value) end

---@overload fun(key:string, defaultValue:string):string @abstract
---@abstract
---@param key string
---@return string
function m:GetString(key) end

---@abstract
---@param key string
---@param value string
function m:SetString(key, value) end

---@overload fun(key:string, defaultObj:any):any @abstract
---@abstract
---@param key string
---@return any
function m:GetObject(key) end

---@abstract
---@param key string
---@param obj any
function m:SetObject(key, obj) end

UnityGameFramework.Runtime.SettingHelperBase = m
return m
