---@class UnityGameFramework.Runtime.NetworkComponent : UnityGameFramework.Runtime.GameFrameworkComponent
---@field public NetworkChannelCount number
local m = {}

---@param name string
---@return boolean
function m:HasNetworkChannel(name) end

---@param name string
---@return GameFramework.Network.INetworkChannel
function m:GetNetworkChannel(name) end

---@return GameFramework.Network.INetworkChannel[]
function m:GetAllNetworkChannels() end

---@param name string
---@return GameFramework.Network.INetworkChannel
function m:CreateNetworkChannel(name) end

---@param name string
---@return boolean
function m:DestroyNetworkChannel(name) end

---@param name string
---@param ipString string
---@param port number
function m:SetNetworkChannelConnection(name, ipString, port) end

---@overload fun(name:string, userData:any)
---@overload fun(name:string, ipString:string, port:number)
---@overload fun(name:string, ipString:string, port:number, userData:any)
---@param name string
function m:ConnectNetworkChannel(name) end

---@param handler GameFramework.Network.IPacketHandler
function m:RegisterHandler(handler) end

UnityGameFramework.Runtime.NetworkComponent = m
return m
