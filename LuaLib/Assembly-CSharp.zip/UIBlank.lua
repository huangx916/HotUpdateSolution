---@class UIBlank : UIWidget
---@field public forceDraw boolean
local m = {}

UIBlank = m
return m
