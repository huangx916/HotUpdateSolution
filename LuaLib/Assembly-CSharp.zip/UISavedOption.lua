---@class UISavedOption : UnityEngine.MonoBehaviour
---@field public keyName string
local m = {}

function m:SaveSelection() end

function m:SaveState() end

function m:SaveProgress() end

UISavedOption = m
return m
