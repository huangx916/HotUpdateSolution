---@class ExampleDragDropSurface : UnityEngine.MonoBehaviour
---@field public rotatePlacedObject boolean
local m = {}

ExampleDragDropSurface = m
return m
