---@class SetColorPickerColor : UnityEngine.MonoBehaviour
local m = {}

function m:SetToCurrent() end

SetColorPickerColor = m
return m
