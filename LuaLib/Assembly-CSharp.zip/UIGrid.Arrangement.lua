---@class UIGrid.Arrangement : System.Enum
---@field public Horizontal UIGrid.Arrangement @static
---@field public Vertical UIGrid.Arrangement @static
---@field public CellSnap UIGrid.Arrangement @static
---@field public value__ number
local m = {}

UIGrid.Arrangement = m
return m
