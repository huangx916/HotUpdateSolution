---@class UnityGameFramework.Runtime.VarDecimal : GameFramework.Variable_1_System_Decimal_
local m = {}

---@overload fun(value:UnityGameFramework.Runtime.VarDecimal):System.Decimal @static
---@static
---@param value System.Decimal
---@return UnityGameFramework.Runtime.VarDecimal
function m.op_Implicit(value) end

UnityGameFramework.Runtime.VarDecimal = m
return m
