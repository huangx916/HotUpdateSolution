---@class UnityGameFramework.Runtime.DefaultSettingHelper : UnityGameFramework.Runtime.SettingHelperBase
local m = {}

---@virtual
function m:Save() end

---@virtual
---@param key string
---@return boolean
function m:HasKey(key) end

---@virtual
---@param key string
function m:RemoveKey(key) end

---@virtual
function m:RemoveAllKeys() end

---@overload fun(key:string, defaultValue:boolean):boolean @virtual
---@virtual
---@param key string
---@return boolean
function m:GetBool(key) end

---@virtual
---@param key string
---@param value boolean
function m:SetBool(key, value) end

---@overload fun(key:string, defaultValue:number):number @virtual
---@virtual
---@param key string
---@return number
function m:GetInt(key) end

---@virtual
---@param key string
---@param value number
function m:SetInt(key, value) end

---@overload fun(key:string, defaultValue:number):number @virtual
---@virtual
---@param key string
---@return number
function m:GetFloat(key) end

---@virtual
---@param key string
---@param value number
function m:SetFloat(key, value) end

---@overload fun(key:string, defaultValue:string):string @virtual
---@virtual
---@param key string
---@return string
function m:GetString(key) end

---@virtual
---@param key string
---@param value string
function m:SetString(key, value) end

---@overload fun(key:string, defaultObj:any):any @virtual
---@virtual
---@param key string
---@return any
function m:GetObject(key) end

---@virtual
---@param key string
---@param obj any
function m:SetObject(key, obj) end

UnityGameFramework.Runtime.DefaultSettingHelper = m
return m
