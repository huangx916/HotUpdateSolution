---@class TweenLetters.AnimationLetterOrder : System.Enum
---@field public Forward TweenLetters.AnimationLetterOrder @static
---@field public Reverse TweenLetters.AnimationLetterOrder @static
---@field public Random TweenLetters.AnimationLetterOrder @static
---@field public value__ number
local m = {}

TweenLetters.AnimationLetterOrder = m
return m
