---@class UnityGameFramework.Runtime.DebuggerComponent.GraphicsInformationWindow : UnityGameFramework.Runtime.DebuggerComponent.ScrollableDebuggerWindowBase
local m = {}

UnityGameFramework.Runtime.DebuggerComponent.GraphicsInformationWindow = m
return m
