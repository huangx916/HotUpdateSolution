---@class ShaderCache : UnityEngine.MonoBehaviour
local m = {}

---@static
---@param name string
---@param shader UnityEngine.Shader
function m.Add(name, shader) end

---@static
---@param name string
---@return UnityEngine.Shader
function m.Find(name) end

---@static
function m.Clear() end

ShaderCache = m
return m
