---@class UnityGameFramework.Runtime.UIFormLogic : UnityEngine.MonoBehaviour
---@field public UIForm UnityGameFramework.Runtime.UIForm
---@field public Name string
---@field public IsAvailable boolean
---@field public CachedTransform UnityEngine.Transform
local m = {}

UnityGameFramework.Runtime.UIFormLogic = m
return m
