---@class UnityGameFramework.Runtime.DataTableComponent : UnityGameFramework.Runtime.GameFrameworkComponent
---@field public Count number
local m = {}

---@overload fun(dataTableName:string, dataTableType:System.Type, dataTableAssetName:string)
---@overload fun(dataTableName:string, dataTableAssetName:string, userData:any)
---@overload fun(dataTableName:string, dataTableType:System.Type, dataTableAssetName:string, userData:any)
---@overload fun(dataTableName:string, dataTableNameInType:string, dataTableAssetName:string)
---@overload fun(dataTableName:string, dataTableType:System.Type, dataTableNameInType:string, dataTableAssetName:string)
---@overload fun(dataTableName:string, dataTableNameInType:string, dataTableAssetName:string, userData:any)
---@overload fun(dataTableName:string, dataTableType:System.Type, dataTableNameInType:string, dataTableAssetName:string, userData:any)
---@param dataTableName string
---@param dataTableAssetName string
function m:LoadDataTable(dataTableName, dataTableAssetName) end

---@overload fun(type:System.Type):boolean
---@overload fun(name:string):boolean
---@overload fun(type:System.Type, name:string):boolean
---@return boolean
function m:HasDataTable() end

---@overload fun(type:System.Type):GameFramework.DataTable.DataTableBase
---@overload fun(name:string):GameFramework.DataTable.IDataTable_1_T_
---@overload fun(type:System.Type, name:string):GameFramework.DataTable.DataTableBase
---@return GameFramework.DataTable.IDataTable_1_T_
function m:GetDataTable() end

---@return GameFramework.DataTable.DataTableBase[]
function m:GetAllDataTables() end

---@overload fun(name:string, text:string):GameFramework.DataTable.IDataTable_1_T_
---@param text string
---@return GameFramework.DataTable.IDataTable_1_T_
function m:CreateDataTable(text) end

---@overload fun(type:System.Type):boolean
---@overload fun(name:string):boolean
---@overload fun(type:System.Type, name:string):boolean
---@return boolean
function m:DestroyDataTable() end

UnityGameFramework.Runtime.DataTableComponent = m
return m
