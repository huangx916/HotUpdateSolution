---@class UnityGameFramework.Runtime.DebuggerComponent.RuntimeMemoryInformationWindow_1.Sample_T_ : System.Object
---@field public Name string
---@field public Type string
---@field public Size number
---@field public Highlight boolean
local m = {}

UnityGameFramework.Runtime.DebuggerComponent.RuntimeMemoryInformationWindow_1.Sample_T_ = m
return m
