---@class TweenClipRegion : UITweener
---@field public from UnityEngine.Vector4
---@field public to UnityEngine.Vector4
---@field public clipRegion UnityEngine.Vector4
---@field public value UnityEngine.Vector4
local m = {}

---@static
---@param go UnityEngine.GameObject
---@param duration number
---@param clipRegion UnityEngine.Vector4
---@return TweenClipRegion
function m.Begin(go, duration, clipRegion) end

---@virtual
function m:SetStartToCurrentValue() end

---@virtual
function m:SetEndToCurrentValue() end

TweenClipRegion = m
return m
