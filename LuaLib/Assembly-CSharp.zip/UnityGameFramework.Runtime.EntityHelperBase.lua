---@class UnityGameFramework.Runtime.EntityHelperBase : UnityEngine.MonoBehaviour
local m = {}

---@abstract
---@param entityAsset any
---@return any
function m:InstantiateEntity(entityAsset) end

---@abstract
---@param entityInstance any
---@param entityGroup GameFramework.Entity.IEntityGroup
---@param userData any
---@return GameFramework.Entity.IEntity
function m:CreateEntity(entityInstance, entityGroup, userData) end

---@abstract
---@param entityAsset any
---@param entityInstance any
function m:ReleaseEntity(entityAsset, entityInstance) end

UnityGameFramework.Runtime.EntityHelperBase = m
return m
