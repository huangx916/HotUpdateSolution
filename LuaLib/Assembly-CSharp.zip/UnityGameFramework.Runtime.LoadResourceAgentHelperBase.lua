---@class UnityGameFramework.Runtime.LoadResourceAgentHelperBase : UnityEngine.MonoBehaviour
local m = {}

---@abstract
---@param value fun(sender:any, e:GameFramework.Resource.LoadResourceAgentHelperUpdateEventArgs)
function m:add_LoadResourceAgentHelperUpdate(value) end

---@abstract
---@param value fun(sender:any, e:GameFramework.Resource.LoadResourceAgentHelperUpdateEventArgs)
function m:remove_LoadResourceAgentHelperUpdate(value) end

---@abstract
---@param value fun(sender:any, e:GameFramework.Resource.LoadResourceAgentHelperReadFileCompleteEventArgs)
function m:add_LoadResourceAgentHelperReadFileComplete(value) end

---@abstract
---@param value fun(sender:any, e:GameFramework.Resource.LoadResourceAgentHelperReadFileCompleteEventArgs)
function m:remove_LoadResourceAgentHelperReadFileComplete(value) end

---@abstract
---@param value fun(sender:any, e:GameFramework.Resource.LoadResourceAgentHelperReadBytesCompleteEventArgs)
function m:add_LoadResourceAgentHelperReadBytesComplete(value) end

---@abstract
---@param value fun(sender:any, e:GameFramework.Resource.LoadResourceAgentHelperReadBytesCompleteEventArgs)
function m:remove_LoadResourceAgentHelperReadBytesComplete(value) end

---@abstract
---@param value fun(sender:any, e:GameFramework.Resource.LoadResourceAgentHelperParseBytesCompleteEventArgs)
function m:add_LoadResourceAgentHelperParseBytesComplete(value) end

---@abstract
---@param value fun(sender:any, e:GameFramework.Resource.LoadResourceAgentHelperParseBytesCompleteEventArgs)
function m:remove_LoadResourceAgentHelperParseBytesComplete(value) end

---@abstract
---@param value fun(sender:any, e:GameFramework.Resource.LoadResourceAgentHelperLoadCompleteEventArgs)
function m:add_LoadResourceAgentHelperLoadComplete(value) end

---@abstract
---@param value fun(sender:any, e:GameFramework.Resource.LoadResourceAgentHelperLoadCompleteEventArgs)
function m:remove_LoadResourceAgentHelperLoadComplete(value) end

---@abstract
---@param value fun(sender:any, e:GameFramework.Resource.LoadResourceAgentHelperErrorEventArgs)
function m:add_LoadResourceAgentHelperError(value) end

---@abstract
---@param value fun(sender:any, e:GameFramework.Resource.LoadResourceAgentHelperErrorEventArgs)
function m:remove_LoadResourceAgentHelperError(value) end

---@abstract
---@param fullPath string
function m:ReadFile(fullPath) end

---@abstract
---@param fullPath string
---@param loadType number
function m:ReadBytes(fullPath, loadType) end

---@abstract
---@param bytes string
function m:ParseBytes(bytes) end

---@abstract
---@param resource any
---@param resourceChildName string
---@param isScene boolean
function m:LoadAsset(resource, resourceChildName, isScene) end

---@abstract
function m:Reset() end

UnityGameFramework.Runtime.LoadResourceAgentHelperBase = m
return m
