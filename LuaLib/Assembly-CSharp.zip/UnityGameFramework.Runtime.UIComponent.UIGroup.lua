---@class UnityGameFramework.Runtime.UIComponent.UIGroup : System.Object
---@field public Name string
---@field public Depth number
local m = {}

UnityGameFramework.Runtime.UIComponent.UIGroup = m
return m
