---@class UIShowControlScheme : UnityEngine.MonoBehaviour
---@field public target UnityEngine.GameObject
---@field public mouse boolean
---@field public touch boolean
---@field public controller boolean
local m = {}

UIShowControlScheme = m
return m
