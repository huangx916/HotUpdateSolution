---@class UnityGameFramework.Runtime.VarVector2 : GameFramework.Variable_1_UnityEngine_Vector2_
local m = {}

---@overload fun(value:UnityGameFramework.Runtime.VarVector2):UnityEngine.Vector2 @static
---@static
---@param value UnityEngine.Vector2
---@return UnityGameFramework.Runtime.VarVector2
function m.op_Implicit(value) end

UnityGameFramework.Runtime.VarVector2 = m
return m
