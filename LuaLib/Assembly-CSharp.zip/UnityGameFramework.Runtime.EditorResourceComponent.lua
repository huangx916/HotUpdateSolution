---@class UnityGameFramework.Runtime.EditorResourceComponent : UnityEngine.MonoBehaviour
---@field public ReadOnlyPath string
---@field public ReadWritePath string
---@field public ResourceMode GameFramework.Resource.ResourceMode
---@field public CurrentVariant string
---@field public ApplicableGameVersion string
---@field public InternalResourceVersion number
---@field public AssetCount number
---@field public ResourceCount number
---@field public ResourceGroupCount number
---@field public UpdatePrefixUri string
---@field public UpdateRetryCount number
---@field public UpdateWaitingCount number
---@field public UpdatingCount number
---@field public LoadTotalAgentCount number
---@field public LoadFreeAgentCount number
---@field public LoadWorkingAgentCount number
---@field public LoadWaitingTaskCount number
---@field public AssetAutoReleaseInterval number
---@field public AssetCapacity number
---@field public AssetExpireTime number
---@field public AssetPriority number
---@field public ResourceAutoReleaseInterval number
---@field public ResourceCapacity number
---@field public ResourceExpireTime number
---@field public ResourcePriority number
local m = {}

---@virtual
---@param value fun(sender:any, e:GameFramework.Resource.ResourceInitCompleteEventArgs)
function m:add_ResourceInitComplete(value) end

---@virtual
---@param value fun(sender:any, e:GameFramework.Resource.ResourceInitCompleteEventArgs)
function m:remove_ResourceInitComplete(value) end

---@virtual
---@param value fun(sender:any, e:GameFramework.Resource.VersionListUpdateSuccessEventArgs)
function m:add_VersionListUpdateSuccess(value) end

---@virtual
---@param value fun(sender:any, e:GameFramework.Resource.VersionListUpdateSuccessEventArgs)
function m:remove_VersionListUpdateSuccess(value) end

---@virtual
---@param value fun(sender:any, e:GameFramework.Resource.VersionListUpdateFailureEventArgs)
function m:add_VersionListUpdateFailure(value) end

---@virtual
---@param value fun(sender:any, e:GameFramework.Resource.VersionListUpdateFailureEventArgs)
function m:remove_VersionListUpdateFailure(value) end

---@virtual
---@param value fun(sender:any, e:GameFramework.Resource.ResourceCheckCompleteEventArgs)
function m:add_ResourceCheckComplete(value) end

---@virtual
---@param value fun(sender:any, e:GameFramework.Resource.ResourceCheckCompleteEventArgs)
function m:remove_ResourceCheckComplete(value) end

---@virtual
---@param value fun(sender:any, e:GameFramework.Resource.ResourceUpdateStartEventArgs)
function m:add_ResourceUpdateStart(value) end

---@virtual
---@param value fun(sender:any, e:GameFramework.Resource.ResourceUpdateStartEventArgs)
function m:remove_ResourceUpdateStart(value) end

---@virtual
---@param value fun(sender:any, e:GameFramework.Resource.ResourceUpdateChangedEventArgs)
function m:add_ResourceUpdateChanged(value) end

---@virtual
---@param value fun(sender:any, e:GameFramework.Resource.ResourceUpdateChangedEventArgs)
function m:remove_ResourceUpdateChanged(value) end

---@virtual
---@param value fun(sender:any, e:GameFramework.Resource.ResourceUpdateSuccessEventArgs)
function m:add_ResourceUpdateSuccess(value) end

---@virtual
---@param value fun(sender:any, e:GameFramework.Resource.ResourceUpdateSuccessEventArgs)
function m:remove_ResourceUpdateSuccess(value) end

---@virtual
---@param value fun(sender:any, e:GameFramework.Resource.ResourceUpdateFailureEventArgs)
function m:add_ResourceUpdateFailure(value) end

---@virtual
---@param value fun(sender:any, e:GameFramework.Resource.ResourceUpdateFailureEventArgs)
function m:remove_ResourceUpdateFailure(value) end

---@virtual
---@param value fun(sender:any, e:GameFramework.Resource.ResourceUpdateAllCompleteEventArgs)
function m:add_ResourceUpdateAllComplete(value) end

---@virtual
---@param value fun(sender:any, e:GameFramework.Resource.ResourceUpdateAllCompleteEventArgs)
function m:remove_ResourceUpdateAllComplete(value) end

---@virtual
---@param readOnlyPath string
function m:SetReadOnlyPath(readOnlyPath) end

---@virtual
---@param readWritePath string
function m:SetReadWritePath(readWritePath) end

---@virtual
---@param resourceMode GameFramework.Resource.ResourceMode
function m:SetResourceMode(resourceMode) end

---@virtual
---@param currentVariant string
function m:SetCurrentVariant(currentVariant) end

---@virtual
---@param objectPoolManager GameFramework.ObjectPool.IObjectPoolManager
function m:SetObjectPoolManager(objectPoolManager) end

---@virtual
---@param downloadManager GameFramework.Download.IDownloadManager
function m:SetDownloadManager(downloadManager) end

---@virtual
---@param decryptResourceCallback fun(name:string, variant:string, loadType:number, length:number, hashCode:number, storageInReadOnly:boolean, bytes:string):string
function m:SetDecryptResourceCallback(decryptResourceCallback) end

---@virtual
---@param resourceHelper GameFramework.Resource.IResourceHelper
function m:SetResourceHelper(resourceHelper) end

---@virtual
---@param loadResourceAgentHelper GameFramework.Resource.ILoadResourceAgentHelper
function m:AddLoadResourceAgentHelper(loadResourceAgentHelper) end

---@virtual
function m:InitResources() end

---@virtual
---@param latestInternalResourceVersion number
---@return GameFramework.Resource.CheckVersionListResult
function m:CheckVersionList(latestInternalResourceVersion) end

---@virtual
---@param versionListLength number
---@param versionListHashCode number
---@param versionListZipLength number
---@param versionListZipHashCode number
function m:UpdateVersionList(versionListLength, versionListHashCode, versionListZipLength, versionListZipHashCode) end

---@virtual
function m:CheckResources() end

---@virtual
function m:UpdateResources() end

---@overload fun(assetName:string, loadAssetCallbacks:GameFramework.Resource.LoadAssetCallbacks, userData:any) @virtual
---@virtual
---@param assetName string
---@param loadAssetCallbacks GameFramework.Resource.LoadAssetCallbacks
function m:LoadAsset(assetName, loadAssetCallbacks) end

---@virtual
---@param asset any
function m:UnloadAsset(asset) end

---@overload fun(sceneAssetName:string, loadSceneCallbacks:GameFramework.Resource.LoadSceneCallbacks, userData:any) @virtual
---@virtual
---@param sceneAssetName string
---@param loadSceneCallbacks GameFramework.Resource.LoadSceneCallbacks
function m:LoadScene(sceneAssetName, loadSceneCallbacks) end

---@overload fun(sceneAssetName:string, unloadSceneCallbacks:GameFramework.Resource.UnloadSceneCallbacks, userData:any) @virtual
---@virtual
---@param sceneAssetName string
---@param unloadSceneCallbacks GameFramework.Resource.UnloadSceneCallbacks
function m:UnloadScene(sceneAssetName, unloadSceneCallbacks) end

---@virtual
---@param resourceGroupName string
---@return boolean
function m:GetResourceGroupReady(resourceGroupName) end

---@virtual
---@param resourceGroupName string
---@return number
function m:GetResourceGroupResourceCount(resourceGroupName) end

---@virtual
---@param resourceGroupName string
---@return number
function m:GetResourceGroupReadyResourceCount(resourceGroupName) end

---@virtual
---@param resourceGroupName string
---@return number
function m:GetResourceGroupTotalLength(resourceGroupName) end

---@virtual
---@param resourceGroupName string
---@return number
function m:GetResourceGroupTotalReadyLength(resourceGroupName) end

---@virtual
---@param resourceGroupName string
---@return number
function m:GetResourceGroupProgress(resourceGroupName) end

UnityGameFramework.Runtime.EditorResourceComponent = m
return m
