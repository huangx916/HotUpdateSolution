---@class UIDrawCall.OnCreateDrawCall : System.MulticastDelegate
local m = {}

---@virtual
---@param dc UIDrawCall
---@param filter UnityEngine.MeshFilter
---@param ren UnityEngine.MeshRenderer
function m:Invoke(dc, filter, ren) end

---@virtual
---@param dc UIDrawCall
---@param filter UnityEngine.MeshFilter
---@param ren UnityEngine.MeshRenderer
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(dc, filter, ren, callback, object) end

---@virtual
---@param result System.IAsyncResult
function m:EndInvoke(result) end

UIDrawCall.OnCreateDrawCall = m
return m
