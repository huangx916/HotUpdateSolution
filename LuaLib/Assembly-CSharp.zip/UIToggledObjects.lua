---@class UIToggledObjects : UnityEngine.MonoBehaviour
---@field public activate UnityEngine.GameObject[]
---@field public deactivate UnityEngine.GameObject[]
local m = {}

function m:Toggle() end

UIToggledObjects = m
return m
