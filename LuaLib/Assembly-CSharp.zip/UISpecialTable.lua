---@class UISpecialTable : UITable
local m = {}

---@virtual
---@return UnityEngine.Transform[]
function m:GetChildList() end

UISpecialTable = m
return m
