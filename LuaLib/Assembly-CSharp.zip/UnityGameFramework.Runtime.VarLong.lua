---@class UnityGameFramework.Runtime.VarLong : GameFramework.Variable_1_System_Int64_
local m = {}

---@overload fun(value:UnityGameFramework.Runtime.VarLong):number @static
---@static
---@param value number
---@return UnityGameFramework.Runtime.VarLong
function m.op_Implicit(value) end

UnityGameFramework.Runtime.VarLong = m
return m
