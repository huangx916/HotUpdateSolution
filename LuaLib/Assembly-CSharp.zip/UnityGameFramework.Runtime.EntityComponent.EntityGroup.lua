---@class UnityGameFramework.Runtime.EntityComponent.EntityGroup : System.Object
---@field public Name string
---@field public InstanceAutoReleaseInterval number
---@field public InstanceCapacity number
---@field public InstanceExpireTime number
---@field public InstancePriority number
local m = {}

UnityGameFramework.Runtime.EntityComponent.EntityGroup = m
return m
