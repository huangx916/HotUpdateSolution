---@class UnityGameFramework.Runtime.FsmComponent : UnityGameFramework.Runtime.GameFrameworkComponent
---@field public Count number
local m = {}

---@overload fun(name:string):boolean
---@return boolean
function m:HasFsm() end

---@overload fun(name:string):GameFramework.Fsm.IFsm_1_T_
---@return GameFramework.Fsm.IFsm_1_T_
function m:GetFsm() end

---@return GameFramework.Fsm.FsmBase[]
function m:GetAllFsms() end

---@overload fun(owner:any):GameFramework.Fsm.IFsm_1_T_
---@overload fun(name:string, owner:any, states:GameFramework.Fsm.FsmState_1_T_[]|GameFramework.Fsm.FsmState_1_T_):GameFramework.Fsm.IFsm_1_T_
---@overload fun(name:string, owner:any):GameFramework.Fsm.IFsm_1_T_
---@param owner any
---@param states GameFramework.Fsm.FsmState_1_T_[]|GameFramework.Fsm.FsmState_1_T_
---@return GameFramework.Fsm.IFsm_1_T_
function m:CreateFsm(owner, states) end

---@overload fun(name:string):boolean
---@overload fun(fsm:GameFramework.Fsm.IFsm_1_T_):boolean
---@return boolean
function m:DestroyFsm() end

UnityGameFramework.Runtime.FsmComponent = m
return m
