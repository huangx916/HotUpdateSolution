---@class UnityGameFramework.Runtime.BaseComponent : UnityGameFramework.Runtime.GameFrameworkComponent
---@field public GameVersion string
---@field public InternalApplicationVersion number
---@field public EditorResourceMode boolean
---@field public EditorLanguage GameFramework.Localization.Language
---@field public EditorResourceHelper GameFramework.Resource.IResourceManager
---@field public FrameRate number
---@field public GameSpeed number
---@field public IsGamePaused boolean
---@field public IsNormalGameSpeed boolean
---@field public RunInBackground boolean
---@field public NeverSleep boolean
local m = {}

function m:PauseGame() end

function m:ResumeGame() end

function m:ResetNormalGameSpeed() end

UnityGameFramework.Runtime.BaseComponent = m
return m
