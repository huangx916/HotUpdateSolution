---@class UnityGameFramework.Runtime.OpenUIFormUpdateEventArgs : GameFramework.Event.GameEventArgs
---@field public Id number
---@field public SerialId number
---@field public UIFormAssetName string
---@field public UIGroupName string
---@field public PauseCoveredUIForm boolean
---@field public Progress number
---@field public UserData any
local m = {}

UnityGameFramework.Runtime.OpenUIFormUpdateEventArgs = m
return m
