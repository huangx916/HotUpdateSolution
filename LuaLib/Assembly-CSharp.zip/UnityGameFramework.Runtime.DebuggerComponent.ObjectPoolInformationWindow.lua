---@class UnityGameFramework.Runtime.DebuggerComponent.ObjectPoolInformationWindow : UnityGameFramework.Runtime.DebuggerComponent.ScrollableDebuggerWindowBase
local m = {}

---@overload fun() @virtual
---@virtual
---@param args any[]|any
function m:Initialize(args) end

UnityGameFramework.Runtime.DebuggerComponent.ObjectPoolInformationWindow = m
return m
