---@class UnityGameFramework.Runtime.ReadWritePathType : System.Enum
---@field public Unspecified UnityGameFramework.Runtime.ReadWritePathType @static
---@field public TemporaryCache UnityGameFramework.Runtime.ReadWritePathType @static
---@field public PersistentData UnityGameFramework.Runtime.ReadWritePathType @static
---@field public value__ number
local m = {}

UnityGameFramework.Runtime.ReadWritePathType = m
return m
