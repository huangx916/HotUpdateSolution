---@class UnityGameFramework.Runtime.GameEntry : System.Object
---@field public Version string @static
local m = {}

---@overload fun(type:System.Type):UnityGameFramework.Runtime.GameFrameworkComponent @static
---@overload fun(typeName:string):UnityGameFramework.Runtime.GameFrameworkComponent @static
---@static
---@return UnityGameFramework.Runtime.GameFrameworkComponent
function m.GetComponent() end

---@static
---@param shutdownType UnityGameFramework.Runtime.ShutdownType
function m.Shutdown(shutdownType) end

UnityGameFramework.Runtime.GameEntry = m
return m
