---@class UnityGameFramework.Runtime.NetworkSendPacketEventArgs : GameFramework.Event.GameEventArgs
---@field public Id number
---@field public NetworkChannel GameFramework.Network.INetworkChannel
---@field public BytesSent number
---@field public UserData any
local m = {}

UnityGameFramework.Runtime.NetworkSendPacketEventArgs = m
return m
