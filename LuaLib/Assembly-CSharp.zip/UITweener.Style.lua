---@class UITweener.Style : System.Enum
---@field public Once UITweener.Style @static
---@field public Loop UITweener.Style @static
---@field public PingPong UITweener.Style @static
---@field public value__ number
local m = {}

UITweener.Style = m
return m
