---@class UnityGameFramework.Runtime.DebuggerComponent.SceneInformationWindow : UnityGameFramework.Runtime.DebuggerComponent.ScrollableDebuggerWindowBase
local m = {}

UnityGameFramework.Runtime.DebuggerComponent.SceneInformationWindow = m
return m
