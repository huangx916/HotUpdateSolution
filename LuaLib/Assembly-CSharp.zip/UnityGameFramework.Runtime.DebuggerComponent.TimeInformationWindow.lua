---@class UnityGameFramework.Runtime.DebuggerComponent.TimeInformationWindow : UnityGameFramework.Runtime.DebuggerComponent.ScrollableDebuggerWindowBase
local m = {}

UnityGameFramework.Runtime.DebuggerComponent.TimeInformationWindow = m
return m
