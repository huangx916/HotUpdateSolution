---@class NGUITools : System.Object
---@field public audioSource UnityEngine.AudioSource @static
---@field public keys UnityEngine.KeyCode[] @static
---@field public soundVolume number @static
---@field public fileAccess boolean @static
---@field public clipboard string @static
---@field public screenSize UnityEngine.Vector2 @static
local m = {}

---@overload fun(clip:UnityEngine.AudioClip, volume:number):UnityEngine.AudioSource @static
---@overload fun(clip:UnityEngine.AudioClip, volume:number, pitch:number):UnityEngine.AudioSource @static
---@static
---@param clip UnityEngine.AudioClip
---@return UnityEngine.AudioSource
function m.PlaySound(clip) end

---@static
---@param min number
---@param max number
---@return number
function m.RandomRange(min, max) end

---@static
---@param obj UnityEngine.GameObject
---@return string
function m.GetHierarchy(obj) end

---@static
---@return UnityEngine.Component[]
function m.FindActive() end

---@static
---@param layer number
---@return UnityEngine.Camera
function m.FindCameraForLayer(layer) end

---@overload fun(go:UnityEngine.GameObject, considerInactive:boolean) @static
---@static
---@param go UnityEngine.GameObject
function m.AddWidgetCollider(go) end

---@overload fun(go:UnityEngine.GameObject, considerInactive:boolean) @static
---@overload fun(box:UnityEngine.BoxCollider, considerInactive:boolean) @static
---@overload fun(box:UnityEngine.BoxCollider2D, considerInactive:boolean) @static
---@static
---@param go UnityEngine.GameObject
function m.UpdateWidgetCollider(go) end

---@overload fun(obj:UnityEngine.Object):string @static
---@static
---@return string
function m.GetTypeName() end

---@static
---@param obj UnityEngine.Object
---@param name string
function m.RegisterUndo(obj, name) end

---@static
---@param obj UnityEngine.Object
function m.SetDirty(obj) end

---@overload fun(parent:UnityEngine.GameObject, layer:number):UnityEngine.GameObject @static
---@overload fun(parent:UnityEngine.GameObject, undo:boolean):UnityEngine.GameObject @static
---@overload fun(parent:UnityEngine.GameObject, undo:boolean, layer:number):UnityEngine.GameObject @static
---@overload fun(parent:UnityEngine.GameObject, prefab:UnityEngine.GameObject):UnityEngine.GameObject @static
---@overload fun(parent:UnityEngine.GameObject, prefab:UnityEngine.GameObject, layer:number):UnityEngine.GameObject @static
---@overload fun(parent:UnityEngine.GameObject):UnityEngine.Component @static
---@overload fun(parent:UnityEngine.GameObject, undo:boolean):UnityEngine.Component @static
---@static
---@param parent UnityEngine.GameObject
---@return UnityEngine.GameObject
function m.AddChild(parent) end

---@static
---@param go UnityEngine.GameObject
---@return number
function m.CalculateRaycastDepth(go) end

---@overload fun(go:UnityEngine.GameObject, ignoreChildrenWithColliders:boolean):number @static
---@static
---@param go UnityEngine.GameObject
---@return number
function m.CalculateNextDepth(go) end

---@static
---@param go UnityEngine.GameObject
---@param adjustment number
---@return number
function m.AdjustDepth(go, adjustment) end

---@static
---@param go UnityEngine.GameObject
function m.BringForward(go) end

---@static
---@param go UnityEngine.GameObject
function m.PushBack(go) end

---@static
function m.NormalizeDepths() end

---@overload fun(go:UnityEngine.GameObject) @static
---@overload fun(list:UIWidget[]) @static
---@static
function m.NormalizeWidgetDepths() end

---@static
function m.NormalizePanelDepths() end

---@overload fun(advanced3D:boolean, layer:number):UIPanel @static
---@overload fun(trans:UnityEngine.Transform, advanced3D:boolean, layer:number):UIPanel @static
---@static
---@param advanced3D boolean
---@return UIPanel
function m.CreateUI(advanced3D) end

---@static
---@param t UnityEngine.Transform
---@param layer number
function m.SetChildLayer(t, layer) end

---@overload fun(go:UnityEngine.GameObject):UIWidget @static
---@static
---@param go UnityEngine.GameObject
---@param depth number
---@return UIWidget
function m.AddWidget(go, depth) end

---@overload fun(go:UnityEngine.GameObject, atlas:UIAtlas, spriteName:string):UISprite @static
---@static
---@param go UnityEngine.GameObject
---@param atlas UIAtlas
---@param spriteName string
---@param depth number
---@return UISprite
function m.AddSprite(go, atlas, spriteName, depth) end

---@static
---@param go UnityEngine.GameObject
---@return UnityEngine.GameObject
function m.GetRoot(go) end

---@overload fun(trans:UnityEngine.Transform):UnityEngine.Component @static
---@static
---@param go UnityEngine.GameObject
---@return UnityEngine.Component
function m.FindInParents(go) end

---@static
---@param obj UnityEngine.Object
function m.Destroy(obj) end

---@static
---@param t UnityEngine.Transform
function m.DestroyChildren(t) end

---@static
---@param obj UnityEngine.Object
function m.DestroyImmediate(obj) end

---@overload fun(funcName:string, param:any) @static
---@static
---@param funcName string
function m.Broadcast(funcName) end

---@static
---@param parent UnityEngine.Transform
---@param child UnityEngine.Transform
---@return boolean
function m.IsChild(parent, child) end

---@overload fun(go:UnityEngine.GameObject, state:boolean, compatibilityMode:boolean) @static
---@static
---@param go UnityEngine.GameObject
---@param state boolean
function m.SetActive(go, state) end

---@static
---@param go UnityEngine.GameObject
---@param state boolean
function m.SetActiveChildren(go, state) end

---@overload fun(go:UnityEngine.GameObject):boolean @static
---@static
---@param mb UnityEngine.Behaviour
---@return boolean
function m.IsOpaque(mb) end

---@static
---@param mb UnityEngine.Behaviour
---@return boolean
function m.IsActive(mb) end

---@overload fun(go:UnityEngine.GameObject):boolean @static
---@static
---@param mb UnityEngine.Behaviour
---@return boolean
function m.GetActive(mb) end

---@static
---@param go UnityEngine.GameObject
---@param state boolean
function m.SetActiveSelf(go, state) end

---@static
---@param go UnityEngine.GameObject
---@param layer number
function m.SetLayer(go, layer) end

---@static
---@param v UnityEngine.Vector3
---@return UnityEngine.Vector3
function m.Round(v) end

---@static
---@param t UnityEngine.Transform
function m.MakePixelPerfect(t) end

---@overload fun(cam:UnityEngine.Camera, t:UnityEngine.Transform, considerInactive:boolean) @static
---@overload fun(cam:UnityEngine.Camera, t:UnityEngine.Transform) @static
---@overload fun(cam:UnityEngine.Camera, transform:UnityEngine.Transform, pos:UnityEngine.Vector3) @static
---@overload fun(cam:UnityEngine.Camera, transform:UnityEngine.Transform, content:UnityEngine.Transform, pos:UnityEngine.Vector3, considerInactive:boolean) @static
---@overload fun(cam:UnityEngine.Camera, transform:UnityEngine.Transform, content:UnityEngine.Transform, pos:UnityEngine.Vector3) @static
---@overload fun(cam:UnityEngine.Camera, transform:UnityEngine.Transform, content:UnityEngine.Transform, pos:UnityEngine.Vector3, considerInactive:boolean):UnityEngine.Bounds @static
---@overload fun(cam:UnityEngine.Camera, transform:UnityEngine.Transform, content:UnityEngine.Transform, pos:UnityEngine.Vector3):UnityEngine.Bounds @static
---@static
---@param cam UnityEngine.Camera
---@param t UnityEngine.Transform
---@param considerInactive boolean
---@param considerChildren boolean
function m.FitOnScreen(cam, t, considerInactive, considerChildren) end

---@static
---@param fileName string
---@param bytes string
---@return boolean
function m.Save(fileName, bytes) end

---@static
---@param fileName string
---@return string
function m.Load(fileName) end

---@static
---@param c UnityEngine.Color
---@return UnityEngine.Color
function m.ApplyPMA(c) end

---@static
---@param go UnityEngine.GameObject
function m.MarkParentAsChanged(go) end

---@static
---@param c UnityEngine.Color
---@return string
function m.EncodeColor(c) end

---@static
---@param text string
---@param offset number
---@return UnityEngine.Color
function m.ParseColor(text, offset) end

---@static
---@param text string
---@return string
function m.StripSymbols(text) end

---@static
---@param go UnityEngine.GameObject
---@return UnityEngine.Component
function m.AddMissingComponent(go) end

---@overload fun(cam:UnityEngine.Camera, depth:number):UnityEngine.Vector3[] @static
---@overload fun(cam:UnityEngine.Camera, relativeTo:UnityEngine.Transform):UnityEngine.Vector3[] @static
---@overload fun(cam:UnityEngine.Camera, depth:number, relativeTo:UnityEngine.Transform):UnityEngine.Vector3[] @static
---@static
---@param cam UnityEngine.Camera
---@return UnityEngine.Vector3[]
function m.GetSides(cam) end

---@overload fun(cam:UnityEngine.Camera, depth:number):UnityEngine.Vector3[] @static
---@overload fun(cam:UnityEngine.Camera, relativeTo:UnityEngine.Transform):UnityEngine.Vector3[] @static
---@overload fun(cam:UnityEngine.Camera, depth:number, relativeTo:UnityEngine.Transform):UnityEngine.Vector3[] @static
---@static
---@param cam UnityEngine.Camera
---@return UnityEngine.Vector3[]
function m.GetWorldCorners(cam) end

---@static
---@param obj any
---@param method string
---@return string
function m.GetFuncName(obj, method) end

---@static
---@param go UnityEngine.GameObject
---@param funcName string
function m.Execute(go, funcName) end

---@static
---@param root UnityEngine.GameObject
---@param funcName string
function m.ExecuteAll(root, funcName) end

---@static
---@param root UnityEngine.GameObject
function m.ImmediatelyCreateDrawCalls(root) end

---@static
---@param key UnityEngine.KeyCode
---@return string
function m.KeyToCaption(key) end

---@overload fun(id:string):UIWidget @static
---@static
---@param id string
---@param onInit fun(w:UIWidget)
---@return UIWidget
function m.Draw(id, onInit) end

---@static
---@param c UnityEngine.Color
---@return UnityEngine.Color
function m.GammaToLinearSpace(c) end

NGUITools = m
return m
