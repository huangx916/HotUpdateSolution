---@class UICenterOnChild.OnCenterCallback : System.MulticastDelegate
local m = {}

---@virtual
---@param centeredObject UnityEngine.GameObject
function m:Invoke(centeredObject) end

---@virtual
---@param centeredObject UnityEngine.GameObject
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(centeredObject, callback, object) end

---@virtual
---@param result System.IAsyncResult
function m:EndInvoke(result) end

UICenterOnChild.OnCenterCallback = m
return m
