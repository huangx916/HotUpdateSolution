---@class UnityGameFramework.Runtime.EditorResourceComponent.UnloadSceneInfo : System.Object
---@field public AsyncOperation UnityEngine.AsyncOperation
---@field public SceneAssetName string
---@field public UnloadSceneCallbacks GameFramework.Resource.UnloadSceneCallbacks
---@field public UserData any
local m = {}

UnityGameFramework.Runtime.EditorResourceComponent.UnloadSceneInfo = m
return m
