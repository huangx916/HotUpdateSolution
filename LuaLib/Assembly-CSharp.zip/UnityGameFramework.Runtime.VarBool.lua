---@class UnityGameFramework.Runtime.VarBool : GameFramework.Variable_1_System_Boolean_
local m = {}

---@overload fun(value:UnityGameFramework.Runtime.VarBool):boolean @static
---@static
---@param value boolean
---@return UnityGameFramework.Runtime.VarBool
function m.op_Implicit(value) end

UnityGameFramework.Runtime.VarBool = m
return m
