---@class UnityExtensionGFW : System.Object
local m = {}

---@overload fun(gameObject:UnityEngine.GameObject, type:System.Type):UnityEngine.Component @static
---@static
---@param gameObject UnityEngine.GameObject
---@return UnityEngine.Component
function m.GetOrAddComponent(gameObject) end

---@static
---@param gameObject UnityEngine.GameObject
---@return boolean
function m.InScene(gameObject) end

---@static
---@param vector3 UnityEngine.Vector3
---@return UnityEngine.Vector2
function m.ToVector2(vector3) end

---@overload fun(vector2:UnityEngine.Vector2, y:number):UnityEngine.Vector3 @static
---@static
---@param vector2 UnityEngine.Vector2
---@return UnityEngine.Vector3
function m.ToVector3(vector2) end

---@static
---@param transform UnityEngine.Transform
---@param newValue number
function m.SetPositionX(transform, newValue) end

---@static
---@param transform UnityEngine.Transform
---@param newValue number
function m.SetPositionY(transform, newValue) end

---@static
---@param transform UnityEngine.Transform
---@param newValue number
function m.SetPositionZ(transform, newValue) end

---@static
---@param transform UnityEngine.Transform
---@param deltaValue number
function m.AddPositionX(transform, deltaValue) end

---@static
---@param transform UnityEngine.Transform
---@param deltaValue number
function m.AddPositionY(transform, deltaValue) end

---@static
---@param transform UnityEngine.Transform
---@param deltaValue number
function m.AddPositionZ(transform, deltaValue) end

---@static
---@param transform UnityEngine.Transform
---@param newValue number
function m.SetLocalPositionX(transform, newValue) end

---@static
---@param transform UnityEngine.Transform
---@param newValue number
function m.SetLocalPositionY(transform, newValue) end

---@static
---@param transform UnityEngine.Transform
---@param newValue number
function m.SetLocalPositionZ(transform, newValue) end

---@static
---@param transform UnityEngine.Transform
---@param deltaValue number
function m.AddLocalPositionX(transform, deltaValue) end

---@static
---@param transform UnityEngine.Transform
---@param deltaValue number
function m.AddLocalPositionY(transform, deltaValue) end

---@static
---@param transform UnityEngine.Transform
---@param deltaValue number
function m.AddLocalPositionZ(transform, deltaValue) end

---@static
---@param transform UnityEngine.Transform
---@param newValue number
function m.SetLocalScaleX(transform, newValue) end

---@static
---@param transform UnityEngine.Transform
---@param newValue number
function m.SetLocalScaleY(transform, newValue) end

---@static
---@param transform UnityEngine.Transform
---@param newValue number
function m.SetLocalScaleZ(transform, newValue) end

---@static
---@param transform UnityEngine.Transform
---@param deltaValue number
function m.AddLocalScaleX(transform, deltaValue) end

---@static
---@param transform UnityEngine.Transform
---@param deltaValue number
function m.AddLocalScaleY(transform, deltaValue) end

---@static
---@param transform UnityEngine.Transform
---@param deltaValue number
function m.AddLocalScaleZ(transform, deltaValue) end

---@static
---@param transform UnityEngine.Transform
---@param lookAtPoint2D UnityEngine.Vector2
function m.LookAt2D(transform, lookAtPoint2D) end

---@static
---@param transform UnityEngine.Transform
---@param layer number
function m.SetLayerRecursively(transform, layer) end

UnityExtensionGFW = m
return m
