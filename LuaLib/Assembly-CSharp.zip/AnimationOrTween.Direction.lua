---@class AnimationOrTween.Direction : System.Enum
---@field public Reverse AnimationOrTween.Direction @static
---@field public Toggle AnimationOrTween.Direction @static
---@field public Forward AnimationOrTween.Direction @static
---@field public value__ number
local m = {}

AnimationOrTween.Direction = m
return m
