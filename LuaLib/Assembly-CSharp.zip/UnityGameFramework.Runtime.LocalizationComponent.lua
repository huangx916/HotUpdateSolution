---@class UnityGameFramework.Runtime.LocalizationComponent : UnityGameFramework.Runtime.GameFrameworkComponent
---@field public Language GameFramework.Localization.Language
---@field public SystemLanguage GameFramework.Localization.Language
---@field public DictionaryCount number
local m = {}

---@overload fun(dictionaryName:string, dictionaryAssetName:string, userData:any)
---@param dictionaryName string
---@param dictionaryAssetName string
function m:LoadDictionary(dictionaryName, dictionaryAssetName) end

---@overload fun(text:string, userData:any):boolean
---@param text string
---@return boolean
function m:ParseDictionary(text) end

---@overload fun(key:string):string
---@param key string
---@param args any[]|any
---@return string
function m:GetString(key, args) end

---@param key string
---@return boolean
function m:HasRawString(key) end

---@param key string
---@return string
function m:GetRawString(key) end

---@param key string
---@return boolean
function m:RemoveRawString(key) end

UnityGameFramework.Runtime.LocalizationComponent = m
return m
