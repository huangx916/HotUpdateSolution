---@class UnityGameFramework.Runtime.DefaultResourceHelper : UnityGameFramework.Runtime.ResourceHelperBase
local m = {}

---@virtual
---@param fileUri string
---@param loadBytesCallback fun(fileUri:string, bytes:string, errorMessage:string)
function m:LoadBytes(fileUri, loadBytesCallback) end

---@virtual
---@param sceneAssetName string
---@param unloadSceneCallbacks GameFramework.Resource.UnloadSceneCallbacks
---@param userData any
function m:UnloadScene(sceneAssetName, unloadSceneCallbacks, userData) end

---@virtual
---@param objectToRelease any
function m:Release(objectToRelease) end

UnityGameFramework.Runtime.DefaultResourceHelper = m
return m
