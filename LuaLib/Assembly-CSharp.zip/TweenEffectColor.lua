---@class TweenEffectColor : UITweener
---@field public from UnityEngine.Color
---@field public to UnityEngine.Color
---@field public color UnityEngine.Color
---@field public value UnityEngine.Color
local m = {}

---@static
---@param go UnityEngine.GameObject
---@param duration number
---@param color UnityEngine.Color
---@return TweenEffectColor
function m.Begin(go, duration, color) end

---@virtual
function m:SetStartToCurrentValue() end

---@virtual
function m:SetEndToCurrentValue() end

TweenEffectColor = m
return m
