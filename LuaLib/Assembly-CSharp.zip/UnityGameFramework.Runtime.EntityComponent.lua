---@class UnityGameFramework.Runtime.EntityComponent : UnityGameFramework.Runtime.GameFrameworkComponent
---@field public EntityCount number
---@field public EntityGroupCount number
local m = {}

---@param entityGroupName string
---@return boolean
function m:HasEntityGroup(entityGroupName) end

---@param entityGroupName string
---@return GameFramework.Entity.IEntityGroup
function m:GetEntityGroup(entityGroupName) end

---@return GameFramework.Entity.IEntityGroup[]
function m:GetAllEntityGroups() end

---@param entityGroupName string
---@param instanceAutoReleaseInterval number
---@param instanceCapacity number
---@param instanceExpireTime number
---@param instancePriority number
---@return boolean
function m:AddEntityGroup(entityGroupName, instanceAutoReleaseInterval, instanceCapacity, instanceExpireTime, instancePriority) end

---@overload fun(entityAssetName:string):boolean
---@param entityId number
---@return boolean
function m:HasEntity(entityId) end

---@overload fun(entityAssetName:string):UnityGameFramework.Runtime.Entity
---@param entityId number
---@return UnityGameFramework.Runtime.Entity
function m:GetEntity(entityId) end

---@param entityAssetName string
---@return UnityGameFramework.Runtime.Entity[]
function m:GetEntities(entityAssetName) end

---@return UnityGameFramework.Runtime.Entity[]
function m:GetAllLoadedEntities() end

---@return number[]
function m:GetAllLoadingEntityIds() end

---@param entityId number
---@return boolean
function m:IsLoadingEntity(entityId) end

---@param entity UnityGameFramework.Runtime.Entity
---@return boolean
function m:IsValidEntity(entity) end

---@overload fun(entityId:number, entityLogicType:System.Type, entityAssetName:string, entityGroupName:string)
---@overload fun(entityId:number, entityAssetName:string, entityGroupName:string, userData:any)
---@overload fun(entityId:number, entityLogicType:System.Type, entityAssetName:string, entityGroupName:string, userData:any)
---@param entityId number
---@param entityAssetName string
---@param entityGroupName string
function m:ShowEntity(entityId, entityAssetName, entityGroupName) end

---@overload fun(entityId:number, userData:any)
---@overload fun(entity:UnityGameFramework.Runtime.Entity)
---@overload fun(entity:UnityGameFramework.Runtime.Entity, userData:any)
---@param entityId number
function m:HideEntity(entityId) end

---@overload fun(userData:any)
function m:HideAllLoadedEntities() end

function m:HideAllLoadingEntities() end

---@overload fun(childEntity:UnityGameFramework.Runtime.Entity):UnityGameFramework.Runtime.Entity
---@param childEntityId number
---@return UnityGameFramework.Runtime.Entity
function m:GetParentEntity(childEntityId) end

---@overload fun(parentEntity:UnityGameFramework.Runtime.Entity):UnityGameFramework.Runtime.Entity[]
---@param parentEntityId number
---@return UnityGameFramework.Runtime.Entity[]
function m:GetChildEntities(parentEntityId) end

---@overload fun(childEntityId:number, parentEntity:UnityGameFramework.Runtime.Entity)
---@overload fun(childEntity:UnityGameFramework.Runtime.Entity, parentEntityId:number)
---@overload fun(childEntity:UnityGameFramework.Runtime.Entity, parentEntity:UnityGameFramework.Runtime.Entity)
---@overload fun(childEntityId:number, parentEntityId:number, parentTransformPath:string)
---@overload fun(childEntityId:number, parentEntity:UnityGameFramework.Runtime.Entity, parentTransformPath:string)
---@overload fun(childEntity:UnityGameFramework.Runtime.Entity, parentEntityId:number, parentTransformPath:string)
---@overload fun(childEntity:UnityGameFramework.Runtime.Entity, parentEntity:UnityGameFramework.Runtime.Entity, parentTransformPath:string)
---@overload fun(childEntityId:number, parentEntityId:number, parentTransform:UnityEngine.Transform)
---@overload fun(childEntityId:number, parentEntity:UnityGameFramework.Runtime.Entity, parentTransform:UnityEngine.Transform)
---@overload fun(childEntity:UnityGameFramework.Runtime.Entity, parentEntityId:number, parentTransform:UnityEngine.Transform)
---@overload fun(childEntity:UnityGameFramework.Runtime.Entity, parentEntity:UnityGameFramework.Runtime.Entity, parentTransform:UnityEngine.Transform)
---@overload fun(childEntityId:number, parentEntityId:number, userData:any)
---@overload fun(childEntityId:number, parentEntity:UnityGameFramework.Runtime.Entity, userData:any)
---@overload fun(childEntity:UnityGameFramework.Runtime.Entity, parentEntityId:number, userData:any)
---@overload fun(childEntity:UnityGameFramework.Runtime.Entity, parentEntity:UnityGameFramework.Runtime.Entity, userData:any)
---@overload fun(childEntityId:number, parentEntityId:number, parentTransformPath:string, userData:any)
---@overload fun(childEntityId:number, parentEntity:UnityGameFramework.Runtime.Entity, parentTransformPath:string, userData:any)
---@overload fun(childEntity:UnityGameFramework.Runtime.Entity, parentEntityId:number, parentTransformPath:string, userData:any)
---@overload fun(childEntity:UnityGameFramework.Runtime.Entity, parentEntity:UnityGameFramework.Runtime.Entity, parentTransformPath:string, userData:any)
---@overload fun(childEntityId:number, parentEntityId:number, parentTransform:UnityEngine.Transform, userData:any)
---@overload fun(childEntityId:number, parentEntity:UnityGameFramework.Runtime.Entity, parentTransform:UnityEngine.Transform, userData:any)
---@overload fun(childEntity:UnityGameFramework.Runtime.Entity, parentEntityId:number, parentTransform:UnityEngine.Transform, userData:any)
---@overload fun(childEntity:UnityGameFramework.Runtime.Entity, parentEntity:UnityGameFramework.Runtime.Entity, parentTransform:UnityEngine.Transform, userData:any)
---@param childEntityId number
---@param parentEntityId number
function m:AttachEntity(childEntityId, parentEntityId) end

---@overload fun(childEntityId:number, userData:any)
---@overload fun(childEntity:UnityGameFramework.Runtime.Entity)
---@overload fun(childEntity:UnityGameFramework.Runtime.Entity, userData:any)
---@param childEntityId number
function m:DetachEntity(childEntityId) end

---@overload fun(parentEntityId:number, userData:any)
---@overload fun(parentEntity:UnityGameFramework.Runtime.Entity)
---@overload fun(parentEntity:UnityGameFramework.Runtime.Entity, userData:any)
---@param parentEntityId number
function m:DetachChildEntities(parentEntityId) end

---@param entity UnityGameFramework.Runtime.Entity
---@param locked boolean
function m:SetInstanceLocked(entity, locked) end

---@param entity UnityGameFramework.Runtime.Entity
---@param priority number
function m:SetInstancePriority(entity, priority) end

UnityGameFramework.Runtime.EntityComponent = m
return m
