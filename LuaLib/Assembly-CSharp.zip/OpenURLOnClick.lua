---@class OpenURLOnClick : UnityEngine.MonoBehaviour
local m = {}

OpenURLOnClick = m
return m
