---@class UIScrollBar : UISlider
---@field public scrollValue number
---@field public barSize number
local m = {}

---@virtual
function m:ForceUpdate() end

UIScrollBar = m
return m
