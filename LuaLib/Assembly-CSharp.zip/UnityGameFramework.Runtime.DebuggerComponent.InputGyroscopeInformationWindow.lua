---@class UnityGameFramework.Runtime.DebuggerComponent.InputGyroscopeInformationWindow : UnityGameFramework.Runtime.DebuggerComponent.ScrollableDebuggerWindowBase
local m = {}

UnityGameFramework.Runtime.DebuggerComponent.InputGyroscopeInformationWindow = m
return m
