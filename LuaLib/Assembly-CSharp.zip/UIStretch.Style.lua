---@class UIStretch.Style : System.Enum
---@field public None UIStretch.Style @static
---@field public Horizontal UIStretch.Style @static
---@field public Vertical UIStretch.Style @static
---@field public Both UIStretch.Style @static
---@field public BasedOnHeight UIStretch.Style @static
---@field public FillKeepingRatio UIStretch.Style @static
---@field public FitInternalKeepingRatio UIStretch.Style @static
---@field public value__ number
local m = {}

UIStretch.Style = m
return m
