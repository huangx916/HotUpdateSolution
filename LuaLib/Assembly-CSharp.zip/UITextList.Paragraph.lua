---@class UITextList.Paragraph : System.Object
---@field public text string
---@field public lines string[]
local m = {}

UITextList.Paragraph = m
return m
