---@class InvBaseItem : System.Object
---@field public id16 number
---@field public name string
---@field public description string
---@field public slot InvBaseItem.Slot
---@field public minItemLevel number
---@field public maxItemLevel number
---@field public stats InvStat[]
---@field public attachment UnityEngine.GameObject
---@field public color UnityEngine.Color
---@field public iconAtlas UIAtlas
---@field public iconName string
local m = {}

InvBaseItem = m
return m
