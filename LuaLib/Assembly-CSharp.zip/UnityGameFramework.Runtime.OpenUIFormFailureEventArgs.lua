---@class UnityGameFramework.Runtime.OpenUIFormFailureEventArgs : GameFramework.Event.GameEventArgs
---@field public Id number
---@field public SerialId number
---@field public UIFormAssetName string
---@field public UIGroupName string
---@field public PauseCoveredUIForm boolean
---@field public ErrorMessage string
---@field public UserData any
local m = {}

UnityGameFramework.Runtime.OpenUIFormFailureEventArgs = m
return m
