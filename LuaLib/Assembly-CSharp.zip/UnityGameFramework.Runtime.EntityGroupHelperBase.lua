---@class UnityGameFramework.Runtime.EntityGroupHelperBase : UnityEngine.MonoBehaviour
local m = {}

UnityGameFramework.Runtime.EntityGroupHelperBase = m
return m
