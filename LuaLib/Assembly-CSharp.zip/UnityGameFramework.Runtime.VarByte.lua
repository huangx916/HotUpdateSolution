---@class UnityGameFramework.Runtime.VarByte : GameFramework.Variable_1_System_Byte_
local m = {}

---@overload fun(value:UnityGameFramework.Runtime.VarByte):number @static
---@static
---@param value number
---@return UnityGameFramework.Runtime.VarByte
function m.op_Implicit(value) end

UnityGameFramework.Runtime.VarByte = m
return m
