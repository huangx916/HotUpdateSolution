---@class UnityGameFramework.Runtime.UIFormHelperBase : UnityEngine.MonoBehaviour
local m = {}

---@abstract
---@param uiFormAsset any
---@return any
function m:InstantiateUIForm(uiFormAsset) end

---@abstract
---@param uiFormInstance any
---@param uiGroup GameFramework.UI.IUIGroup
---@param userData any
---@return GameFramework.UI.IUIForm
function m:CreateUIForm(uiFormInstance, uiGroup, userData) end

---@abstract
---@param uiFormAsset any
---@param uiFormInstance any
function m:ReleaseUIForm(uiFormAsset, uiFormInstance) end

UnityGameFramework.Runtime.UIFormHelperBase = m
return m
