---@class UnityGameFramework.Runtime.NetworkErrorEventArgs : GameFramework.Event.GameEventArgs
---@field public Id number
---@field public NetworkChannel GameFramework.Network.INetworkChannel
---@field public ErrorCode GameFramework.Network.NetworkErrorCode
---@field public ErrorMessage string
local m = {}

UnityGameFramework.Runtime.NetworkErrorEventArgs = m
return m
