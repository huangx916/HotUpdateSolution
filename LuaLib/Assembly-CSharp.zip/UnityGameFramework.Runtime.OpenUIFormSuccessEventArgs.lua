---@class UnityGameFramework.Runtime.OpenUIFormSuccessEventArgs : GameFramework.Event.GameEventArgs
---@field public Id number
---@field public UIForm UnityGameFramework.Runtime.UIForm
---@field public Duration number
---@field public UserData any
local m = {}

UnityGameFramework.Runtime.OpenUIFormSuccessEventArgs = m
return m
