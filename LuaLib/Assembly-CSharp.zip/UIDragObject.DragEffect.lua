---@class UIDragObject.DragEffect : System.Enum
---@field public None UIDragObject.DragEffect @static
---@field public Momentum UIDragObject.DragEffect @static
---@field public MomentumAndSpring UIDragObject.DragEffect @static
---@field public value__ number
local m = {}

UIDragObject.DragEffect = m
return m
