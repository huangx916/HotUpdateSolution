---@class UnityGameFramework.Runtime.WebRequestFailureEventArgs : GameFramework.Event.GameEventArgs
---@field public Id number
---@field public SerialId number
---@field public WebRequestUri string
---@field public ErrorMessage string
---@field public UserData any
local m = {}

UnityGameFramework.Runtime.WebRequestFailureEventArgs = m
return m
