---@class AnimationOrTween.DisableCondition : System.Enum
---@field public DisableAfterReverse AnimationOrTween.DisableCondition @static
---@field public DoNotDisable AnimationOrTween.DisableCondition @static
---@field public DisableAfterForward AnimationOrTween.DisableCondition @static
---@field public value__ number
local m = {}

AnimationOrTween.DisableCondition = m
return m
