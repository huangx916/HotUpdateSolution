---@class UILabel : UIWidget
---@field public keepCrispWhenShrunk UILabel.Crispness
---@field public customModifier fun(s:string):string
---@field public finalFontSize number
---@field public isAnchoredHorizontally boolean
---@field public isAnchoredVertically boolean
---@field public material UnityEngine.Material
---@field public mainTexture UnityEngine.Texture
---@field public font UIFont
---@field public bitmapFont UIFont
---@field public trueTypeFont UnityEngine.Font
---@field public ambigiousFont UnityEngine.Object
---@field public text string
---@field public defaultFontSize number
---@field public fontSize number
---@field public fontStyle UnityEngine.FontStyle
---@field public alignment NGUIText.Alignment
---@field public applyGradient boolean
---@field public gradientTop UnityEngine.Color
---@field public gradientBottom UnityEngine.Color
---@field public spacingX number
---@field public spacingY number
---@field public useFloatSpacing boolean
---@field public floatSpacingX number
---@field public floatSpacingY number
---@field public effectiveSpacingY number
---@field public effectiveSpacingX number
---@field public overflowEllipsis boolean
---@field public overflowWidth number
---@field public supportEncoding boolean
---@field public symbolStyle NGUIText.SymbolStyle
---@field public overflowMethod UILabel.Overflow
---@field public lineWidth number
---@field public lineHeight number
---@field public multiLine boolean
---@field public localCorners UnityEngine.Vector3[]
---@field public worldCorners UnityEngine.Vector3[]
---@field public drawingDimensions UnityEngine.Vector4
---@field public maxLineCount number
---@field public effectStyle UILabel.Effect
---@field public effectColor UnityEngine.Color
---@field public effectDistance UnityEngine.Vector2
---@field public quadsPerCharacter number
---@field public shrinkToFit boolean
---@field public processedText string
---@field public printedSize UnityEngine.Vector2
---@field public localSize UnityEngine.Vector2
---@field public modifier UILabel.Modifier
---@field public printedText string
local m = {}

---@virtual
---@param relativeTo UnityEngine.Transform
---@return UnityEngine.Vector3[]
function m:GetSides(relativeTo) end

---@virtual
function m:MarkAsChanged() end

---@overload fun(legacyMode:boolean)
---@overload fun()
---@param legacyMode boolean
---@param full boolean
function m:ProcessText(legacyMode, full) end

---@virtual
function m:MakePixelPerfect() end

function m:AssumeNaturalSize() end

---@overload fun(localPos:UnityEngine.Vector2):number
---@overload fun(currentIndex:number, key:UnityEngine.KeyCode):number
---@param worldPos UnityEngine.Vector3
---@return number
function m:GetCharacterIndex(worldPos) end

---@overload fun(localPos:UnityEngine.Vector2, precise:boolean):number
---@param worldPos UnityEngine.Vector3
---@param precise boolean
---@return number
function m:GetCharacterIndexAtPosition(worldPos, precise) end

---@overload fun(localPos:UnityEngine.Vector2):string
---@param worldPos UnityEngine.Vector3
---@return string
function m:GetWordAtPosition(worldPos) end

---@param characterIndex number
---@return string
function m:GetWordAtCharacterIndex(characterIndex) end

---@overload fun(localPos:UnityEngine.Vector2):string
---@param worldPos UnityEngine.Vector3
---@return string
function m:GetUrlAtPosition(worldPos) end

---@param characterIndex number
---@return string
function m:GetUrlAtCharacterIndex(characterIndex) end

---@param start number
---@param _end number
---@param caret UIGeometry
---@param highlight UIGeometry
---@param caretColor UnityEngine.Color
---@param highlightColor UnityEngine.Color
function m:PrintOverlay(start, _end, caret, highlight, caretColor, highlightColor) end

---@virtual
---@param verts UnityEngine.Vector3[]
---@param uvs UnityEngine.Vector2[]
---@param cols UnityEngine.Color[]
function m:OnFill(verts, uvs, cols) end

---@param verts UnityEngine.Vector3[]
---@param start number
---@return UnityEngine.Vector2
function m:ApplyOffset(verts, start) end

---@param verts UnityEngine.Vector3[]
---@param uvs UnityEngine.Vector2[]
---@param cols UnityEngine.Color[]
---@param start number
---@param _end number
---@param x number
---@param y number
function m:ApplyShadow(verts, uvs, cols, start, _end, x, y) end

---@param text string
---@return number
function m:CalculateOffsetToFit(text) end

function m:SetCurrentProgress() end

function m:SetCurrentPercent() end

function m:SetCurrentSelection() end

---@overload fun(text:string, height:number):boolean, System.String
---@param text string
---@return boolean, System.String
function m:Wrap(text) end

function m:UpdateNGUIText() end

UILabel = m
return m
