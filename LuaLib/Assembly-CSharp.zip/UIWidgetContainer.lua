---@class UIWidgetContainer : UnityEngine.MonoBehaviour
local m = {}

UIWidgetContainer = m
return m
