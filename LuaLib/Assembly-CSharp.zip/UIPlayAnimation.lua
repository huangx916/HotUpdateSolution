---@class UIPlayAnimation : UnityEngine.MonoBehaviour
---@field public current UIPlayAnimation @static
---@field public target UnityEngine.Animation
---@field public animator UnityEngine.Animator
---@field public clipName string
---@field public trigger AnimationOrTween.Trigger
---@field public playDirection AnimationOrTween.Direction
---@field public resetOnPlay boolean
---@field public clearSelection boolean
---@field public ifDisabledOnPlay AnimationOrTween.EnableCondition
---@field public disableWhenFinished AnimationOrTween.DisableCondition
---@field public onFinished EventDelegate[]
local m = {}

---@overload fun(forward:boolean, onlyIfDifferent:boolean)
---@param forward boolean
function m:Play(forward) end

function m:PlayForward() end

function m:PlayReverse() end

UIPlayAnimation = m
return m
