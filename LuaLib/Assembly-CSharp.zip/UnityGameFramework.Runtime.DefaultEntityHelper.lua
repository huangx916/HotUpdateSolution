---@class UnityGameFramework.Runtime.DefaultEntityHelper : UnityGameFramework.Runtime.EntityHelperBase
local m = {}

---@virtual
---@param entityAsset any
---@return any
function m:InstantiateEntity(entityAsset) end

---@virtual
---@param entityInstance any
---@param entityGroup GameFramework.Entity.IEntityGroup
---@param userData any
---@return GameFramework.Entity.IEntity
function m:CreateEntity(entityInstance, entityGroup, userData) end

---@virtual
---@param entityAsset any
---@param entityInstance any
function m:ReleaseEntity(entityAsset, entityInstance) end

UnityGameFramework.Runtime.DefaultEntityHelper = m
return m
