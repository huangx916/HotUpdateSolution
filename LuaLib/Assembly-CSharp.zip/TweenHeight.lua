---@class TweenHeight : UITweener
---@field public from number
---@field public to number
---@field public updateTable boolean
---@field public cachedWidget UIWidget
---@field public height number
---@field public value number
local m = {}

---@static
---@param widget UIWidget
---@param duration number
---@param height number
---@return TweenHeight
function m.Begin(widget, duration, height) end

---@virtual
function m:SetStartToCurrentValue() end

---@virtual
function m:SetEndToCurrentValue() end

TweenHeight = m
return m
