---@class UISpriteAnimation : UnityEngine.MonoBehaviour
---@field public frameIndex number
---@field public frames number
---@field public framesPerSecond number
---@field public namePrefix string
---@field public loop boolean
---@field public isPlaying boolean
local m = {}

function m:RebuildSpriteList() end

function m:Play() end

function m:Pause() end

function m:ResetToBeginning() end

UISpriteAnimation = m
return m
