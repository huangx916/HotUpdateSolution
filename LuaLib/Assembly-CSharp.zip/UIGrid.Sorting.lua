---@class UIGrid.Sorting : System.Enum
---@field public None UIGrid.Sorting @static
---@field public Alphabetic UIGrid.Sorting @static
---@field public Horizontal UIGrid.Sorting @static
---@field public Vertical UIGrid.Sorting @static
---@field public Custom UIGrid.Sorting @static
---@field public value__ number
local m = {}

UIGrid.Sorting = m
return m
