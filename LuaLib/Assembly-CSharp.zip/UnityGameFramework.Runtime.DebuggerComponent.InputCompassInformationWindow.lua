---@class UnityGameFramework.Runtime.DebuggerComponent.InputCompassInformationWindow : UnityGameFramework.Runtime.DebuggerComponent.ScrollableDebuggerWindowBase
local m = {}

UnityGameFramework.Runtime.DebuggerComponent.InputCompassInformationWindow = m
return m
