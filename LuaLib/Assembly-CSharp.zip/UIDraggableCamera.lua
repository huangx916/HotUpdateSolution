---@class UIDraggableCamera : UnityEngine.MonoBehaviour
---@field public rootForBounds UnityEngine.Transform
---@field public scale UnityEngine.Vector2
---@field public scrollWheelFactor number
---@field public dragEffect UIDragObject.DragEffect
---@field public smoothDragStart boolean
---@field public momentumAmount number
---@field public currentMomentum UnityEngine.Vector2
local m = {}

---@param immediate boolean
---@return boolean
function m:ConstrainToBounds(immediate) end

---@param isPressed boolean
function m:Press(isPressed) end

---@param delta UnityEngine.Vector2
function m:Drag(delta) end

---@param delta number
function m:Scroll(delta) end

UIDraggableCamera = m
return m
