---@class PropertyBinding.Direction : System.Enum
---@field public SourceUpdatesTarget PropertyBinding.Direction @static
---@field public TargetUpdatesSource PropertyBinding.Direction @static
---@field public BiDirectional PropertyBinding.Direction @static
---@field public value__ number
local m = {}

PropertyBinding.Direction = m
return m
