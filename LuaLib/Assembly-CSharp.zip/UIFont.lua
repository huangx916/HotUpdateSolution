---@class UIFont : UnityEngine.MonoBehaviour
---@field public bmFont BMFont
---@field public texWidth number
---@field public texHeight number
---@field public hasSymbols boolean
---@field public symbols BMSymbol[]
---@field public atlas UIAtlas
---@field public material UnityEngine.Material
---@field public premultipliedAlpha boolean
---@field public premultipliedAlphaShader boolean
---@field public packedFontShader boolean
---@field public texture UnityEngine.Texture2D
---@field public uvRect UnityEngine.Rect
---@field public spriteName string
---@field public isValid boolean
---@field public size number
---@field public defaultSize number
---@field public sprite UISpriteData
---@field public replacement UIFont
---@field public isDynamic boolean
---@field public dynamicFont UnityEngine.Font
---@field public dynamicFontStyle UnityEngine.FontStyle
local m = {}

---@static
---@param a UIFont
---@param b UIFont
---@return boolean
function m.CheckIfRelated(a, b) end

function m:MarkAsChanged() end

function m:UpdateUVRect() end

---@param text string
---@param offset number
---@param textLength number
---@return BMSymbol
function m:MatchSymbol(text, offset, textLength) end

---@param sequence string
---@param spriteName string
function m:AddSymbol(sequence, spriteName) end

---@param sequence string
function m:RemoveSymbol(sequence) end

---@param before string
---@param after string
function m:RenameSymbol(before, after) end

---@param s string
---@return boolean
function m:UsesSprite(s) end

UIFont = m
return m
