---@class UnityGameFramework.Runtime.VarColor : GameFramework.Variable_1_UnityEngine_Color_
local m = {}

---@overload fun(value:UnityGameFramework.Runtime.VarColor):UnityEngine.Color @static
---@static
---@param value UnityEngine.Color
---@return UnityGameFramework.Runtime.VarColor
function m.op_Implicit(value) end

UnityGameFramework.Runtime.VarColor = m
return m
