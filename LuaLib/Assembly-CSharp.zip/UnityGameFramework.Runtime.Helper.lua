---@class UnityGameFramework.Runtime.Helper : System.Object
local m = {}

---@overload fun(helperTypeName:string, customHelper:UnityEngine.MonoBehaviour, index:number):UnityEngine.MonoBehaviour @static
---@static
---@param helperTypeName string
---@param customHelper UnityEngine.MonoBehaviour
---@return UnityEngine.MonoBehaviour
function m.CreateHelper(helperTypeName, customHelper) end

UnityGameFramework.Runtime.Helper = m
return m
