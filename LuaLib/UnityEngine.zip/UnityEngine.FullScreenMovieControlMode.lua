---@class UnityEngine.FullScreenMovieControlMode : System.Enum
---@field public Full UnityEngine.FullScreenMovieControlMode @static
---@field public Minimal UnityEngine.FullScreenMovieControlMode @static
---@field public CancelOnInput UnityEngine.FullScreenMovieControlMode @static
---@field public Hidden UnityEngine.FullScreenMovieControlMode @static
---@field public value__ number
local m = {}

UnityEngine.FullScreenMovieControlMode = m
return m
