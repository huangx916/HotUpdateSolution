---@class UnityEngine.GradientAlphaKey : System.ValueType
---@field public alpha number
---@field public time number
local m = {}

UnityEngine.GradientAlphaKey = m
return m
