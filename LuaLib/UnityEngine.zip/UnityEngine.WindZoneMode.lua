---@class UnityEngine.WindZoneMode : System.Enum
---@field public Directional UnityEngine.WindZoneMode @static
---@field public Spherical UnityEngine.WindZoneMode @static
---@field public value__ number
local m = {}

UnityEngine.WindZoneMode = m
return m
