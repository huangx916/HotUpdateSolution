---@class UnityEngine.JointAngleLimits2D : System.ValueType
---@field public min number
---@field public max number
local m = {}

UnityEngine.JointAngleLimits2D = m
return m
