---@class UnityEngine.ParticleSystemCollisionQuality : System.Enum
---@field public High UnityEngine.ParticleSystemCollisionQuality @static
---@field public Medium UnityEngine.ParticleSystemCollisionQuality @static
---@field public Low UnityEngine.ParticleSystemCollisionQuality @static
---@field public value__ number
local m = {}

UnityEngine.ParticleSystemCollisionQuality = m
return m
