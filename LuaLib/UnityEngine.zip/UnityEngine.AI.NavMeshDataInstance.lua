---@class UnityEngine.AI.NavMeshDataInstance : System.ValueType
---@field public valid boolean
---@field public owner UnityEngine.Object
local m = {}

function m:Remove() end

UnityEngine.AI.NavMeshDataInstance = m
return m
