---@class UnityEngine.CollisionFlags : System.Enum
---@field public None UnityEngine.CollisionFlags @static
---@field public Sides UnityEngine.CollisionFlags @static
---@field public Above UnityEngine.CollisionFlags @static
---@field public Below UnityEngine.CollisionFlags @static
---@field public CollidedSides UnityEngine.CollisionFlags @static
---@field public CollidedAbove UnityEngine.CollisionFlags @static
---@field public CollidedBelow UnityEngine.CollisionFlags @static
---@field public value__ number
local m = {}

UnityEngine.CollisionFlags = m
return m
