---@class UnityEngine.CharacterController : UnityEngine.Collider
---@field public isGrounded boolean
---@field public velocity UnityEngine.Vector3
---@field public collisionFlags UnityEngine.CollisionFlags
---@field public radius number
---@field public height number
---@field public center UnityEngine.Vector3
---@field public slopeLimit number
---@field public stepOffset number
---@field public skinWidth number
---@field public minMoveDistance number
---@field public detectCollisions boolean
---@field public enableOverlapRecovery boolean
local m = {}

---@param speed UnityEngine.Vector3
---@return boolean
function m:SimpleMove(speed) end

---@param motion UnityEngine.Vector3
---@return UnityEngine.CollisionFlags
function m:Move(motion) end

UnityEngine.CharacterController = m
return m
