---@class UnityEngine.ControllerColliderHit : System.Object
---@field public controller UnityEngine.CharacterController
---@field public collider UnityEngine.Collider
---@field public rigidbody UnityEngine.Rigidbody
---@field public gameObject UnityEngine.GameObject
---@field public transform UnityEngine.Transform
---@field public point UnityEngine.Vector3
---@field public normal UnityEngine.Vector3
---@field public moveDirection UnityEngine.Vector3
---@field public moveLength number
local m = {}

UnityEngine.ControllerColliderHit = m
return m
