---@class UnityEngine.RigidbodyType2D : System.Enum
---@field public Dynamic UnityEngine.RigidbodyType2D @static
---@field public Kinematic UnityEngine.RigidbodyType2D @static
---@field public Static UnityEngine.RigidbodyType2D @static
---@field public value__ number
local m = {}

UnityEngine.RigidbodyType2D = m
return m
