---@class UnityEngine.ParticleSystem.TriggerModule : System.ValueType
---@field public enabled boolean
---@field public inside UnityEngine.ParticleSystemOverlapAction
---@field public outside UnityEngine.ParticleSystemOverlapAction
---@field public enter UnityEngine.ParticleSystemOverlapAction
---@field public exit UnityEngine.ParticleSystemOverlapAction
---@field public radiusScale number
---@field public maxColliderCount number
local m = {}

---@param index number
---@param collider UnityEngine.Component
function m:SetCollider(index, collider) end

---@param index number
---@return UnityEngine.Component
function m:GetCollider(index) end

UnityEngine.ParticleSystem.TriggerModule = m
return m
