---@class UnityEngine.Collider2D : UnityEngine.Behaviour
---@field public density number
---@field public isTrigger boolean
---@field public usedByEffector boolean
---@field public usedByComposite boolean
---@field public composite UnityEngine.CompositeCollider2D
---@field public offset UnityEngine.Vector2
---@field public attachedRigidbody UnityEngine.Rigidbody2D
---@field public shapeCount number
---@field public bounds UnityEngine.Bounds
---@field public sharedMaterial UnityEngine.PhysicsMaterial2D
---@field public friction number
---@field public bounciness number
local m = {}

---@overload fun(collider:UnityEngine.Collider2D, contactFilter:UnityEngine.ContactFilter2D):boolean
---@overload fun(contactFilter:UnityEngine.ContactFilter2D):boolean
---@param collider UnityEngine.Collider2D
---@return boolean
function m:IsTouching(collider) end

---@overload fun():boolean
---@param layerMask number
---@return boolean
function m:IsTouchingLayers(layerMask) end

---@param point UnityEngine.Vector2
---@return boolean
function m:OverlapPoint(point) end

---@param contactFilter UnityEngine.ContactFilter2D
---@param results UnityEngine.Collider2D[]
---@return number
function m:OverlapCollider(contactFilter, results) end

---@overload fun(direction:UnityEngine.Vector2, contactFilter:UnityEngine.ContactFilter2D, results:UnityEngine.RaycastHit2D[], distance:number):number
---@overload fun(direction:UnityEngine.Vector2, results:UnityEngine.RaycastHit2D[], distance:number, layerMask:number, minDepth:number):number
---@overload fun(direction:UnityEngine.Vector2, results:UnityEngine.RaycastHit2D[], distance:number, layerMask:number):number
---@overload fun(direction:UnityEngine.Vector2, results:UnityEngine.RaycastHit2D[], distance:number):number
---@overload fun(direction:UnityEngine.Vector2, results:UnityEngine.RaycastHit2D[]):number
---@overload fun(direction:UnityEngine.Vector2, results:UnityEngine.RaycastHit2D[], distance:number, layerMask:number, minDepth:number, maxDepth:number):number
---@param direction UnityEngine.Vector2
---@param contactFilter UnityEngine.ContactFilter2D
---@param results UnityEngine.RaycastHit2D[]
---@return number
function m:Raycast(direction, contactFilter, results) end

---@overload fun(direction:UnityEngine.Vector2, contactFilter:UnityEngine.ContactFilter2D, results:UnityEngine.RaycastHit2D[]):number
---@overload fun(direction:UnityEngine.Vector2, contactFilter:UnityEngine.ContactFilter2D, results:UnityEngine.RaycastHit2D[], distance:number, ignoreSiblingColliders:boolean):number
---@overload fun(direction:UnityEngine.Vector2, results:UnityEngine.RaycastHit2D[], distance:number):number
---@overload fun(direction:UnityEngine.Vector2, results:UnityEngine.RaycastHit2D[]):number
---@overload fun(direction:UnityEngine.Vector2, results:UnityEngine.RaycastHit2D[], distance:number, ignoreSiblingColliders:boolean):number
---@param direction UnityEngine.Vector2
---@param contactFilter UnityEngine.ContactFilter2D
---@param results UnityEngine.RaycastHit2D[]
---@param distance number
---@return number
function m:Cast(direction, contactFilter, results, distance) end

---@overload fun(contactFilter:UnityEngine.ContactFilter2D, contacts:UnityEngine.ContactPoint2D[]):number
---@overload fun(colliders:UnityEngine.Collider2D[]):number
---@overload fun(contactFilter:UnityEngine.ContactFilter2D, colliders:UnityEngine.Collider2D[]):number
---@param contacts UnityEngine.ContactPoint2D[]
---@return number
function m:GetContacts(contacts) end

---@param collider UnityEngine.Collider2D
---@return UnityEngine.ColliderDistance2D
function m:Distance(collider) end

UnityEngine.Collider2D = m
return m
