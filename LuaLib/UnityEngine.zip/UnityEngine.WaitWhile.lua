---@class UnityEngine.WaitWhile : UnityEngine.CustomYieldInstruction
---@field public keepWaiting boolean
local m = {}

UnityEngine.WaitWhile = m
return m
