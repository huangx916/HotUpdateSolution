---@class UnityEngine.MeshCollider : UnityEngine.Collider
---@field public sharedMesh UnityEngine.Mesh
---@field public convex boolean
---@field public inflateMesh boolean
---@field public skinWidth number
---@field public smoothSphereCollisions boolean
local m = {}

UnityEngine.MeshCollider = m
return m
