---@class UnityEngine.ParticleSystem.NoiseModule : System.ValueType
---@field public enabled boolean
---@field public separateAxes boolean
---@field public strength UnityEngine.ParticleSystem.MinMaxCurve
---@field public strengthMultiplier number
---@field public strengthX UnityEngine.ParticleSystem.MinMaxCurve
---@field public strengthXMultiplier number
---@field public strengthY UnityEngine.ParticleSystem.MinMaxCurve
---@field public strengthYMultiplier number
---@field public strengthZ UnityEngine.ParticleSystem.MinMaxCurve
---@field public strengthZMultiplier number
---@field public frequency number
---@field public damping boolean
---@field public octaveCount number
---@field public octaveMultiplier number
---@field public octaveScale number
---@field public quality UnityEngine.ParticleSystemNoiseQuality
---@field public scrollSpeed UnityEngine.ParticleSystem.MinMaxCurve
---@field public scrollSpeedMultiplier number
---@field public remapEnabled boolean
---@field public remap UnityEngine.ParticleSystem.MinMaxCurve
---@field public remapMultiplier number
---@field public remapX UnityEngine.ParticleSystem.MinMaxCurve
---@field public remapXMultiplier number
---@field public remapY UnityEngine.ParticleSystem.MinMaxCurve
---@field public remapYMultiplier number
---@field public remapZ UnityEngine.ParticleSystem.MinMaxCurve
---@field public remapZMultiplier number
local m = {}

UnityEngine.ParticleSystem.NoiseModule = m
return m
