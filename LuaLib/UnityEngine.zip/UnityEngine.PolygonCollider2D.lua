---@class UnityEngine.PolygonCollider2D : UnityEngine.Collider2D
---@field public points UnityEngine.Vector2[]
---@field public pathCount number
---@field public autoTiling boolean
local m = {}

---@param index number
---@return UnityEngine.Vector2[]
function m:GetPath(index) end

---@param index number
---@param points UnityEngine.Vector2[]
function m:SetPath(index, points) end

---@return number
function m:GetTotalPointCount() end

---@overload fun(sides:number, scale:UnityEngine.Vector2)
---@overload fun(sides:number)
---@param sides number
---@param scale UnityEngine.Vector2
---@param offset UnityEngine.Vector2
function m:CreatePrimitive(sides, scale, offset) end

UnityEngine.PolygonCollider2D = m
return m
