---@class UnityEngine.CursorMode : System.Enum
---@field public Auto UnityEngine.CursorMode @static
---@field public ForceSoftware UnityEngine.CursorMode @static
---@field public value__ number
local m = {}

UnityEngine.CursorMode = m
return m
