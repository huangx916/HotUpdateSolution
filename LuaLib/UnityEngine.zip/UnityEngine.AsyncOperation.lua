---@class UnityEngine.AsyncOperation : UnityEngine.YieldInstruction
---@field public isDone boolean
---@field public progress number
---@field public priority number
---@field public allowSceneActivation boolean
local m = {}

UnityEngine.AsyncOperation = m
return m
