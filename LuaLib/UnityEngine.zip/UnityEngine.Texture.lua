---@class UnityEngine.Texture : UnityEngine.Object
---@field public masterTextureLimit number @static
---@field public anisotropicFiltering UnityEngine.AnisotropicFiltering @static
---@field public width number
---@field public height number
---@field public dimension UnityEngine.Rendering.TextureDimension
---@field public filterMode UnityEngine.FilterMode
---@field public anisoLevel number
---@field public wrapMode UnityEngine.TextureWrapMode
---@field public mipMapBias number
---@field public texelSize UnityEngine.Vector2
local m = {}

---@static
---@param forcedMin number
---@param globalMax number
function m.SetGlobalAnisotropicFilteringLimits(forcedMin, globalMax) end

---@return System.IntPtr
function m:GetNativeTexturePtr() end

---@return number
function m:GetNativeTextureID() end

UnityEngine.Texture = m
return m
