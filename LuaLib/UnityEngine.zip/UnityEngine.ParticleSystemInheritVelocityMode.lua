---@class UnityEngine.ParticleSystemInheritVelocityMode : System.Enum
---@field public Initial UnityEngine.ParticleSystemInheritVelocityMode @static
---@field public Current UnityEngine.ParticleSystemInheritVelocityMode @static
---@field public value__ number
local m = {}

UnityEngine.ParticleSystemInheritVelocityMode = m
return m
