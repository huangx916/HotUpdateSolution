---@class UnityEngine.PlayerConnectionInternal : System.Object
local m = {}

---@static
---@return boolean
function m.IsConnected() end

---@static
function m.Initialize() end

---@static
---@param messageId string
function m.RegisterInternal(messageId) end

---@static
---@param messageId string
function m.UnregisterInternal(messageId) end

---@static
---@param messageId string
---@param data string
---@param playerId number
function m.SendMessage(messageId, data, playerId) end

UnityEngine.PlayerConnectionInternal = m
return m
