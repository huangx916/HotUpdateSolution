---@class UnityEngine.ApplicationSandboxType : System.Enum
---@field public Unknown UnityEngine.ApplicationSandboxType @static
---@field public NotSandboxed UnityEngine.ApplicationSandboxType @static
---@field public Sandboxed UnityEngine.ApplicationSandboxType @static
---@field public SandboxBroken UnityEngine.ApplicationSandboxType @static
---@field public value__ number
local m = {}

UnityEngine.ApplicationSandboxType = m
return m
