---@class UnityEngine.Halo : UnityEngine.Behaviour
local m = {}

UnityEngine.Halo = m
return m
