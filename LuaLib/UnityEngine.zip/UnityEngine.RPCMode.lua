---@class UnityEngine.RPCMode : System.Enum
---@field public Server UnityEngine.RPCMode @static
---@field public Others UnityEngine.RPCMode @static
---@field public OthersBuffered UnityEngine.RPCMode @static
---@field public All UnityEngine.RPCMode @static
---@field public AllBuffered UnityEngine.RPCMode @static
---@field public value__ number
local m = {}

UnityEngine.RPCMode = m
return m
