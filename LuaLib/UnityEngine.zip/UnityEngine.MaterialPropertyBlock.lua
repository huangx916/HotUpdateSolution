---@class UnityEngine.MaterialPropertyBlock : System.Object
---@field public isEmpty boolean
local m = {}

function m:Clear() end

---@overload fun(nameID:number, value:number)
---@param name string
---@param value number
function m:SetFloat(name, value) end

---@overload fun(nameID:number, value:UnityEngine.Vector4)
---@param name string
---@param value UnityEngine.Vector4
function m:SetVector(name, value) end

---@overload fun(nameID:number, value:UnityEngine.Color)
---@param name string
---@param value UnityEngine.Color
function m:SetColor(name, value) end

---@overload fun(nameID:number, value:UnityEngine.Matrix4x4)
---@param name string
---@param value UnityEngine.Matrix4x4
function m:SetMatrix(name, value) end

---@overload fun(nameID:number, value:UnityEngine.ComputeBuffer)
---@param name string
---@param value UnityEngine.ComputeBuffer
function m:SetBuffer(name, value) end

---@overload fun(nameID:number, value:UnityEngine.Texture)
---@param name string
---@param value UnityEngine.Texture
function m:SetTexture(name, value) end

---@overload fun(nameID:number, values:number[])
---@overload fun(name:string, values:number[])
---@overload fun(nameID:number, values:number[])
---@param name string
---@param values number[]
function m:SetFloatArray(name, values) end

---@overload fun(nameID:number, values:UnityEngine.Vector4[])
---@overload fun(name:string, values:UnityEngine.Vector4[])
---@overload fun(nameID:number, values:UnityEngine.Vector4[])
---@param name string
---@param values UnityEngine.Vector4[]
function m:SetVectorArray(name, values) end

---@overload fun(nameID:number, values:UnityEngine.Matrix4x4[])
---@overload fun(name:string, values:UnityEngine.Matrix4x4[])
---@overload fun(nameID:number, values:UnityEngine.Matrix4x4[])
---@param name string
---@param values UnityEngine.Matrix4x4[]
function m:SetMatrixArray(name, values) end

---@overload fun(nameID:number):number
---@param name string
---@return number
function m:GetFloat(name) end

---@overload fun(nameID:number):UnityEngine.Vector4
---@param name string
---@return UnityEngine.Vector4
function m:GetVector(name) end

---@overload fun(nameID:number):UnityEngine.Matrix4x4
---@param name string
---@return UnityEngine.Matrix4x4
function m:GetMatrix(name) end

---@overload fun(nameID:number, values:number[])
---@overload fun(name:string):number[]
---@overload fun(nameID:number):number[]
---@param name string
---@param values number[]
function m:GetFloatArray(name, values) end

---@overload fun(nameID:number, values:UnityEngine.Vector4[])
---@overload fun(name:string):UnityEngine.Vector4[]
---@overload fun(nameID:number):UnityEngine.Vector4[]
---@param name string
---@param values UnityEngine.Vector4[]
function m:GetVectorArray(name, values) end

---@overload fun(nameID:number, values:UnityEngine.Matrix4x4[])
---@overload fun(name:string):UnityEngine.Matrix4x4[]
---@overload fun(nameID:number):UnityEngine.Matrix4x4[]
---@param name string
---@param values UnityEngine.Matrix4x4[]
function m:GetMatrixArray(name, values) end

---@overload fun(nameID:number):UnityEngine.Texture
---@param name string
---@return UnityEngine.Texture
function m:GetTexture(name) end

---@overload fun(nameID:number, value:number)
---@param name string
---@param value number
function m:AddFloat(name, value) end

---@overload fun(nameID:number, value:UnityEngine.Vector4)
---@param name string
---@param value UnityEngine.Vector4
function m:AddVector(name, value) end

---@overload fun(nameID:number, value:UnityEngine.Color)
---@param name string
---@param value UnityEngine.Color
function m:AddColor(name, value) end

---@overload fun(nameID:number, value:UnityEngine.Matrix4x4)
---@param name string
---@param value UnityEngine.Matrix4x4
function m:AddMatrix(name, value) end

---@overload fun(nameID:number, value:UnityEngine.Texture)
---@param name string
---@param value UnityEngine.Texture
function m:AddTexture(name, value) end

UnityEngine.MaterialPropertyBlock = m
return m
