---@class UnityEngine.WheelFrictionCurve : System.ValueType
---@field public extremumSlip number
---@field public extremumValue number
---@field public asymptoteSlip number
---@field public asymptoteValue number
---@field public stiffness number
local m = {}

UnityEngine.WheelFrictionCurve = m
return m
