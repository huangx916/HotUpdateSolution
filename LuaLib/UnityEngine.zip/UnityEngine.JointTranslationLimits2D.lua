---@class UnityEngine.JointTranslationLimits2D : System.ValueType
---@field public min number
---@field public max number
local m = {}

UnityEngine.JointTranslationLimits2D = m
return m
