---@class UnityEngine.PhysicMaterial : UnityEngine.Object
---@field public dynamicFriction number
---@field public staticFriction number
---@field public bounciness number
---@field public bouncyness number
---@field public frictionDirection2 UnityEngine.Vector3
---@field public dynamicFriction2 number
---@field public staticFriction2 number
---@field public frictionCombine UnityEngine.PhysicMaterialCombine
---@field public bounceCombine UnityEngine.PhysicMaterialCombine
---@field public frictionDirection UnityEngine.Vector3
local m = {}

UnityEngine.PhysicMaterial = m
return m
