---@class UnityEngine.BitStream : System.Object
---@field public isReading boolean
---@field public isWriting boolean
local m = {}

---@overload fun(value:System.Char):System.Char
---@overload fun(value:System.Int16):System.Int16
---@overload fun(value:System.Int32):System.Int32
---@overload fun(value:System.Single):System.Single
---@overload fun(value:System.Single, maxDelta:number):System.Single
---@overload fun(value:UnityEngine.Quaternion):UnityEngine.Quaternion
---@overload fun(value:UnityEngine.Quaternion, maxDelta:number):UnityEngine.Quaternion
---@overload fun(value:UnityEngine.Vector3):UnityEngine.Vector3
---@overload fun(value:UnityEngine.Vector3, maxDelta:number):UnityEngine.Vector3
---@overload fun(value:UnityEngine.NetworkPlayer):UnityEngine.NetworkPlayer
---@overload fun(viewID:UnityEngine.NetworkViewID):UnityEngine.NetworkViewID
---@param value System.Boolean
---@return System.Boolean
function m:Serialize(value) end

UnityEngine.BitStream = m
return m
