---@class UnityEngine.ParticleSystem.CollisionModule : System.ValueType
---@field public enabled boolean
---@field public type UnityEngine.ParticleSystemCollisionType
---@field public mode UnityEngine.ParticleSystemCollisionMode
---@field public dampen UnityEngine.ParticleSystem.MinMaxCurve
---@field public dampenMultiplier number
---@field public bounce UnityEngine.ParticleSystem.MinMaxCurve
---@field public bounceMultiplier number
---@field public lifetimeLoss UnityEngine.ParticleSystem.MinMaxCurve
---@field public lifetimeLossMultiplier number
---@field public minKillSpeed number
---@field public maxKillSpeed number
---@field public collidesWith UnityEngine.LayerMask
---@field public enableDynamicColliders boolean
---@field public enableInteriorCollisions boolean
---@field public maxCollisionShapes number
---@field public quality UnityEngine.ParticleSystemCollisionQuality
---@field public voxelSize number
---@field public radiusScale number
---@field public sendCollisionMessages boolean
---@field public maxPlaneCount number
local m = {}

---@param index number
---@param transform UnityEngine.Transform
function m:SetPlane(index, transform) end

---@param index number
---@return UnityEngine.Transform
function m:GetPlane(index) end

UnityEngine.ParticleSystem.CollisionModule = m
return m
