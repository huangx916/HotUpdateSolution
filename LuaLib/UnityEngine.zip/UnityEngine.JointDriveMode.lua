---@class UnityEngine.JointDriveMode : System.Enum
---@field public None UnityEngine.JointDriveMode @static
---@field public Position UnityEngine.JointDriveMode @static
---@field public Velocity UnityEngine.JointDriveMode @static
---@field public PositionAndVelocity UnityEngine.JointDriveMode @static
---@field public value__ number
local m = {}

UnityEngine.JointDriveMode = m
return m
