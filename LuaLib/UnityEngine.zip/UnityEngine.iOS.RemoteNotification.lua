---@class UnityEngine.iOS.RemoteNotification : System.Object
---@field public alertBody string
---@field public hasAction boolean
---@field public applicationIconBadgeNumber number
---@field public soundName string
---@field public userInfo System.Collections.IDictionary
local m = {}

UnityEngine.iOS.RemoteNotification = m
return m
