---@class UnityEngine.ParticleSystemSimulationSpace : System.Enum
---@field public Local UnityEngine.ParticleSystemSimulationSpace @static
---@field public World UnityEngine.ParticleSystemSimulationSpace @static
---@field public Custom UnityEngine.ParticleSystemSimulationSpace @static
---@field public value__ number
local m = {}

UnityEngine.ParticleSystemSimulationSpace = m
return m
