---@class UnityEngine.SpritePackingRotation : System.Enum
---@field public None UnityEngine.SpritePackingRotation @static
---@field public Any UnityEngine.SpritePackingRotation @static
---@field public value__ number
local m = {}

UnityEngine.SpritePackingRotation = m
return m
