---@class UnityEngine.Rendering.SortingGroup : UnityEngine.Behaviour
---@field public sortingLayerName string
---@field public sortingLayerID number
---@field public sortingOrder number
local m = {}

UnityEngine.Rendering.SortingGroup = m
return m
