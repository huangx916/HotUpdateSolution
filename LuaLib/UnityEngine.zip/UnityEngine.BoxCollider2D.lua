---@class UnityEngine.BoxCollider2D : UnityEngine.Collider2D
---@field public center UnityEngine.Vector2
---@field public size UnityEngine.Vector2
---@field public edgeRadius number
---@field public autoTiling boolean
local m = {}

UnityEngine.BoxCollider2D = m
return m
