---@class UnityEngine.Experimental.Director.Playable : System.Object
---@field public handle UnityEngine.Experimental.Director.PlayableHandle
local m = {}

---@static
---@param b UnityEngine.Experimental.Director.Playable
---@return UnityEngine.Experimental.Director.PlayableHandle
function m.op_Implicit(b) end

---@return boolean
function m:IsValid() end

UnityEngine.Experimental.Director.Playable = m
return m
