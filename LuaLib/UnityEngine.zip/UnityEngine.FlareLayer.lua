---@class UnityEngine.FlareLayer : UnityEngine.Behaviour
local m = {}

UnityEngine.FlareLayer = m
return m
