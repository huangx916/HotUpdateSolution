---@class UnityEngine.TrailRenderer : UnityEngine.Renderer
---@field public time number
---@field public startWidth number
---@field public endWidth number
---@field public widthCurve UnityEngine.AnimationCurve
---@field public widthMultiplier number
---@field public startColor UnityEngine.Color
---@field public endColor UnityEngine.Color
---@field public colorGradient UnityEngine.Gradient
---@field public autodestruct boolean
---@field public numCornerVertices number
---@field public numCapVertices number
---@field public minVertexDistance number
---@field public textureMode UnityEngine.LineTextureMode
---@field public alignment UnityEngine.LineAlignment
---@field public positionCount number
---@field public numPositions number
local m = {}

function m:Clear() end

---@param index number
---@return UnityEngine.Vector3
function m:GetPosition(index) end

---@param positions UnityEngine.Vector3[]
---@return number
function m:GetPositions(positions) end

UnityEngine.TrailRenderer = m
return m
