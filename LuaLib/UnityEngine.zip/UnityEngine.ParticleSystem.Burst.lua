---@class UnityEngine.ParticleSystem.Burst : System.ValueType
---@field public time number
---@field public minCount number
---@field public maxCount number
---@field public cycleCount number
---@field public repeatInterval number
local m = {}

UnityEngine.ParticleSystem.Burst = m
return m
