---@class UnityEngine.AreaEffector2D : UnityEngine.Effector2D
---@field public forceDirection number
---@field public forceAngle number
---@field public useGlobalAngle boolean
---@field public forceMagnitude number
---@field public forceVariation number
---@field public drag number
---@field public angularDrag number
---@field public forceTarget UnityEngine.EffectorSelection2D
local m = {}

UnityEngine.AreaEffector2D = m
return m
