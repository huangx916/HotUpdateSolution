---@class UnityEngine.JointLimits : System.ValueType
---@field public minBounce number
---@field public maxBounce number
---@field public min number
---@field public max number
---@field public bounciness number
---@field public bounceMinVelocity number
---@field public contactDistance number
local m = {}

UnityEngine.JointLimits = m
return m
