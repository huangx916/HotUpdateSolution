---@class UnityEngine.SceneManagement.LoadSceneMode : System.Enum
---@field public Single UnityEngine.SceneManagement.LoadSceneMode @static
---@field public Additive UnityEngine.SceneManagement.LoadSceneMode @static
---@field public value__ number
local m = {}

UnityEngine.SceneManagement.LoadSceneMode = m
return m
