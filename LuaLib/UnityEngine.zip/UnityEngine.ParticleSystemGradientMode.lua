---@class UnityEngine.ParticleSystemGradientMode : System.Enum
---@field public Color UnityEngine.ParticleSystemGradientMode @static
---@field public Gradient UnityEngine.ParticleSystemGradientMode @static
---@field public TwoColors UnityEngine.ParticleSystemGradientMode @static
---@field public TwoGradients UnityEngine.ParticleSystemGradientMode @static
---@field public RandomColor UnityEngine.ParticleSystemGradientMode @static
---@field public value__ number
local m = {}

UnityEngine.ParticleSystemGradientMode = m
return m
