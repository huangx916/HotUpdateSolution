---@class UnityEngine.ParticleSystemCurveMode : System.Enum
---@field public Constant UnityEngine.ParticleSystemCurveMode @static
---@field public Curve UnityEngine.ParticleSystemCurveMode @static
---@field public TwoCurves UnityEngine.ParticleSystemCurveMode @static
---@field public TwoConstants UnityEngine.ParticleSystemCurveMode @static
---@field public value__ number
local m = {}

UnityEngine.ParticleSystemCurveMode = m
return m
