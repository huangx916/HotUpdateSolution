---@class UnityEngine.Experimental.Rendering.ShaderPassName : System.ValueType
local m = {}

UnityEngine.Experimental.Rendering.ShaderPassName = m
return m
