---@class UnityEngine.Experimental.Director.PlayState : System.Enum
---@field public Paused UnityEngine.Experimental.Director.PlayState @static
---@field public Playing UnityEngine.Experimental.Director.PlayState @static
---@field public value__ number
local m = {}

UnityEngine.Experimental.Director.PlayState = m
return m
