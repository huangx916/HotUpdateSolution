---@class UnityEngine.Collision : System.Object
---@field public relativeVelocity UnityEngine.Vector3
---@field public rigidbody UnityEngine.Rigidbody
---@field public collider UnityEngine.Collider
---@field public transform UnityEngine.Transform
---@field public gameObject UnityEngine.GameObject
---@field public contacts UnityEngine.ContactPoint[]
---@field public impulse UnityEngine.Vector3
---@field public impactForceSum UnityEngine.Vector3
---@field public frictionForceSum UnityEngine.Vector3
---@field public other UnityEngine.Component
local m = {}

---@virtual
---@return System.Collections.IEnumerator
function m:GetEnumerator() end

UnityEngine.Collision = m
return m
