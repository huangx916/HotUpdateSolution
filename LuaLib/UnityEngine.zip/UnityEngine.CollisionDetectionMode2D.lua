---@class UnityEngine.CollisionDetectionMode2D : System.Enum
---@field public None UnityEngine.CollisionDetectionMode2D @static
---@field public Discrete UnityEngine.CollisionDetectionMode2D @static
---@field public Continuous UnityEngine.CollisionDetectionMode2D @static
---@field public value__ number
local m = {}

UnityEngine.CollisionDetectionMode2D = m
return m
