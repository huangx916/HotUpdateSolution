---@class UnityEngine.CircleCollider2D : UnityEngine.Collider2D
---@field public center UnityEngine.Vector2
---@field public radius number
local m = {}

UnityEngine.CircleCollider2D = m
return m
