---@class UnityEngine.AI.NavMeshData : UnityEngine.Object
---@field public sourceBounds UnityEngine.Bounds
---@field public position UnityEngine.Vector3
---@field public rotation UnityEngine.Quaternion
local m = {}

UnityEngine.AI.NavMeshData = m
return m
