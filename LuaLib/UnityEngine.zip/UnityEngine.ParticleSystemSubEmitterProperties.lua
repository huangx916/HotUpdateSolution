---@class UnityEngine.ParticleSystemSubEmitterProperties : System.Enum
---@field public InheritNothing UnityEngine.ParticleSystemSubEmitterProperties @static
---@field public InheritEverything UnityEngine.ParticleSystemSubEmitterProperties @static
---@field public InheritColor UnityEngine.ParticleSystemSubEmitterProperties @static
---@field public InheritSize UnityEngine.ParticleSystemSubEmitterProperties @static
---@field public InheritRotation UnityEngine.ParticleSystemSubEmitterProperties @static
---@field public value__ number
local m = {}

UnityEngine.ParticleSystemSubEmitterProperties = m
return m
