---@class UnityEngine.ParticleSystem.ForceOverLifetimeModule : System.ValueType
---@field public enabled boolean
---@field public x UnityEngine.ParticleSystem.MinMaxCurve
---@field public y UnityEngine.ParticleSystem.MinMaxCurve
---@field public z UnityEngine.ParticleSystem.MinMaxCurve
---@field public xMultiplier number
---@field public yMultiplier number
---@field public zMultiplier number
---@field public space UnityEngine.ParticleSystemSimulationSpace
---@field public randomized boolean
local m = {}

UnityEngine.ParticleSystem.ForceOverLifetimeModule = m
return m
