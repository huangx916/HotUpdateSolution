---@class UnityEngineInternal.LightmapType : System.Enum
---@field public NoLightmap UnityEngineInternal.LightmapType @static
---@field public StaticLightmap UnityEngineInternal.LightmapType @static
---@field public DynamicLightmap UnityEngineInternal.LightmapType @static
---@field public value__ number
local m = {}

UnityEngineInternal.LightmapType = m
return m
