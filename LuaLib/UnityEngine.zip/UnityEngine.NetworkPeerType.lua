---@class UnityEngine.NetworkPeerType : System.Enum
---@field public Disconnected UnityEngine.NetworkPeerType @static
---@field public Server UnityEngine.NetworkPeerType @static
---@field public Client UnityEngine.NetworkPeerType @static
---@field public Connecting UnityEngine.NetworkPeerType @static
---@field public value__ number
local m = {}

UnityEngine.NetworkPeerType = m
return m
