---@class UnityEngine.WSA.TileForegroundText : System.Enum
---@field public Default UnityEngine.WSA.TileForegroundText @static
---@field public Dark UnityEngine.WSA.TileForegroundText @static
---@field public Light UnityEngine.WSA.TileForegroundText @static
---@field public value__ number
local m = {}

UnityEngine.WSA.TileForegroundText = m
return m
