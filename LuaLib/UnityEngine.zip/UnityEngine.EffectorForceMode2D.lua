---@class UnityEngine.EffectorForceMode2D : System.Enum
---@field public Constant UnityEngine.EffectorForceMode2D @static
---@field public InverseLinear UnityEngine.EffectorForceMode2D @static
---@field public InverseSquared UnityEngine.EffectorForceMode2D @static
---@field public value__ number
local m = {}

UnityEngine.EffectorForceMode2D = m
return m
