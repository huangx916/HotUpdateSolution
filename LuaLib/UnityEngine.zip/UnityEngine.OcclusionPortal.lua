---@class UnityEngine.OcclusionPortal : UnityEngine.Component
---@field public open boolean
local m = {}

UnityEngine.OcclusionPortal = m
return m
