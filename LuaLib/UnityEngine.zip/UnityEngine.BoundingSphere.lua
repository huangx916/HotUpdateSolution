---@class UnityEngine.BoundingSphere : System.ValueType
---@field public position UnityEngine.Vector3
---@field public radius number
local m = {}

UnityEngine.BoundingSphere = m
return m
