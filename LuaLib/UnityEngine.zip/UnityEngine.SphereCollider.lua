---@class UnityEngine.SphereCollider : UnityEngine.Collider
---@field public center UnityEngine.Vector3
---@field public radius number
local m = {}

UnityEngine.SphereCollider = m
return m
