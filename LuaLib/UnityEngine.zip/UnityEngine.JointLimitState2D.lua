---@class UnityEngine.JointLimitState2D : System.Enum
---@field public Inactive UnityEngine.JointLimitState2D @static
---@field public LowerLimit UnityEngine.JointLimitState2D @static
---@field public UpperLimit UnityEngine.JointLimitState2D @static
---@field public EqualLimits UnityEngine.JointLimitState2D @static
---@field public value__ number
local m = {}

UnityEngine.JointLimitState2D = m
return m
