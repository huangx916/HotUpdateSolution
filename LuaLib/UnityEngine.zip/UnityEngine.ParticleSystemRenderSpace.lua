---@class UnityEngine.ParticleSystemRenderSpace : System.Enum
---@field public View UnityEngine.ParticleSystemRenderSpace @static
---@field public World UnityEngine.ParticleSystemRenderSpace @static
---@field public Local UnityEngine.ParticleSystemRenderSpace @static
---@field public Facing UnityEngine.ParticleSystemRenderSpace @static
---@field public value__ number
local m = {}

UnityEngine.ParticleSystemRenderSpace = m
return m
