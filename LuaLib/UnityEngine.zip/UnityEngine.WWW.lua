---@class UnityEngine.WWW : System.Object
---@field public responseHeaders System.Collections.Generic.Dictionary_2_System_String_System_String_
---@field public text string
---@field public data string
---@field public bytes string
---@field public size number
---@field public error string
---@field public texture UnityEngine.Texture2D
---@field public textureNonReadable UnityEngine.Texture2D
---@field public audioClip UnityEngine.Object
---@field public movie UnityEngine.Object
---@field public isDone boolean
---@field public progress number
---@field public uploadProgress number
---@field public bytesDownloaded number
---@field public oggVorbis UnityEngine.Object
---@field public url string
---@field public assetBundle UnityEngine.AssetBundle
---@field public threadPriority UnityEngine.ThreadPriority
local m = {}

---@virtual
function m:Dispose() end

---@param url string
---@param postData string
---@param iHeaders string[]
function m:InitWWW(url, postData, iHeaders) end

---@overload fun(s:string, e:System.Text.Encoding):string @static
---@static
---@param s string
---@return string
function m.EscapeURL(s) end

---@overload fun(s:string, e:System.Text.Encoding):string @static
---@static
---@param s string
---@return string
function m.UnEscapeURL(s) end

---@param tex UnityEngine.Texture2D
function m:LoadImageIntoTexture(tex) end

---@static
---@param url string
---@return string
function m.GetURL(url) end

---@static
---@param url string
---@return UnityEngine.Texture2D
function m.GetTextureFromURL(url) end

function m:LoadUnityWeb() end

---@overload fun(url:string, version:number, crc:number):UnityEngine.WWW @static
---@overload fun(url:string, hash:UnityEngine.Hash128):UnityEngine.WWW @static
---@overload fun(url:string, hash:UnityEngine.Hash128, crc:number):UnityEngine.WWW @static
---@static
---@param url string
---@param version number
---@return UnityEngine.WWW
function m.LoadFromCacheOrDownload(url, version) end

---@overload fun(threeD:boolean):UnityEngine.AudioClip @extension
---@overload fun(threeD:boolean, stream:boolean):UnityEngine.AudioClip @extension
---@overload fun(threeD:boolean, stream:boolean, audioType:UnityEngine.AudioType):UnityEngine.AudioClip @extension
---@extension
---@return UnityEngine.AudioClip
function m.GetAudioClip() end

---@overload fun(threeD:boolean):UnityEngine.AudioClip @extension
---@overload fun(threeD:boolean, audioType:UnityEngine.AudioType):UnityEngine.AudioClip @extension
---@extension
---@return UnityEngine.AudioClip
function m.GetAudioClipCompressed() end

---@extension
---@return UnityEngine.MovieTexture
function m.GetMovieTexture() end

UnityEngine.WWW = m
return m
