---@class UnityEngine.ParticleSystem.ExternalForcesModule : System.ValueType
---@field public enabled boolean
---@field public multiplier number
local m = {}

UnityEngine.ParticleSystem.ExternalForcesModule = m
return m
