---@class UnityEngine.ParticleSystem.ColorBySpeedModule : System.ValueType
---@field public enabled boolean
---@field public color UnityEngine.ParticleSystem.MinMaxGradient
---@field public range UnityEngine.Vector2
local m = {}

UnityEngine.ParticleSystem.ColorBySpeedModule = m
return m
