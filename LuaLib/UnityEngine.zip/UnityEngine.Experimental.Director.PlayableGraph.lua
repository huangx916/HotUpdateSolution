---@class UnityEngine.Experimental.Director.PlayableGraph : System.ValueType
---@field public isDone boolean
---@field public playableCount number
---@field public scriptOutputCount number
---@field public rootPlayableCount number
local m = {}

---@return boolean
function m:IsValid() end

---@static
---@return UnityEngine.Experimental.Director.PlayableGraph
function m.CreateGraph() end

function m:Play() end

function m:Stop() end

---@param name string
---@return UnityEngine.Experimental.Director.ScriptPlayableOutput
function m:CreateScriptOutput(name) end

---@param index number
---@return UnityEngine.Experimental.Director.ScriptPlayableOutput
function m:GetScriptOutput(index) end

---@return UnityEngine.Experimental.Director.PlayableHandle
function m:CreatePlayable() end

---@overload fun(inputCount:number):UnityEngine.Experimental.Director.PlayableHandle
---@return UnityEngine.Experimental.Director.PlayableHandle
function m:CreateGenericMixerPlayable() end

---@return UnityEngine.Experimental.Director.PlayableHandle
function m:CreateScriptPlayable() end

function m:Destroy() end

---@overload fun(source:UnityEngine.Experimental.Director.Playable, sourceOutputPort:number, destination:UnityEngine.Experimental.Director.Playable, destinationInputPort:number):boolean
---@param source UnityEngine.Experimental.Director.PlayableHandle
---@param sourceOutputPort number
---@param destination UnityEngine.Experimental.Director.PlayableHandle
---@param destinationInputPort number
---@return boolean
function m:Connect(source, sourceOutputPort, destination, destinationInputPort) end

---@overload fun(playable:UnityEngine.Experimental.Director.PlayableHandle, inputPort:number)
---@param playable UnityEngine.Experimental.Director.Playable
---@param inputPort number
function m:Disconnect(playable, inputPort) end

---@param playable UnityEngine.Experimental.Director.PlayableHandle
function m:DestroyPlayable(playable) end

---@overload fun(output:UnityEngine.Experimental.Director.AnimationPlayableOutput) @extension
---@param output UnityEngine.Experimental.Director.ScriptPlayableOutput
function m:DestroyOutput(output) end

---@param playable UnityEngine.Experimental.Director.PlayableHandle
function m:DestroySubgraph(playable) end

---@overload fun(deltaTime:number)
function m:Evaluate() end

---@param index number
---@return UnityEngine.Experimental.Director.PlayableHandle
function m:GetRootPlayable(index) end

---@extension
---@param name string
---@param target UnityEngine.Animator
---@return UnityEngine.Experimental.Director.AnimationPlayableOutput
function m.CreateAnimationOutput(name, target) end

---@extension
---@param clip UnityEngine.AnimationClip
---@return UnityEngine.Experimental.Director.PlayableHandle
function m.CreateAnimationClipPlayable(clip) end

---@overload fun():UnityEngine.Experimental.Director.PlayableHandle @extension
---@overload fun(inputCount:number, normalizeWeights:boolean):UnityEngine.Experimental.Director.PlayableHandle @extension
---@extension
---@param inputCount number
---@return UnityEngine.Experimental.Director.PlayableHandle
function m.CreateAnimationMixerPlayable(inputCount) end

---@extension
---@param controller UnityEngine.RuntimeAnimatorController
---@return UnityEngine.Experimental.Director.PlayableHandle
function m.CreateAnimatorControllerPlayable(controller) end

---@extension
---@return number
function m.GetAnimationOutputCount() end

---@extension
---@param index number
---@return UnityEngine.Experimental.Director.AnimationPlayableOutput
function m.GetAnimationOutput(index) end

UnityEngine.Experimental.Director.PlayableGraph = m
return m
