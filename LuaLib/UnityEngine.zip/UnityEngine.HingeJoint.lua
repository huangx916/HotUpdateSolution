---@class UnityEngine.HingeJoint : UnityEngine.Joint
---@field public motor UnityEngine.JointMotor
---@field public limits UnityEngine.JointLimits
---@field public spring UnityEngine.JointSpring
---@field public useMotor boolean
---@field public useLimits boolean
---@field public useSpring boolean
---@field public velocity number
---@field public angle number
local m = {}

UnityEngine.HingeJoint = m
return m
