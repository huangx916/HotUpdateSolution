---@class UnityEngine.AI.NavMeshBuildMarkup : System.ValueType
---@field public overrideArea boolean
---@field public area number
---@field public ignoreFromBuild boolean
---@field public root UnityEngine.Transform
local m = {}

UnityEngine.AI.NavMeshBuildMarkup = m
return m
