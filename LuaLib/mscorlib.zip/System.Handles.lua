---@class System.Handles : System.Enum
---@field public STD_INPUT System.Handles @static
---@field public STD_OUTPUT System.Handles @static
---@field public STD_ERROR System.Handles @static
---@field public value__ number
local m = {}

System.Handles = m
return m
