---@class Microsoft.Win32.SafeHandles.SafeHandleMinusOneIsInvalid : System.Runtime.InteropServices.SafeHandle
---@field public IsInvalid boolean
local m = {}

Microsoft.Win32.SafeHandles.SafeHandleMinusOneIsInvalid = m
return m
