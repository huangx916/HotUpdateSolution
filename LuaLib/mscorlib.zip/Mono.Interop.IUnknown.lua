---@class Mono.Interop.IUnknown : table
local m = {}

Mono.Interop.IUnknown = m
return m
