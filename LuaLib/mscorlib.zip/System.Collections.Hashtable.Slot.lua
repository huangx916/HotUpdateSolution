---@class System.Collections.Hashtable.Slot : System.ValueType
local m = {}

System.Collections.Hashtable.Slot = m
return m
