---@class System.CLSCompliantAttribute : System.Attribute
---@field public IsCompliant boolean
local m = {}

System.CLSCompliantAttribute = m
return m
