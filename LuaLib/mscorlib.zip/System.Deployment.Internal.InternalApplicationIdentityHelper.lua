---@class System.Deployment.Internal.InternalApplicationIdentityHelper : System.Object
local m = {}

---@static
---@param appInfo System.ActivationContext
---@return any
function m.GetActivationContextData(appInfo) end

---@static
---@param id System.ApplicationIdentity
---@return any
function m.GetInternalAppId(id) end

System.Deployment.Internal.InternalApplicationIdentityHelper = m
return m
