---@class System.MonoDocumentationNoteAttribute : System.MonoTODOAttribute
local m = {}

System.MonoDocumentationNoteAttribute = m
return m
