---@class System.IAsyncResult : table
---@field public AsyncState any
---@field public AsyncWaitHandle System.Threading.WaitHandle
---@field public CompletedSynchronously boolean
---@field public IsCompleted boolean
local m = {}

System.IAsyncResult = m
return m
