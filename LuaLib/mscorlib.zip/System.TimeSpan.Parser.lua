---@class System.TimeSpan.Parser : System.Object
---@field public AtEnd boolean
local m = {}

---@return System.TimeSpan
function m:Execute() end

System.TimeSpan.Parser = m
return m
