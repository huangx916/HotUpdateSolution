---@class System.NotImplementedException : System.SystemException
local m = {}

System.NotImplementedException = m
return m
