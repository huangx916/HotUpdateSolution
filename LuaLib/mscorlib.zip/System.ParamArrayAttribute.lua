---@class System.ParamArrayAttribute : System.Attribute
local m = {}

System.ParamArrayAttribute = m
return m
