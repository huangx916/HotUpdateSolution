---@class System.DateTime.Which : System.Enum
---@field public Day System.DateTime.Which @static
---@field public DayYear System.DateTime.Which @static
---@field public Month System.DateTime.Which @static
---@field public Year System.DateTime.Which @static
---@field public value__ number
local m = {}

System.DateTime.Which = m
return m
