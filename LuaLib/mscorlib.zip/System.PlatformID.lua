---@class System.PlatformID : System.Enum
---@field public Win32S System.PlatformID @static
---@field public Win32Windows System.PlatformID @static
---@field public Win32NT System.PlatformID @static
---@field public WinCE System.PlatformID @static
---@field public Unix System.PlatformID @static
---@field public Xbox System.PlatformID @static
---@field public MacOSX System.PlatformID @static
---@field public value__ number
local m = {}

System.PlatformID = m
return m
