---@class System.Collections.Hashtable.KeyMarker : System.Object
---@field public Removed System.Collections.Hashtable.KeyMarker @static
local m = {}

---@virtual
---@param context System.Runtime.Serialization.StreamingContext
---@return any
function m:GetRealObject(context) end

System.Collections.Hashtable.KeyMarker = m
return m
