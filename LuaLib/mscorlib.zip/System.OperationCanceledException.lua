---@class System.OperationCanceledException : System.SystemException
local m = {}

System.OperationCanceledException = m
return m
