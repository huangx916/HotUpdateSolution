---@class System.ConsoleScreenBufferInfo : System.ValueType
---@field public Size System.Coord
---@field public CursorPosition System.Coord
---@field public Attribute number
---@field public Window System.SmallRect
---@field public MaxWindowSize System.Coord
local m = {}

System.ConsoleScreenBufferInfo = m
return m
