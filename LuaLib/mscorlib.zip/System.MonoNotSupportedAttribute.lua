---@class System.MonoNotSupportedAttribute : System.MonoTODOAttribute
local m = {}

System.MonoNotSupportedAttribute = m
return m
