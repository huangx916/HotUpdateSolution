---@class System.MonoCustomAttrs : System.Object
local m = {}

System.MonoCustomAttrs = m
return m
