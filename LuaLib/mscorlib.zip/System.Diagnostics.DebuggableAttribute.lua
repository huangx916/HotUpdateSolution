---@class System.Diagnostics.DebuggableAttribute : System.Attribute
---@field public DebuggingFlags System.Diagnostics.DebuggableAttribute.DebuggingModes
---@field public IsJITTrackingEnabled boolean
---@field public IsJITOptimizerDisabled boolean
local m = {}

System.Diagnostics.DebuggableAttribute = m
return m
