---@class System.String : System.Object
---@field public Empty string @static
---@field public Chars number
---@field public Length number
local m = {}

---@overload fun(obj:any):boolean @virtual
---@overload fun(value:string):boolean @virtual
---@overload fun(a:string, b:string, comparisonType:System.StringComparison):boolean @static
---@overload fun(value:string, comparisonType:System.StringComparison):boolean
---@static
---@param a string
---@param b string
---@return boolean
function m.Equals(a, b) end

---@virtual
---@return any
function m:Clone() end

---@virtual
---@return System.TypeCode
function m:GetTypeCode() end

---@param sourceIndex number
---@param destination number[]
---@param destinationIndex number
---@param count number
function m:CopyTo(sourceIndex, destination, destinationIndex, count) end

---@overload fun(startIndex:number, length:number):number[]
---@return number[]
function m:ToCharArray() end

---@overload fun():string[]
---@overload fun(separator:number[], count:number):string[]
---@overload fun(separator:number[], count:number, options:System.StringSplitOptions):string[]
---@overload fun(separator:string[], count:number, options:System.StringSplitOptions):string[]
---@overload fun(separator:number[], options:System.StringSplitOptions):string[]
---@overload fun(separator:string[], options:System.StringSplitOptions):string[]
---@param separator number[]|number
---@return string[]
function m:Split(separator) end

---@overload fun(startIndex:number, length:number):string
---@param startIndex number
---@return string
function m:Substring(startIndex) end

---@overload fun(trimChars:number[]):string
---@overload fun():string
---@return string
function m:Trim() end

---@overload fun():string
---@param trimChars number[]|number
---@return string
function m:TrimStart(trimChars) end

---@overload fun():string
---@param trimChars number[]|number
---@return string
function m:TrimEnd(trimChars) end

---@overload fun(strA:string, strB:string, ignoreCase:boolean):number @static
---@overload fun(strA:string, strB:string, ignoreCase:boolean, culture:System.Globalization.CultureInfo):number @static
---@overload fun(strA:string, indexA:number, strB:string, indexB:number, length:number):number @static
---@overload fun(strA:string, indexA:number, strB:string, indexB:number, length:number, ignoreCase:boolean):number @static
---@overload fun(strA:string, indexA:number, strB:string, indexB:number, length:number, ignoreCase:boolean, culture:System.Globalization.CultureInfo):number @static
---@overload fun(strA:string, strB:string, comparisonType:System.StringComparison):number @static
---@overload fun(strA:string, indexA:number, strB:string, indexB:number, length:number, comparisonType:System.StringComparison):number @static
---@overload fun(strA:string, strB:string, culture:System.Globalization.CultureInfo, options:System.Globalization.CompareOptions):number @static
---@overload fun(strA:string, indexA:number, strB:string, indexB:number, length:number, culture:System.Globalization.CultureInfo, options:System.Globalization.CompareOptions):number @static
---@static
---@param strA string
---@param strB string
---@return number
function m.Compare(strA, strB) end

---@overload fun(strB:string):number @virtual
---@virtual
---@param value any
---@return number
function m:CompareTo(value) end

---@overload fun(strA:string, indexA:number, strB:string, indexB:number, length:number):number @static
---@static
---@param strA string
---@param strB string
---@return number
function m.CompareOrdinal(strA, strB) end

---@overload fun(value:string, ignoreCase:boolean, culture:System.Globalization.CultureInfo):boolean
---@overload fun(value:string, comparisonType:System.StringComparison):boolean
---@param value string
---@return boolean
function m:EndsWith(value) end

---@overload fun(anyOf:number[], startIndex:number):number
---@overload fun(anyOf:number[], startIndex:number, count:number):number
---@param anyOf number[]
---@return number
function m:IndexOfAny(anyOf) end

---@overload fun(value:string, startIndex:number, comparisonType:System.StringComparison):number
---@overload fun(value:string, startIndex:number, count:number, comparisonType:System.StringComparison):number
---@overload fun(value:number):number
---@overload fun(value:number, startIndex:number):number
---@overload fun(value:number, startIndex:number, count:number):number
---@overload fun(value:string):number
---@overload fun(value:string, startIndex:number):number
---@overload fun(value:string, startIndex:number, count:number):number
---@param value string
---@param comparisonType System.StringComparison
---@return number
function m:IndexOf(value, comparisonType) end

---@overload fun(value:string, startIndex:number, comparisonType:System.StringComparison):number
---@overload fun(value:string, startIndex:number, count:number, comparisonType:System.StringComparison):number
---@overload fun(value:number):number
---@overload fun(value:number, startIndex:number):number
---@overload fun(value:number, startIndex:number, count:number):number
---@overload fun(value:string):number
---@overload fun(value:string, startIndex:number):number
---@overload fun(value:string, startIndex:number, count:number):number
---@param value string
---@param comparisonType System.StringComparison
---@return number
function m:LastIndexOf(value, comparisonType) end

---@overload fun(anyOf:number[], startIndex:number):number
---@overload fun(anyOf:number[], startIndex:number, count:number):number
---@param anyOf number[]
---@return number
function m:LastIndexOfAny(anyOf) end

---@param value string
---@return boolean
function m:Contains(value) end

---@static
---@param value string
---@return boolean
function m.IsNullOrEmpty(value) end

---@overload fun(normalizationForm:System.Text.NormalizationForm):string
---@return string
function m:Normalize() end

---@overload fun(normalizationForm:System.Text.NormalizationForm):boolean
---@return boolean
function m:IsNormalized() end

---@overload fun(startIndex:number, count:number):string
---@param startIndex number
---@return string
function m:Remove(startIndex) end

---@overload fun(totalWidth:number, paddingChar:number):string
---@param totalWidth number
---@return string
function m:PadLeft(totalWidth) end

---@overload fun(totalWidth:number, paddingChar:number):string
---@param totalWidth number
---@return string
function m:PadRight(totalWidth) end

---@overload fun(value:string, comparisonType:System.StringComparison):boolean
---@overload fun(value:string, ignoreCase:boolean, culture:System.Globalization.CultureInfo):boolean
---@param value string
---@return boolean
function m:StartsWith(value) end

---@overload fun(oldValue:string, newValue:string):string
---@param oldChar number
---@param newChar number
---@return string
function m:Replace(oldChar, newChar) end

---@overload fun(culture:System.Globalization.CultureInfo):string
---@return string
function m:ToLower() end

---@return string
function m:ToLowerInvariant() end

---@overload fun(culture:System.Globalization.CultureInfo):string
---@return string
function m:ToUpper() end

---@return string
function m:ToUpperInvariant() end

---@overload fun(provider:System.IFormatProvider):string @virtual
---@virtual
---@return string
function m:ToString() end

---@overload fun(format:string, arg0:any, arg1:any):string @static
---@overload fun(format:string, arg0:any, arg1:any, arg2:any):string @static
---@overload fun(format:string, args:any[]|any):string @static
---@overload fun(format:string):string @static
---@overload fun(provider:System.IFormatProvider, format:string, args:any[]|any):string @static
---@overload fun(provider:System.IFormatProvider, format:string):string @static
---@static
---@param format string
---@param arg0 any
---@return string
function m.Format(format, arg0) end

---@static
---@param str string
---@return string
function m.Copy(str) end

---@overload fun(arg0:any, arg1:any):string @static
---@overload fun(arg0:any, arg1:any, arg2:any):string @static
---@overload fun(arg0:any, arg1:any, arg2:any, arg3:any):string @static
---@overload fun(str0:string, str1:string):string @static
---@overload fun(str0:string, str1:string, str2:string):string @static
---@overload fun(str0:string, str1:string, str2:string, str3:string):string @static
---@overload fun(args:any[]):string @static
---@overload fun():string @static
---@overload fun(values:string[]):string @static
---@overload fun():string @static
---@static
---@param arg0 any
---@return string
function m.Concat(arg0) end

---@param startIndex number
---@param value string
---@return string
function m:Insert(startIndex, value) end

---@static
---@param str string
---@return string
function m.Intern(str) end

---@static
---@param str string
---@return string
function m.IsInterned(str) end

---@overload fun(separator:string, value:string[], startIndex:number, count:number):string @static
---@static
---@param separator string
---@param value string[]
---@return string
function m.Join(separator, value) end

---@return System.CharEnumerator
function m:GetEnumerator() end

---@virtual
---@return number
function m:GetHashCode() end

---@static
---@param a string
---@param b string
---@return boolean
function m.op_Equality(a, b) end

---@static
---@param a string
---@param b string
---@return boolean
function m.op_Inequality(a, b) end

System.String = m
return m
