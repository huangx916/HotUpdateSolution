---@class System.BRECORD : System.ValueType
local m = {}

System.BRECORD = m
return m
