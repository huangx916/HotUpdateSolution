---@class System.CurrentSystemTimeZone.TimeZoneNames : System.Enum
---@field public StandardNameIdx System.CurrentSystemTimeZone.TimeZoneNames @static
---@field public DaylightNameIdx System.CurrentSystemTimeZone.TimeZoneNames @static
---@field public value__ number
local m = {}

System.CurrentSystemTimeZone.TimeZoneNames = m
return m
