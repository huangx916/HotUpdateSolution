---@class System.AssemblyLoadEventArgs : System.EventArgs
---@field public LoadedAssembly System.Reflection.Assembly
local m = {}

System.AssemblyLoadEventArgs = m
return m
