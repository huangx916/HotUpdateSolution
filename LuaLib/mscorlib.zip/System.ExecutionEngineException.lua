---@class System.ExecutionEngineException : System.SystemException
local m = {}

System.ExecutionEngineException = m
return m
