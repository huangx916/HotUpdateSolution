---@class SimpleJson.Reflection.GetHandler : System.MulticastDelegate
local m = {}

---@virtual
---@param source any
---@return any
function m:Invoke(source) end

---@virtual
---@param source any
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(source, callback, object) end

---@virtual
---@param result System.IAsyncResult
---@return any
function m:EndInvoke(result) end

SimpleJson.Reflection.GetHandler = m
return m
