---@class SimpleJson.Reflection.CacheResolver.MemberMap : System.Object
---@field public MemberInfo System.Reflection.MemberInfo
---@field public Type System.Type
---@field public Getter fun(source:any):any
---@field public Setter fun(source:any, value:any)
local m = {}

SimpleJson.Reflection.CacheResolver.MemberMap = m
return m
