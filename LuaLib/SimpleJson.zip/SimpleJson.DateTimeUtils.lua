---@class SimpleJson.DateTimeUtils : System.Object
local m = {}

---@static
---@param d System.DateTime
---@return string
function m.GetUtcOffsetText(d) end

---@static
---@param d System.DateTime
---@return System.TimeSpan
function m.GetUtcOffset(d) end

SimpleJson.DateTimeUtils = m
return m
