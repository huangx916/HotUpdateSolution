---@class SimpleJson.Reflection.SetHandler : System.MulticastDelegate
local m = {}

---@virtual
---@param source any
---@param value any
function m:Invoke(source, value) end

---@virtual
---@param source any
---@param value any
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(source, value, callback, object) end

---@virtual
---@param result System.IAsyncResult
function m:EndInvoke(result) end

SimpleJson.Reflection.SetHandler = m
return m
