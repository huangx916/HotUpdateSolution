---@class SimpleJson.PocoJsonSerializerStrategy : System.Object
local m = {}

---@virtual
---@param input any
---@return boolean, System.Object
function m:SerializeNonPrimitiveObject(input) end

---@virtual
---@param value any
---@param type System.Type
---@return any
function m:DeserializeObject(value, type) end

SimpleJson.PocoJsonSerializerStrategy = m
return m
