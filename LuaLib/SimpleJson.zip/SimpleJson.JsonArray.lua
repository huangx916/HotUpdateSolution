---@class SimpleJson.JsonArray : System.Collections.Generic.List_1_System_Object_
local m = {}

---@virtual
---@return string
function m:ToString() end

SimpleJson.JsonArray = m
return m
