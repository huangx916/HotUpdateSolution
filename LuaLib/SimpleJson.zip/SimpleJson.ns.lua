---@class SimpleJson
SimpleJson = {}