---@class SimpleJson.DataContractJsonSerializerStrategy : SimpleJson.PocoJsonSerializerStrategy
local m = {}

SimpleJson.DataContractJsonSerializerStrategy = m
return m
