---@class SimpleJson.Reflection.ReflectionUtils : System.Object
local m = {}

---@overload fun(objectType:System.Type, attributeType:System.Type):System.Attribute @static
---@static
---@param info System.Reflection.MemberInfo
---@param type System.Type
---@return System.Attribute
function m.GetAttribute(info, type) end

---@static
---@param type System.Type
---@return boolean
function m.IsTypeGenericeCollectionInterface(type) end

---@static
---@param type System.Type
---@return boolean
function m.IsTypeDictionary(type) end

---@static
---@param type System.Type
---@return boolean
function m.IsNullableType(type) end

---@static
---@param obj any
---@param nullableType System.Type
---@return any
function m.ToNullableType(obj, nullableType) end

SimpleJson.Reflection.ReflectionUtils = m
return m
