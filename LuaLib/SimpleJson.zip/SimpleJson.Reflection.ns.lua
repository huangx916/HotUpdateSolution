---@class SimpleJson.Reflection
SimpleJson.Reflection = {}