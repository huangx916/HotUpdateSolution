---@class SimpleJson.IJsonSerializerStrategy : table
local m = {}

---@abstract
---@param input any
---@return boolean, System.Object
function m:SerializeNonPrimitiveObject(input) end

---@abstract
---@param value any
---@param type System.Type
---@return any
function m:DeserializeObject(value, type) end

SimpleJson.IJsonSerializerStrategy = m
return m
