---@class SimpleJson.Reflection.CacheResolver : System.Object
local m = {}

---@static
---@param type System.Type
---@return any
function m.GetNewInstance(type) end

---@param type System.Type
---@return SimpleJson.Reflection.SafeDictionary_2_System_String_SimpleJson_Reflection_CacheResolver_MemberMap_
function m:LoadMaps(type) end

SimpleJson.Reflection.CacheResolver = m
return m
