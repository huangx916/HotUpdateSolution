---@class SimpleJson.SimpleJson : System.Object
---@field public CurrentJsonSerializerStrategy SimpleJson.IJsonSerializerStrategy @static
---@field public PocoJsonSerializerStrategy SimpleJson.PocoJsonSerializerStrategy @static
---@field public DataContractJsonSerializerStrategy SimpleJson.DataContractJsonSerializerStrategy @static
local m = {}

---@overload fun(json:string, type:System.Type, jsonSerializerStrategy:SimpleJson.IJsonSerializerStrategy):any @static
---@overload fun(json:string, type:System.Type):any @static
---@overload fun(json:string, jsonSerializerStrategy:SimpleJson.IJsonSerializerStrategy):any @static
---@overload fun(json:string):any @static
---@static
---@param json string
---@return any
function m.DeserializeObject(json) end

---@static
---@param json string
---@return boolean, System.Object
function m.TryDeserializeObject(json) end

---@overload fun(json:any):string @static
---@static
---@param json any
---@param jsonSerializerStrategy SimpleJson.IJsonSerializerStrategy
---@return string
function m.SerializeObject(json, jsonSerializerStrategy) end

---@static
---@param jsonString string
---@return string
function m.EscapeToJavascriptString(jsonString) end

SimpleJson.SimpleJson = m
return m
