---@class SimpleJson.Reflection.SafeDictionary_2_TKey_TValue_ : System.Object
---@field public Item any
local m = {}

---@param key any
---@return boolean, any
function m:TryGetValue(key) end

---@return System.Collections.Generic.IEnumerator_1_System_Collections_Generic_KeyValuePair_2_TKey_TValue__
function m:GetEnumerator() end

---@param key any
---@param value any
function m:Add(key, value) end

SimpleJson.Reflection.SafeDictionary_2_TKey_TValue_ = m
return m
