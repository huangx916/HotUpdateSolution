---@class SimpleJson.JsonObject : System.Object
---@field public Item any
---@field public Keys System.Collections.Generic.ICollection_1_System_String_
---@field public Values System.Collections.Generic.ICollection_1_System_Object_
---@field public Item any
---@field public Count number
---@field public IsReadOnly boolean
local m = {}

---@overload fun(item:System.Collections.Generic.KeyValuePair_2_System_String_System_Object_) @virtual
---@virtual
---@param key string
---@param value any
function m:Add(key, value) end

---@virtual
---@param key string
---@return boolean
function m:ContainsKey(key) end

---@overload fun(item:System.Collections.Generic.KeyValuePair_2_System_String_System_Object_):boolean @virtual
---@virtual
---@param key string
---@return boolean
function m:Remove(key) end

---@virtual
---@param key string
---@return boolean, System.Object
function m:TryGetValue(key) end

---@virtual
function m:Clear() end

---@virtual
---@param item System.Collections.Generic.KeyValuePair_2_System_String_System_Object_
---@return boolean
function m:Contains(item) end

---@virtual
---@param array System.Collections.Generic.KeyValuePair_2_System_String_System_Object_[]
---@param arrayIndex number
function m:CopyTo(array, arrayIndex) end

---@virtual
---@return System.Collections.Generic.IEnumerator_1_System_Collections_Generic_KeyValuePair_2_System_String_System_Object__
function m:GetEnumerator() end

---@virtual
---@return string
function m:ToString() end

SimpleJson.JsonObject = m
return m
