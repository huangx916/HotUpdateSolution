---@class SimpleJson.Reflection.MemberMapLoader : System.MulticastDelegate
local m = {}

---@virtual
---@param type System.Type
---@param memberMaps SimpleJson.Reflection.SafeDictionary_2_System_String_SimpleJson_Reflection_CacheResolver_MemberMap_
function m:Invoke(type, memberMaps) end

---@virtual
---@param type System.Type
---@param memberMaps SimpleJson.Reflection.SafeDictionary_2_System_String_SimpleJson_Reflection_CacheResolver_MemberMap_
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(type, memberMaps, callback, object) end

---@virtual
---@param result System.IAsyncResult
function m:EndInvoke(result) end

SimpleJson.Reflection.MemberMapLoader = m
return m
