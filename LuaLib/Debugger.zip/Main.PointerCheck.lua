---@class Main.PointerCheck : System.Object
local m = {}

---@overload fun(obj:any, message:string):boolean @static
---@overload fun(obj:any, message:string, type:UnityEngine.LogType):boolean @static
---@static
---@param obj any
---@return boolean
function m.IsNotNull(obj) end

---@overload fun(obj:any, message:string):boolean @static
---@overload fun(obj:any, message:string, type:UnityEngine.LogType):boolean @static
---@static
---@param obj any
---@return boolean
function m.IsNull(obj) end

Main.PointerCheck = m
return m
