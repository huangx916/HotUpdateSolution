---@class Main.Debugger : System.Object
---@field public EnableLog boolean @static
---@field public EnableDraw boolean @static
---@field public LogMessageFormat fun(arg1:any):string @static
---@field public DeveloperConsoleVisible boolean @static
---@field public isDebugBuild boolean @static
local m = {}

---@overload fun(condition:boolean, context:UnityEngine.Object) @static
---@overload fun(condition:boolean, message:any) @static
---@overload fun(condition:boolean, message:any, context:UnityEngine.Object) @static
---@static
---@param condition boolean
function m.Assert(condition) end

---@overload fun(condition:boolean, format:string) @static
---@overload fun(condition:boolean, context:UnityEngine.Object, format:string, args:any[]|any) @static
---@overload fun(condition:boolean, context:UnityEngine.Object, format:string) @static
---@static
---@param condition boolean
---@param format string
---@param args any[]|any
function m.AssertFormat(condition, format, args) end

---@static
function m.Break() end

---@static
function m.DebugBreak() end

---@static
function m.ClearDeveloperConsole() end

---@overload fun(start:UnityEngine.Vector3, _end:UnityEngine.Vector3, color:UnityEngine.Color) @static
---@overload fun(start:UnityEngine.Vector3, _end:UnityEngine.Vector3, color:UnityEngine.Color, duration:number) @static
---@overload fun(start:UnityEngine.Vector3, _end:UnityEngine.Vector3, color:UnityEngine.Color, duration:number, depthTest:boolean) @static
---@static
---@param start UnityEngine.Vector3
---@param _end UnityEngine.Vector3
function m.DrawLine(start, _end) end

---@overload fun(start:UnityEngine.Vector3, dir:UnityEngine.Vector3, color:UnityEngine.Color) @static
---@overload fun(start:UnityEngine.Vector3, dir:UnityEngine.Vector3, color:UnityEngine.Color, duration:number) @static
---@overload fun(start:UnityEngine.Vector3, dir:UnityEngine.Vector3, color:UnityEngine.Color, duration:number, depthTest:boolean) @static
---@static
---@param start UnityEngine.Vector3
---@param dir UnityEngine.Vector3
function m.DrawRay(start, dir) end

---@overload fun(message:any) @static
---@overload fun(message:any, context:UnityEngine.Object) @static
---@overload fun(type:UnityEngine.LogType) @static
---@overload fun(type:UnityEngine.LogType, message:any) @static
---@overload fun(type:UnityEngine.LogType, message:any, context:UnityEngine.Object) @static
---@static
function m.Log() end

---@overload fun(format:string) @static
---@overload fun(context:UnityEngine.Object, format:string, args:any[]|any) @static
---@overload fun(context:UnityEngine.Object, format:string) @static
---@overload fun(type:UnityEngine.LogType, format:string, args:any[]|any) @static
---@overload fun(type:UnityEngine.LogType, format:string) @static
---@overload fun(type:UnityEngine.LogType, context:UnityEngine.Object, format:string, args:any[]|any) @static
---@overload fun(type:UnityEngine.LogType, context:UnityEngine.Object, format:string) @static
---@static
---@param format string
---@param args any[]|any
function m.LogFormat(format, args) end

---@overload fun(message:any) @static
---@overload fun(message:any, context:UnityEngine.Object) @static
---@static
function m.LogAssertion() end

---@overload fun(format:string) @static
---@overload fun(context:UnityEngine.Object, format:string, args:any[]|any) @static
---@overload fun(context:UnityEngine.Object, format:string) @static
---@static
---@param format string
---@param args any[]|any
function m.LogAssertionFormat(format, args) end

---@overload fun(message:any) @static
---@overload fun(message:any, context:UnityEngine.Object) @static
---@static
function m.LogError() end

---@overload fun(format:string) @static
---@overload fun(context:UnityEngine.Object, format:string, args:any[]|any) @static
---@overload fun(context:UnityEngine.Object, format:string) @static
---@static
---@param format string
---@param args any[]|any
function m.LogErrorFormat(format, args) end

---@overload fun(message:any) @static
---@overload fun(message:any, context:UnityEngine.Object) @static
---@static
function m.LogWarning() end

---@overload fun(format:string) @static
---@overload fun(context:UnityEngine.Object, format:string, args:any[]|any) @static
---@overload fun(context:UnityEngine.Object, format:string) @static
---@static
---@param format string
---@param args any[]|any
function m.LogWarningFormat(format, args) end

---@overload fun(exception:System.Exception, context:UnityEngine.Object) @static
---@static
---@param exception System.Exception
function m.LogException(exception) end

Main.Debugger = m
return m
