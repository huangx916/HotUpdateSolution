---@class Main
Main = {}